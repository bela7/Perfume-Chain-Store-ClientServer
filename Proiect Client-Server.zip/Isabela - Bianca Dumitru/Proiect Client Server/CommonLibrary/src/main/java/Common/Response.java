package Common;

import java.io.Serializable;

public class Response implements Serializable {
    private Type type;
    private boolean success;
    private Object data;
    private String role;
    private int idMagazin;


    public Response(Type type, boolean success, Object data) {
        this.type = type;
        this.success = success;
        this.data = data;
    }

    public Response(Type type, Object data) {
        this.type = type;
        this.data = data;
        this.success = true;
    }

    public enum Type {
        LOGIN_RESULT,
        ADD_USER_RESULT,
        UPDATE_USER_RESULT,
        DELETE_USER_RESULT,
        DISPLAY_USER_LIST_RESULT,
        GET_ALL_PRODUCATORS_RESULT,
        FILTER_PARFUMS_RESULT,
        GET_ALL_PARFUMURI_FOR_MAGAZIN_RESULT,
        SORT_PARFUMS_BY_PRICE_RESULT,
        SORT_PARFUMS_BY_NAME_RESULT,
        SEARCH_PARFUM_BY_NAME_RESULT,
        GET_MAGAZIN_ID_BY_NAME_RESULT,
        GET_ALL_MAGAZIN_NAMES_RESULT,
        ADD_PARFUM_NEW_RESULT,
        ADD_PARFUM_RESULT,
        UPDATE_PARFUM_RESULT,
        DELETE_PARFUM_RESULT

    }


    public boolean isSuccess() {
        return success;
    }

    public Object getData() {
        return data;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public int getIdMagazin() {
        return idMagazin;
    }

    public void setIdMagazin(int idMagazin) {
        this.idMagazin = idMagazin;
    }



    @Override
    public String toString() {
        return "Response{" +
                "type=" + type +
                ", success=" + success +
                ", data=" + data +
                ", role='" + role + '\'' +
                ", idMagazin=" + idMagazin +
                '}';
    }
}
