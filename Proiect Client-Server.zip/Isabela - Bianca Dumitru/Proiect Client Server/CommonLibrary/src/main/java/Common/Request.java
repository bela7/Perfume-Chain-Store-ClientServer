package Common;

import java.io.Serializable;

public class Request implements Serializable {
    private Type type;
    private Object data;

    public enum Type {
        LOGIN,
        DISCONNECT,
        ADD_USER,
        UPDATE_USER,
        DELETE_USER,
        DISPLAY_USER_LIST,
        GET_ALL_PRODUCATORS,
        FILTER_PARFUMS,
        GET_ALL_PARFUMURI_FOR_MAGAZIN,
        SORT_PARFUMS_BY_PRICE,
        SORT_PARFUMS_BY_NAME,
        SEARCH_PARFUM_BY_NAME,
        GET_MAGAZIN_ID_BY_NAME,
        GET_ALL_MAGAZIN_NAMES,
        ADD_PARFUM,
        ADD_PARFUM_NEW,
        UPDATE_PARFUM,
        DELETE_PARFUM
    }

    public Request(Type type, Object data) {
        this.type = type;
        this.data = data;
    }
    public Type getType() {
        return type;
    }

    public Object getData() {
        return data;
    }
}
