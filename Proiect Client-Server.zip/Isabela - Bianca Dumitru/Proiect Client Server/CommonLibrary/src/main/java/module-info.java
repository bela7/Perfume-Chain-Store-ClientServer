module com.example.commonlibrary {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.commonlibrary to javafx.fxml;
    exports com.example.commonlibrary;
}