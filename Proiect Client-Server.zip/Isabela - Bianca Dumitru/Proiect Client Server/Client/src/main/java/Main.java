import Client.Client;
import Controller.LoginController;
import Model.Language;

import javax.swing.*;
import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Language language = new Language();

                try {
                    Client client = new Client("127.0.0.1", 12345);
                    LoginController loginController = new LoginController(language, client);
                    loginController.initialize();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
