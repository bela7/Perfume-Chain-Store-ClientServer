package Client;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import Common.Request;
import Common.Response;

public class Client {
    private Socket socket;
    private ObjectOutputStream outputStream;
    private ObjectInputStream inputStream;


    public Client(String host, int port) throws IOException {
        socket = new Socket(host, port);
        outputStream = new ObjectOutputStream(socket.getOutputStream());
        outputStream.flush();
        inputStream = new ObjectInputStream(socket.getInputStream());
        System.out.println("Connected to server at IP: " + socket.getInetAddress().getHostAddress() + " Port: " + socket.getPort());
    }


    public Response sendRequest(Request request) {
        try {
            outputStream.writeObject(request);
            outputStream.flush();
            outputStream.reset();
            System.out.println("Request sent");
            System.out.println("Request: " + request);
            System.out.println("Waiting for response...");
            Response response = (Response) inputStream.readObject();
            System.out.println("Response received");
            return response;
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("IOException or ClassNotFoundException in sendLoginRequest: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    public void sendDisconnectRequest() {
        try {
            Request disconnectRequest = new Request(Request.Type.DISCONNECT, null);
            outputStream.writeObject(disconnectRequest);
            outputStream.flush();
            System.out.println("Disconnect request sent");

            System.out.println("Waiting for disconnect response...");
            Response response = (Response) inputStream.readObject();
            System.out.println("Disconnect response received: " + response.isSuccess());

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }


    public void close() {
        sendDisconnectRequest();
        try {
            outputStream.close();
            inputStream.close();
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



}
