package Controller;

import Client.Client;
import View.ManagerView;
import Common.Request;
import Common.Response;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.*;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


import org.json.simple.JSONArray;
import org.json.simple.JSONObject;


public class ManagerController {
    private ManagerView view;
    private LanguageController languageController;
    private Client client;

    private String currentProducerChartType = "BarChart";
    private String currentStockChartType = "BarChart";



    public ManagerController(Client client) {
        this.languageController = new LanguageController();
        this.client = client;
    }

    public void setView(ManagerView view) {
        this.view = view;
        setupListeners();
    }
    private void changeLanguage(Locale locale) {
        languageController.changeLanguage(locale.getLanguage());
        view.updateResourceBundle(languageController.getCurrentLocale());
        updateUIComponents();
        displayProducators();
        displayParfumList();
        String currentProducerChartType = getCurrentProducerChartType();
        String currentStockChartType = getCurrentStockChartType();
        generateProducerChart(currentProducerChartType);
        generateStockChart(currentStockChartType);
    }

    private void updateUIComponents() {
        ResourceBundle rb = view.getResourceBundle();

        view.setTitle(rb.getString("managerTitle"));
        view.getBtnViewDetails().setText(rb.getString("vizualizeazaDetaliileButton"));
        view.getBtnCauta().setText(rb.getString("cautaButton"));
        view.getLblMagazin().setText(rb.getString("magazin"));
        view.getLblSortareNume().setText(rb.getString("sortareNume"));
        view.getLblSortarePret().setText(rb.getString("sortarePret"));
        view.getLblCautaDupaNume().setText(rb.getString("cautaNume"));
        view.getBtnFiltreaza().setText(rb.getString("filtreazaButton"));
        view.getLblPretMinim().setText(rb.getString("pretMinimLabel"));
        view.getLblPretMaxim().setText(rb.getString("pretMaximLabel"));
        view.getLblProducator().setText(rb.getString("producatorLabel"));
        view.getLblDisponibilitate().setText(rb.getString("disponibilitateLabel"));
        view.getChckbxDisponibil().setText(rb.getString("disponibilCheckbox"));
        view.getLblSaveParfumList().setText(rb.getString("salveazaListaParfumuri"));
        view.getBtnSaveFile().setText(rb.getString("salveazaButton"));
        view.setSaveDialogTitle(rb.getString("specify"));
        view.getLblVisualizeStatistics().setText(rb.getString("vizualizeazaStatisticiLabel"));
        view.getBtnVisualize().setText(rb.getString("vizualizeazaButton"));


        String[] columnNames = new String[] {
                rb.getString("idParfumLabel"),
                rb.getString("denumireLabel"),
                rb.getString("producatorLabel"),
                rb.getString("pretLabel"),
                rb.getString("descriereLabel"),
                rb.getString("stocLabel")
        };
        DefaultTableModel model = (DefaultTableModel) view.getTable().getModel();
        model.setColumnIdentifiers(columnNames);
        updateComboBoxSortarePret();
        updateComboBoxSortareNume();
        updateComboBoxStatistics();

    }

    public void showView(String user) {
        view = new ManagerView(user);
        setView(view);
        view.setVisible(true);
        view.setTitle("Manager - " + user);
        view.getBtnRomanian().addActionListener(e -> changeLanguage(new Locale("ro", "RO")));
        view.getBtnEnglish().addActionListener(e -> changeLanguage(Locale.ENGLISH));
        view.getBtnFrench().addActionListener(e -> changeLanguage(Locale.FRENCH));
        view.getBtnSpanish().addActionListener(e -> changeLanguage(new Locale("es", "ES")));
        displayMagazinNames();
        updateComboBoxSortarePret();
        updateComboBoxSortareNume();
        updateComboBoxStatistics();
        displayParfumList();
        displayProducators();
    }


    private void setupListeners() {

        view.getComboBoxMagazin().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                displayParfumList();
            }
        });


        view.getComboBoxSortareNume().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleSortParfumsByName();
            }
        });

        view.getComboBoxSortarePret().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleSortParfumsByPrice();
            }
        });

        view.getBtnCauta().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleSearchParfumByName();
            }
        });

        view.getBtnViewDetails().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = view.getTable().getSelectedRow();
                if (selectedRow != -1) {
                    Object[] rowData = view.getRowData(view.getTable(), selectedRow);
                    String[] formattedDetails = getFormattedPerfumeDetails(rowData);
                    view.showPerfumeDetails(formattedDetails[0], formattedDetails[1]);
                } else {
                    view.showMessageDialog(getLocalizedMessage("notSelectedParfumMessage"));
                }
            }
        });

        view.getBtnFiltreaza().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleFilterParfums();
            }
        });
        view.getBtnSaveFile().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleSaveParfumList();
            }
        });

        view.getBtnVisualize().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleVisualizeStatistics();
            }
        });


    }


    public String getLocalizedMessage(String key) {
        ResourceBundle rb = view.getResourceBundle();
        return rb.getString(key);
    }
    public void displayMagazinNames() {
        Request request = new Request(Request.Type.GET_ALL_MAGAZIN_NAMES, null);
        Response response = client.sendRequest(request);

        if (response != null && response.isSuccess()) {
            List<String> magazinNames = (List<String>) response.getData();
            JComboBox<String> comboBoxMagazin = view.getComboBoxMagazin();
            comboBoxMagazin.removeAllItems();

            for (String magazinName : magazinNames) {
                comboBoxMagazin.addItem(magazinName);
            }
            displayParfumList();
        }
    }

    public String[] getFormattedPerfumeDetails(Object[] rowData) {
        ResourceBundle rb = view.getResourceBundle();
        String title = rb.getString("detaliiParfumTitle");
        String details = String.format(
                "%s: %s\n%s: %s\n%s: %s\n%s: %s\n%s: %s\n%s: %s",
                rb.getString("idParfumLabel"), rowData[0],
                rb.getString("denumireLabel"), rowData[1],
                rb.getString("producatorLabel"), rowData[2],
                rb.getString("pretLabel"), rowData[3],
                rb.getString("descriereLabel"), rowData[4],
                rb.getString("stocLabel"), rowData[5]
        );
        return new String[]{title, details};
    }

    private void handleVisualizeStatistics() {
        ResourceBundle rb = view.getResourceBundle();
        String statisticsType = (String) view.getComboBoxStatisticsType().getSelectedItem();
        String chartType = (String) view.getComboBoxChartType().getSelectedItem();

        if (chartType.equals("BarChart")) {
            if (statisticsType.equals(rb.getString("producatorLabel"))) {
                generateProducerChart("BarChart");
            } else {
                generateStockChart("BarChart");
            }
        } else {
            if (statisticsType.equals(rb.getString("producatorLabel"))) {
                generateProducerChart("PieChart");
            } else {
                generateStockChart("PieChart");
            }
        }
        showStatisticsWindow();
    }
    private void showStatisticsWindow() {
        ResourceBundle rb = view.getResourceBundle();
        JFrame statisticsFrame = new JFrame(rb.getString("statistics"));
        statisticsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        statisticsFrame.setContentPane(view.getStatisticsPanel());
        statisticsFrame.pack();
        statisticsFrame.setLocationRelativeTo(null);
        statisticsFrame.setVisible(true);
    }

    private void generateProducerChart(String chartType) {
        currentProducerChartType = chartType;
        ResourceBundle rb = view.getResourceBundle();
        Map<String, Integer> producerCounts = new HashMap<>();
        for (int i = 0; i < view.getTable().getRowCount(); i++) {
            String producer = (String) view.getTable().getValueAt(i, 2);
            producerCounts.put(producer, producerCounts.getOrDefault(producer, 0) + 1);
        }
        view.getStatisticsPanel().removeAll();

        if (chartType.equals("BarChart")) {
            createProducerBarChart(producerCounts);
        } else {
            createProducerPieChart(producerCounts);
        }

        view.getStatisticsPanel().revalidate();
        view.getStatisticsPanel().repaint();
    }

    private void generateStockChart(String chartType) {
        currentProducerChartType = chartType;
        ResourceBundle rb = view.getResourceBundle();
        Map<String, Integer> stockCounts = new HashMap<>();
        for (int i = 0; i < view.getTable().getRowCount(); i++) {
            String stock = (int) view.getTable().getValueAt(i, 5) == 0 ? rb.getString("unavailable") : rb.getString("available");
            stockCounts.put(stock, stockCounts.getOrDefault(stock, 0) + 1);
        }
        view.getStatisticsPanel().removeAll();

        if (chartType.equals("BarChart")) {
            createStockBarChart(stockCounts);
        } else {
            createStockPieChart(stockCounts);
        }

        view.getStatisticsPanel().revalidate();
        view.getStatisticsPanel().repaint();
    }

    private String getCurrentProducerChartType() {
        return currentProducerChartType;
    }

    private String getCurrentStockChartType() {
        return currentStockChartType;
    }

    private void createProducerPieChart(Map<String, Integer> producerCounts) {
        ResourceBundle rb = view.getResourceBundle();
        DefaultPieDataset dataset = new DefaultPieDataset();
        for (Map.Entry<String, Integer> entry : producerCounts.entrySet()) {
            dataset.setValue(entry.getKey(), entry.getValue());
        }

        JFreeChart pieChart = ChartFactory.createPieChart(
                rb.getString("producatori"),
                dataset,
                true,
                true,
                false
        );

        PiePlot plot = (PiePlot) pieChart.getPlot();
        plot.setLabelGenerator(new StandardPieSectionLabelGenerator("{0}: {2}", new DecimalFormat("0"), new DecimalFormat("0.0%")));
        plot.setBackgroundPaint(Color.WHITE);
        pieChart.setBackgroundPaint(Color.WHITE);
        ChartPanel chartPanel = new ChartPanel(pieChart);
        chartPanel.setPreferredSize(new Dimension(1100, 750));
        view.getStatisticsPanel().setLayout(new BorderLayout());
        view.getStatisticsPanel().add(chartPanel, BorderLayout.CENTER);
    }

    private void createStockPieChart(Map<String, Integer> stockCounts) {
        ResourceBundle rb = view.getResourceBundle();
        DefaultPieDataset dataset = new DefaultPieDataset();
        for (Map.Entry<String, Integer> entry : stockCounts.entrySet()) {
            dataset.setValue(entry.getKey(), entry.getValue());
        }

        JFreeChart pieChart = ChartFactory.createPieChart(
                rb.getString("stocLabel"),
                dataset,
                true,
                true,
                false
        );

        PiePlot plot = (PiePlot) pieChart.getPlot();
        plot.setLabelGenerator(new StandardPieSectionLabelGenerator("{0}: {2}", new DecimalFormat("0"), new DecimalFormat("0.0%")));
        plot.setBackgroundPaint(Color.WHITE);
        pieChart.setBackgroundPaint(Color.WHITE);
        ChartPanel chartPanel = new ChartPanel(pieChart);
        chartPanel.setPreferredSize(new Dimension(600, 500));
        view.getStatisticsPanel().setLayout(new BorderLayout());
        view.getStatisticsPanel().add(chartPanel, BorderLayout.CENTER);
    }


    private void createProducerBarChart(Map<String, Integer> producerCounts) {
        ResourceBundle rb = view.getResourceBundle();
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        int totalCount = producerCounts.values().stream().mapToInt(Integer::intValue).sum();
        int seriesIndex = 0;

        for (Map.Entry<String, Integer> entry : producerCounts.entrySet()) {
            double percentage = (double) entry.getValue() / totalCount * 100.0;
            dataset.addValue(percentage, entry.getKey(), " ");

            seriesIndex++;
        }

        JFreeChart barChart = ChartFactory.createBarChart(
                rb.getString("producatori"),
                rb.getString("producatori"),
                " ",
                dataset,
                PlotOrientation.VERTICAL,
                true,
                true,
                false
        );

        CategoryPlot plot = barChart.getCategoryPlot();
        BarRenderer renderer = (BarRenderer) plot.getRenderer();

        for (int i = 0; i < seriesIndex; i++) {
            renderer.setSeriesItemLabelGenerator(i, new StandardCategoryItemLabelGenerator("{2}%", new DecimalFormat("0.0")));
            renderer.setSeriesItemLabelsVisible(i, true);
        }

        ChartPanel chartPanel = new ChartPanel(barChart);
        chartPanel.setPreferredSize(new Dimension(1100, 750));
        chartPanel.setBackground(Color.WHITE);
        view.getStatisticsPanel().setLayout(new BorderLayout());
        view.getStatisticsPanel().add(chartPanel, BorderLayout.CENTER);
    }

    private void createStockBarChart(Map<String, Integer> stockCounts) {
        ResourceBundle rb = view.getResourceBundle();
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        int totalCount = stockCounts.values().stream().mapToInt(Integer::intValue).sum();
        int seriesIndex = 0;

        for (Map.Entry<String, Integer> entry : stockCounts.entrySet()) {
            double percentage = (double) entry.getValue() / totalCount * 100.0;
            dataset.addValue(percentage, entry.getKey(), " ");

            seriesIndex++;
        }

        JFreeChart barChart = ChartFactory.createBarChart(
                rb.getString("stocLabel"),
                rb.getString("stocLabel"),
                " ",
                dataset,
                PlotOrientation.VERTICAL,
                true,
                true,
                false
        );

        CategoryPlot plot = barChart.getCategoryPlot();
        BarRenderer renderer = (BarRenderer) plot.getRenderer();

        for (int i = 0; i < seriesIndex; i++) {
            renderer.setSeriesItemLabelGenerator(i, new StandardCategoryItemLabelGenerator("{2}%", new DecimalFormat("0.0")));
            renderer.setSeriesItemLabelsVisible(i, true);
        }

        ChartPanel chartPanel = new ChartPanel(barChart);
        chartPanel.setPreferredSize(new Dimension(500, 500));
        chartPanel.setBackground(Color.WHITE);
        view.getStatisticsPanel().setLayout(new BorderLayout());
        view.getStatisticsPanel().add(chartPanel, BorderLayout.CENTER);
    }


    public boolean isSortByPriceAscending() {
        JComboBox<String> comboBoxSortarePret = view.getComboBoxSortarePret();
        return comboBoxSortarePret.getSelectedItem().equals("Crescător");
    }

    public boolean isSortByNameAscending() {
        JComboBox<String> comboBoxSortareNume = view.getComboBoxSortareNume();
        String selectedItem = (String) comboBoxSortareNume.getSelectedItem();
        if (selectedItem == null) {
            return true;
        }
        return selectedItem.equals(view.getResourceBundle().getString("crescator"));
    }

    private void handleSaveParfumList() {
        String fileFormat = (String) view.getComboBoxFileFormats().getSelectedItem();
        JTable table = view.getTable();

        switch (fileFormat) {
            case "CSV":
                saveTableAsCSV(table);
                break;
            case "JSON":
                saveTableAsJSON(table);
                break;
            case "XML":
                saveTableAsXML(table);
                break;
            case "TXT":
                saveTableAsTXT(table);
                break;
        }
    }

    private void saveTableAsCSV(JTable table) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle(view.getSaveDialogTitle());
        FileNameExtensionFilter filter = new FileNameExtensionFilter("CSV Files", "csv");
        fileChooser.setFileFilter(filter);

        int userSelection = fileChooser.showSaveDialog(view);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            try (FileWriter fw = new FileWriter(fileToSave)) {
                for (int i = 0; i < table.getColumnCount(); i++) {
                    fw.write(table.getColumnName(i));
                    if (i < table.getColumnCount() - 1) {
                        fw.write(",");
                    }
                }
                fw.write("\n");

                for (int i = 0; i < table.getRowCount(); i++) {
                    for (int j = 0; j < table.getColumnCount(); j++) {
                        fw.write(table.getValueAt(i, j).toString());
                        if (j < table.getColumnCount() - 1) {
                            fw.write(",");
                        }
                    }
                    fw.write("\n");
                }
                view.showMessageDialog(getLocalizedMessage("savedSuccess"));
            } catch (IOException e) {
                view.showMessageDialog(getLocalizedMessage("savedError"));
                e.printStackTrace();
            }
        }
    }

    private void saveTableAsJSON(JTable table) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle(view.getSaveDialogTitle());
        FileNameExtensionFilter filter = new FileNameExtensionFilter("JSON Files", "json");
        fileChooser.setFileFilter(filter);

        int userSelection = fileChooser.showSaveDialog(view);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();

            JSONArray jsonArray = new JSONArray();

            for (int i = 0; i < table.getRowCount(); i++) {
                JSONObject jsonObject = new JSONObject();
                for (int j = 0; j < table.getColumnCount(); j++) {
                    jsonObject.put(table.getColumnName(j), table.getValueAt(i, j));
                }
                jsonArray.add(jsonObject);
            }

            try (FileWriter file = new FileWriter(fileToSave)) {
                file.write(jsonArray.toJSONString());
                file.flush();
                view.showMessageDialog(getLocalizedMessage("savedSuccess"));
            } catch (IOException e) {
                view.showMessageDialog(getLocalizedMessage("savedError"));
                e.printStackTrace();
            }
        }
    }



    private void saveTableAsXML(JTable table) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle(view.getSaveDialogTitle());
        FileNameExtensionFilter filter = new FileNameExtensionFilter("XML Files", "xml");
        fileChooser.setFileFilter(filter);

        int userSelection = fileChooser.showSaveDialog(view);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            try (FileWriter fw = new FileWriter(fileToSave)) {
                fw.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
                fw.write("<parfums>\n");

                for (int i = 0; i < table.getRowCount(); i++) {
                    fw.write("  <parfum>\n");
                    for (int j = 0; j < table.getColumnCount(); j++) {
                        fw.write(String.format("    <%s>%s</%s>\n", table.getColumnName(j),
                                table.getValueAt(i, j).toString(), table.getColumnName(j)));
                    }
                    fw.write("  </parfum>\n");
                }
                fw.write("</parfums>");
                view.showMessageDialog(getLocalizedMessage("savedSuccess"));
            } catch (IOException e) {
                view.showMessageDialog(getLocalizedMessage("savedError"));
                e.printStackTrace();
            }
        }
    }

    private void saveTableAsTXT(JTable table) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle(view.getSaveDialogTitle());
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Text Files", "txt");
        fileChooser.setFileFilter(filter);

        int userSelection = fileChooser.showSaveDialog(view);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            try (FileWriter fw = new FileWriter(fileToSave)) {
                for (int i = 0; i < table.getRowCount(); i++) {
                    for (int j = 0; j < table.getColumnCount(); j++) {
                        fw.write(table.getValueAt(i, j).toString());
                        if (j < table.getColumnCount() - 1) {
                            fw.write("\t");
                        }
                    }
                    fw.write("\n");
                }
                view.showMessageDialog(getLocalizedMessage("savedSuccess"));
            } catch (IOException e) {
                view.showMessageDialog(getLocalizedMessage("savedError"));
                e.printStackTrace();
            }
        }
    }




    public void updateComboBoxStatistics() {
        JComboBox<String> comboBoxStatisticsType = view.getComboBoxStatisticsType();
        ActionListener[] listeners = comboBoxStatisticsType.getActionListeners();
        for (ActionListener listener : listeners) {
            comboBoxStatisticsType.removeActionListener(listener);
        }
        comboBoxStatisticsType.removeAllItems();

        ResourceBundle rb = view.getResourceBundle();
        if (rb == null) {
            rb = ResourceBundle.getBundle("LanguageBundle", view.getLocale());
        }

        comboBoxStatisticsType.addItem(rb.getString("producatorLabel"));
        comboBoxStatisticsType.addItem(rb.getString("stocLabel"));

        for (ActionListener listener : listeners) {
            comboBoxStatisticsType.addActionListener(listener);
        }
    }

    public void updateComboBoxSortarePret() {
        JComboBox<String> comboBoxSortarePret = view.getComboBoxSortarePret();
        ActionListener[] listeners = comboBoxSortarePret.getActionListeners();
        for (ActionListener listener : listeners) {
            comboBoxSortarePret.removeActionListener(listener);
        }
        comboBoxSortarePret.removeAllItems();

        ResourceBundle rb = view.getResourceBundle();
        if (rb == null) {
            rb = ResourceBundle.getBundle("LanguageBundle", view.getLocale());
        }

        comboBoxSortarePret.addItem(rb.getString("crescator"));
        comboBoxSortarePret.addItem(rb.getString("descrescator"));

        for (ActionListener listener : listeners) {
            comboBoxSortarePret.addActionListener(listener);
        }
    }

    public void updateComboBoxSortareNume() {
        JComboBox<String> comboBoxSortareNume = view.getComboBoxSortareNume();
        ActionListener[] listeners = comboBoxSortareNume.getActionListeners();
        for (ActionListener listener : listeners) {
            comboBoxSortareNume.removeActionListener(listener);
        }
        comboBoxSortareNume.removeAllItems();

        ResourceBundle rb = view.getResourceBundle();
        if (rb == null) {
            rb = ResourceBundle.getBundle("LanguageBundle", view.getLocale());
        }

        comboBoxSortareNume.addItem(rb.getString("crescator"));
        comboBoxSortareNume.addItem(rb.getString("descrescator"));

        for (ActionListener listener : listeners) {
            comboBoxSortareNume.addActionListener(listener);
        }
    }

    public void displayProducators() {
        JComboBox<String> comboBoxMagazin = view.getComboBoxMagazin();
        String selectedMagazinName = (String) comboBoxMagazin.getSelectedItem();
        int idMagazin = getMagazinIdByName(selectedMagazinName);

        Request request = new Request(Request.Type.GET_ALL_PRODUCATORS, idMagazin);
        Response response = client.sendRequest(request);

        if (response != null && response.isSuccess()) {
            @SuppressWarnings("unchecked")
            List<String> producators = (List<String>) response.getData();
            updateProducatorComboBox(producators);
            displayParfumList();
        } else {
            view.showMessageDialog(getLocalizedMessage("failedDisplay"));
        }
    }

    private void updateProducatorComboBox(List<String> producators) {
        JComboBox<String> comboBoxProducator = view.getComboBoxProducator();
        comboBoxProducator.removeAllItems();

        ResourceBundle rb = view.getResourceBundle();
        if (rb == null) {
            Locale romanianLocale = new Locale("ro", "RO");
            rb = ResourceBundle.getBundle("LanguageBundle", romanianLocale);
        }

        comboBoxProducator.addItem(rb.getString("totiProducatorii"));

        for (String producator : producators) {
            comboBoxProducator.addItem(producator);
        }
    }


    public String getSelectedProducator() {
        JComboBox<String> comboBoxProducator = view.getComboBoxProducator();
        if (comboBoxProducator.getSelectedIndex() > 0) {
            return (String) comboBoxProducator.getSelectedItem();
        }
        return "";
    }

    public String getPriceMin() {
        return view.getTextFieldPretMin().getText().trim();
    }


    public String getEnteredParfumName() { return view.getTextFieldCautaDupaNume().getText(); }

    public String getPriceMax() {
        return view.getTextFieldPretMax().getText().trim();
    }


    public boolean isDisponibilSelected() {
        JCheckBox chckbxDisponibil = view.getChckbxDisponibil();
        return chckbxDisponibil.isSelected();
    }
    public void handleFilterParfums() {
        Double priceMin = null;
        Double priceMax = null;
        String producator = null;
        Boolean disponibil = null;

        String priceMinText = getPriceMin();
        String priceMaxText = getPriceMax();
        JComboBox<String> comboBoxMagazin = view.getComboBoxMagazin();
        String selectedMagazinName = (String) comboBoxMagazin.getSelectedItem();
        int idMagazin = getMagazinIdByName(selectedMagazinName);

        if (!priceMinText.isEmpty()) {
            priceMin = Double.parseDouble(priceMinText);
        }

        if (!priceMaxText.isEmpty()) {
            priceMax = Double.parseDouble(priceMaxText);
        }

        if (!getSelectedProducator().isEmpty()) {
            producator = getSelectedProducator();
        }

        if (isDisponibilSelected()) {
            disponibil = isDisponibilSelected();
        }

        Locale currentLocale = view.getLocale();
        String language = currentLocale.getLanguage();

        Object[] requestData = new Object[]{idMagazin, priceMin, priceMax, producator, disponibil, language};
        Request request = new Request(Request.Type.FILTER_PARFUMS, requestData);
        Response response = client.sendRequest(request);

        if (response != null && response.isSuccess()) {
            @SuppressWarnings("unchecked")
            List<Object[]> filteredParfums = (List<Object[]>) response.getData();
            updateParfumList(filteredParfums);
        } else {
            view.showMessageDialog(getLocalizedMessage("failedDisplay"));
        }
    }


    public void handleSortParfumsByName() {
        boolean ascending = isSortByNameAscending();
        JComboBox<String> comboBoxMagazin = view.getComboBoxMagazin();
        String selectedMagazinName = (String) comboBoxMagazin.getSelectedItem();
        int idMagazin = getMagazinIdByName(selectedMagazinName);

        Locale currentLocale = view.getLocale();
        String language;
        if (currentLocale == null) {
            language = "ro";
        } else {
            language = currentLocale.getLanguage();
        }

        Object[] requestData = new Object[]{idMagazin, ascending, language};
        Request request = new Request(Request.Type.SORT_PARFUMS_BY_NAME, requestData);
        Response response = client.sendRequest(request);

        if (response != null && response.isSuccess()) {
            @SuppressWarnings("unchecked")
            List<Object[]> sortedParfumsObject = (List<Object[]>) response.getData();
            updateParfumList(sortedParfumsObject);
        } else {
            view.showMessageDialog(getLocalizedMessage("failedDisplay"));
        }
    }

    public void handleSortParfumsByPrice() {
        boolean ascending = isSortByPriceAscending();
        JComboBox<String> comboBoxMagazin = view.getComboBoxMagazin();
        String selectedMagazinName = (String) comboBoxMagazin.getSelectedItem();
        int idMagazin = getMagazinIdByName(selectedMagazinName);

        Locale currentLocale = view.getLocale();
        String language;
        if (currentLocale == null) {
            language = "ro";
        } else {
            language = currentLocale.getLanguage();
        }

        Object[] requestData = new Object[]{idMagazin, ascending, language};
        Request request = new Request(Request.Type.SORT_PARFUMS_BY_PRICE, requestData);
        Response response = client.sendRequest(request);

        if (response != null && response.isSuccess()) {
            @SuppressWarnings("unchecked")
            List<Object[]> sortedParfumsObject = (List<Object[]>) response.getData();
            updateParfumList(sortedParfumsObject);
        } else {
            view.showMessageDialog(getLocalizedMessage("failedDisplay"));
        }
    }


    public void handleSearchParfumByName() {
        String parfumName = getEnteredParfumName();
        Object[] requestData = new Object[]{parfumName};
        Request request = new Request(Request.Type.SEARCH_PARFUM_BY_NAME, requestData);
        Response response = client.sendRequest(request);

        if (response != null && response.isSuccess()) {
            String parfumDetails = (String) response.getData();
            view.showPerfumeDetailsByName(parfumDetails);
        } else {
            view.showMessageDialog(getLocalizedMessage("notFound"));
        }
    }
    public int getMagazinIdByName(String selectedMagazinName) {
        Object[] requestData = new Object[]{selectedMagazinName};
        Request request = new Request(Request.Type.GET_MAGAZIN_ID_BY_NAME, requestData);
        Response response = client.sendRequest(request);

        if (response != null && response.isSuccess()) {
            return (int) response.getData();
        } else {
            return -1;
        }
    }


    public void displayParfumList() {
        String language;
        Locale currentLocale = languageController.getCurrentLocale();
        JComboBox<String> comboBoxMagazin = view.getComboBoxMagazin();
        String selectedMagazinName = (String) comboBoxMagazin.getSelectedItem();
        int idMagazin = getMagazinIdByName(selectedMagazinName);

        if (currentLocale == null) {
            language = "ro";
        } else {
            language = currentLocale.getLanguage();
        }

        Object[] requestData = new Object[]{idMagazin, language};
        Request request = new Request(Request.Type.GET_ALL_PARFUMURI_FOR_MAGAZIN, requestData);
        Response response = client.sendRequest(request);

        if (response != null && response.isSuccess()) {
            @SuppressWarnings("unchecked")
            List<Object[]> parfumuriMagazinAsObjects = (List<Object[]>) response.getData();
            Object[][] parfumList = new Object[parfumuriMagazinAsObjects.size()][6];
            for (int i = 0; i < parfumuriMagazinAsObjects.size(); i++) {
                Object[] parfumData = parfumuriMagazinAsObjects.get(i);
                parfumList[i] = parfumData;
            }
            view.displayParfumList(parfumList);
        } else {
            view.showMessageDialog(getLocalizedMessage("failedDisplay"));
        }
    }



    private void updateParfumList(List<Object[]> objectList) {
        Object[][] parfumList = new Object[objectList.size()][6];
        for (int i = 0; i < objectList.size(); i++) {
            Object[] obj = objectList.get(i);
            parfumList[i][0] = obj[0]; // idParfum
            parfumList[i][1] = obj[1]; // nume
            parfumList[i][2] = obj[2]; // producator
            parfumList[i][3] = obj[3]; // pret
            parfumList[i][4] = obj[4]; // translated_descriere
            parfumList[i][5] = obj[5]; // stoc
        }

        view.displayParfumList(parfumList);
    }


}

