package Controller;

import View.AdministratorView;
import Client.Client;
import Common.*;


import javax.swing.*;
import java.util.Locale;
import java.util.ResourceBundle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;


public class AdministratorController {
    private AdministratorView view;
    private LanguageController languageController;
    private Client client;

    public AdministratorController(Client client) {
        this.languageController = new LanguageController();
        this.client = client;
    }

    public void setView(AdministratorView view) {
        this.view = view;
        setupListeners();
    }

    public void showView(String user) {
        view = new AdministratorView(user);
        setView(view);
        view.setVisible(true);
        view.setTitle("Administrator - " + user);
        view.getBtnRomanian().addActionListener(e -> changeLanguage(new Locale("ro", "RO")));
        view.getBtnEnglish().addActionListener(e -> changeLanguage(Locale.ENGLISH));
        view.getBtnFrench().addActionListener(e -> changeLanguage(Locale.FRENCH));
        view.getBtnSpanish().addActionListener(e -> changeLanguage(new Locale("es", "ES")));
        view.getFilterButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                filterUserListByRole();
            }
        });

        displayUserList();
    }

    private void changeLanguage(Locale locale) {
        languageController.changeLanguage(locale.getLanguage());
        view.updateResourceBundle(languageController.getCurrentLocale());
        updateUIComponents();
    }

    private void updateUIComponents() {
        ResourceBundle rb = view.getResourceBundle();

        view.setTitle(rb.getString("adminTitle"));
        view.getUserIdLabel().setText(rb.getString("userIdLabel"));
        view.getUsernameLabel().setText(rb.getString("usernameLabel"));
        view.getPasswordLabel().setText(rb.getString("passwordLabel"));
        view.getRoleLabel().setText(rb.getString("roleLabel"));
        view.getIdMagazinLabel().setText(rb.getString("idMagazinLabel"));
        view.getAddUserButton().setText(rb.getString("addUserButton"));
        view.getDeleteUserButton().setText(rb.getString("deleteUserButton"));
        view.getUpdateUserButton().setText(rb.getString("updateUserButton"));
        view.getViewUserDetailsButton().setText(rb.getString("viewUserDetailsButton"));
        view.getFilterButton().setText(rb.getString("filtreazaButton"));
        view.getFilterRoleLabel().setText(rb.getString("filterRole"));

        String[] translatedRoles = new String[]{
                rb.getString("roleAdministrator"),
                rb.getString("roleManager"),
                rb.getString("roleEmployee")
        };
        updateRoleComboBox(translatedRoles);

        String[] columnNames = new String[] {
                rb.getString("userIdLabel"),
                rb.getString("usernameLabel"),
                rb.getString("passwordLabel"),
                rb.getString("roleLabel"),
                rb.getString("idMagazinLabel")
        };
        DefaultTableModel model = (DefaultTableModel) view.getUserTable().getModel();
        model.setColumnIdentifiers(columnNames);
    }

    private void updateRoleComboBox(String[] translatedRoles) {
        JComboBox<String> roleComboBox = view.getRolComboBox();
        JComboBox<String> rolComboFilter = view.getRolComboFilter();
        DefaultComboBoxModel<String> comboModel = (DefaultComboBoxModel<String>) roleComboBox.getModel();
        DefaultComboBoxModel<String> filterComboModel = (DefaultComboBoxModel<String>) rolComboFilter.getModel();
        comboModel.removeAllElements();
        filterComboModel.removeAllElements();
        for (String role : translatedRoles) {
            comboModel.addElement(role);
            filterComboModel.addElement(role);
        }
        roleComboBox.setModel(comboModel);
        rolComboFilter.setModel(filterComboModel);
    }

    private String getSelectedRoleInRomanian(String selectedRole) {
        ResourceBundle rb = view.getResourceBundle();

        if (selectedRole.equals(rb.getString("roleAdministrator"))) {
            return "Administrator";
        } else if (selectedRole.equals(rb.getString("roleManager"))) {
            return "Manager";
        } else if (selectedRole.equals(rb.getString("roleEmployee"))) {
            return "Angajat";
        }

        return "";
    }

    private void filterUserListByRole() {
        String selectedRole = (String) view.getRolComboFilter().getSelectedItem();
        final String selectedRoleInRomanian = getSelectedRoleInRomanian(selectedRole);

        DefaultTableModel model = (DefaultTableModel) view.getUserTable().getModel();
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
        view.getUserTable().setRowSorter(sorter);

        // Filter the rows based on the selected role in Romanian
        if (selectedRoleInRomanian.isEmpty()) {
            sorter.setRowFilter(null); // Show all users if no role is selected
        } else {
            sorter.setRowFilter(new RowFilter<DefaultTableModel, Integer>() {
                @Override
                public boolean include(Entry<? extends DefaultTableModel, ? extends Integer> entry) {
                    String role = (String) entry.getValue(3); // Column index for role is 3
                    return role.equalsIgnoreCase(selectedRoleInRomanian);
                }
            });
        }
    }




    public int getUserId() {
        try {
            return Integer.parseInt(view.getUserIdField().getText());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    public String getUserName() {
        return view.getUserNameField().getText();
    }

    public String getPassword() {
        return view.getPasswordField().getText();
    }

    public String getRol() {
        return (String) view.getRolComboBox().getSelectedItem();
    }

    public int getIdMagazin() {
        try {
            return Integer.parseInt(view.getIdMagazinField().getText());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    public int getSelectedUserId() {
        int selectedRow = view.getUserTable().getSelectedRow();
        if (selectedRow != -1) {
            return Integer.parseInt(view.getUserTable().getValueAt(selectedRow, 0).toString());
        } else {
            return -1;
        }
    }

    public String getLocalizedMessage(String key) {
        ResourceBundle rb = view.getResourceBundle();
        return rb.getString(key);
    }

    private void setupListeners() {
        view.getAddUserButton().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addUser();
            }
        });

        view.getDeleteUserButton().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteUser();
            }
        });

        view.getUpdateUserButton().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateUser();
            }
        });

        view.getViewUserDetailsButton().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = view.getUserTable().getSelectedRow();
                if (selectedRow != -1) {
                    Object[] rowData = view.getRowData(selectedRow);
                    String userDetails = String.format(
                            "ID User: %s\nUsername: %s\nParola: %s\nRol: %s\nID Magazin: %s",
                            rowData[0], rowData[1], rowData[2], rowData[3], rowData[4]
                    );
                    view.showUserDetails(userDetails);
                } else {
                    view.showMessageDialog(getLocalizedMessage("selectUser"));
                }
            }
        });
    }

    public void addUser() {
        int userId = getUserId();
        String username = getUserName();
        String rol = getRol();
        String parola = getPassword();
        int idMagazin = getIdMagazin();

        Request request = new Request(Request.Type.ADD_USER, new Object[]{userId, username, parola, rol, idMagazin});
        Response response = client.sendRequest(request);

        if (response != null && response.isSuccess()) {
            view.showMessageDialog(getLocalizedMessage("userSuccess"));
            displayUserList();
        } else {
            view.showMessageDialog(getLocalizedMessage("userFailed"));
        }
    }


    public void updateUser() {
        int selectedUserId = getSelectedUserId();

        if (selectedUserId == -1) {
            view.showMessageDialog(getLocalizedMessage("selectUser"));
            return;
        }

        int userId = getUserId();
        String username = getUserName();
        String rol = getRol();
        String parola = getPassword();
        int idMagazin = getIdMagazin();

        Request request = new Request(Request.Type.UPDATE_USER, new Object[]{userId, username, parola, rol, idMagazin});
        Response response = client.sendRequest(request);

        if (response != null && response.isSuccess()) {
            view.showMessageDialog(getLocalizedMessage("updateUser"));
            displayUserList();
        } else {
            view.showMessageDialog(getLocalizedMessage("failedUpdate"));
        }
    }


    public void deleteUser() {
        int selectedUserId = getSelectedUserId();

        if (selectedUserId == -1) {
            view.showMessageDialog(getLocalizedMessage("selectUser"));
            return;
        }

        Request request = new Request(Request.Type.DELETE_USER, selectedUserId);
        Response response = client.sendRequest(request);

        if (response != null && response.isSuccess()) {
            view.showMessageDialog(getLocalizedMessage("deleteSuccess"));
            displayUserList();
        } else {
            view.showMessageDialog(getLocalizedMessage("failedDelete"));
        }
    }


    public void displayUserList() {
        Request request = new Request(Request.Type.DISPLAY_USER_LIST, null);
        Response response = client.sendRequest(request);

        if (response != null && response.isSuccess()) {
            Object[][] users = (Object[][]) response.getData();
            view.displayUsers(users);
        } else {
            view.showMessageDialog(getLocalizedMessage("failedDisplay"));
        }
    }





}
