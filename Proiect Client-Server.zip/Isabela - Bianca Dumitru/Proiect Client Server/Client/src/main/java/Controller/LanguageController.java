package Controller;
import Model.Language;
import java.util.ResourceBundle;
import java.util.Locale;

public class LanguageController {
    private Language language;
    public LanguageController() {
        this.language = new Language();
        this.language.setCurrentLocale(new Locale("ro", "RO"));
    }
    public Locale getCurrentLocale() {
        return language.getCurrentLocale();
    }

    public void changeLanguage(String languageCode) {
        Locale locale = new Locale(languageCode);
        language.setCurrentLocale(locale);
        language.notifyObservers();
    }
    public ResourceBundle getResourceBundle() {
        return language.getResourceBundle();
    }
}
