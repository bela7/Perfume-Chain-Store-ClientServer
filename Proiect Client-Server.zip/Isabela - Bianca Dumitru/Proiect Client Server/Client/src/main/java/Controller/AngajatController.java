package Controller;

import View.AngajatView;
import Common.Request;
import Common.Response;
import Client.Client;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;



public class AngajatController {
    private AngajatView view;
    private LanguageController languageController;
    private Client client;
    private int idMagazin;



    public AngajatController(Client client) {
        this.languageController = new LanguageController();
        this.client = client;
    }

    public void setView(AngajatView view) {
        this.view = view;
        setupListeners();
    }

    private void changeLanguage(Locale locale) {
        languageController.changeLanguage(locale.getLanguage());
        view.updateResourceBundle(languageController.getCurrentLocale());
        updateUIComponents();
        displayProducators();
        displayParfumList();
    }



    public void showView(String user, int idMagazin) {
        this.idMagazin=idMagazin;
        view = new AngajatView(user,idMagazin);
        setView(view);
        view.setVisible(true);
        view.setTitle("Angajat - " + user);
        view.getBtnRomanian().addActionListener(e -> changeLanguage(new Locale("ro", "RO")));
        view.getBtnEnglish().addActionListener(e -> changeLanguage(Locale.ENGLISH));
        view.getBtnFrench().addActionListener(e -> changeLanguage(Locale.FRENCH));
        view.getBtnSpanish().addActionListener(e -> changeLanguage(new Locale("es", "ES")));
        displayMagazinNames();
        updateComboBoxSortarePret();
        updateComboBoxSortareNume();
        displayParfumList();
        displayProducators();
    }


    private void updateUIComponents() {
        ResourceBundle rb = view.getResourceBundle();

        view.setTitle(rb.getString("angajatTitle"));
        view.getLblIdParfum().setText(rb.getString("idParfumLabel"));
        view.getLblStoc().setText(rb.getString("stocLabel"));
        view.getBtnAdaugaParfum().setText(rb.getString("adaugaParfumButton"));
        view.getBtnActualizeazaParfum().setText(rb.getString("actualizeazaParfumButton"));
        view.getBtnViewDetails().setText(rb.getString("vizualizeazaDetaliileButton"));
        view.getBtnStergeParfum().setText(rb.getString("stergeParfumButton"));
        view.getBtnAdaugaParfumNou().setText(rb.getString("adaugaParfumNouButton"));
        view.getBtnFiltreaza().setText(rb.getString("filtreazaButton"));
        view.getLblPretMinim().setText(rb.getString("pretMinimLabel"));
        view.getLblPretMaxim().setText(rb.getString("pretMaximLabel"));
        view.getLblProducator().setText(rb.getString("producatorLabel"));
        view.getLblDisponibilitate().setText(rb.getString("disponibilitateLabel"));
        view.getChckbxDisponibil().setText(rb.getString("disponibilCheckbox"));
        view.getBtnCauta().setText(rb.getString("cautaButton"));
        view.getLblMagazin().setText(rb.getString("magazin"));
        view.getLblSortareNume().setText(rb.getString("sortareNume"));
        view.getLblSortarePret().setText(rb.getString("sortarePret"));
        view.getLblCautaDupaNume().setText(rb.getString("cautaNume"));


        String[] columnNames = new String[] {
                rb.getString("idParfumLabel"),
                rb.getString("denumireLabel"),
                rb.getString("producatorLabel"),
                rb.getString("pretLabel"),
                rb.getString("descriereLabel"),
                rb.getString("stocLabel")
        };
        DefaultTableModel model = (DefaultTableModel) view.getTable().getModel();
        displayMagazinNames();
        updateComboBoxSortarePret();
        updateComboBoxSortareNume();
        model.setColumnIdentifiers(columnNames);
        updateAddParfumFrameLabels();
        displayParfumList();

    }


    private void updateAddParfumFrameLabels() {
        ResourceBundle rb = view.getResourceBundle();

        view.getAddParfumFrame().setTitle(rb.getString("adaugaParfumNouButton"));

        JLabel lblIdParfumAdd = view.getLblIdParfumAdd();
        if (lblIdParfumAdd != null) {
            lblIdParfumAdd.setText(rb.getString("idParfumLabel"));
        }

        JLabel lblNumeAdd = view.getLblNumeAdd();
        if (lblNumeAdd != null) {
            lblNumeAdd.setText(rb.getString("denumireLabel"));
        }

        JLabel lblProducatorAdd = view.getLblProducatorAdd();
        if (lblProducatorAdd != null) {
            lblProducatorAdd.setText(rb.getString("producatorLabel"));
        }

        JLabel lblPretAdd = view.getLblPretAdd();
        if (lblPretAdd != null) {
            lblPretAdd.setText(rb.getString("pretLabel"));
        }

        JLabel lblDescriereAdd = view.getLblDescriereAdd();
        if (lblDescriereAdd != null) {
            lblDescriereAdd.setText(rb.getString("descriereLabel"));
        }

        JLabel lblStocAdd = view.getLblStocAdd();
        if (lblStocAdd != null) {
            lblStocAdd.setText(rb.getString("stocLabel"));
        }

        JButton btnSubmit = view.getBtnSubmit();
        if (btnSubmit != null) {
            btnSubmit.setText(rb.getString("adaugaParfumNouButton"));
        }

        JFrame addParfumFrame = view.getAddParfumFrame();
        if (addParfumFrame != null) {
            addParfumFrame.revalidate();
            addParfumFrame.repaint();
        }
    }



    private void setupListeners() {

        view.getBtnAdaugaParfum().addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                addParfum();
            }
        });


        view.getBtnActualizeazaParfum().addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                updateParfum();
            }
        });

        view.getBtnStergeParfum().addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                deleteParfum();
            }
        });

        view.getBtnViewDetails().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = view.getTable().getSelectedRow();
                if (selectedRow != -1) {
                    Object[] rowData = view.getRowData(view.getTable(), selectedRow);
                    String[] formattedDetails = getFormattedPerfumeDetails(rowData);
                    view.showPerfumeDetails(formattedDetails[0], formattedDetails[1]);
                } else {
                    view.showMessageDialog(getLocalizedMessage("notSelectedParfumMessage"));
                }
            }
        });


        view.getBtnAdaugaParfumNou().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                view.showAddParfumFrame();
                updateAddParfumFrameLabels();
                addSubmitButtonListener();
            }
        });


        view.getBtnFiltreaza().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.out.println("Button Filtreaza clicked");
                handleFilterParfums();
            }
        });


        view.getComboBoxSortareNume().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleSortParfumsByName();
            }
        });

        view.getComboBoxSortarePret().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleSortParfumsByPrice();
            }
        });

        view.getBtnCauta().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleSearchParfumByName();
            }
        });

        view.getComboBoxMagazin().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                displayParfumList();
            }
        });



    }

    public void addSubmitButtonListener() {
        if (view.getBtnSubmit() != null) {
            view.getBtnSubmit().addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                        addNewParfum();
                        view.disposeAddParfumFrame();
                }
            });
        }
    }

    public String getSelectedProducator() {
        JComboBox<String> comboBoxProducator = view.getComboBoxProducator();
        if (comboBoxProducator.getSelectedIndex() > 0) {
            return (String) comboBoxProducator.getSelectedItem();
        }
        return "";
    }


    public void updateComboBoxSortarePret() {
        JComboBox<String> comboBoxSortarePret = view.getComboBoxSortarePret();
        ActionListener[] listeners = comboBoxSortarePret.getActionListeners();
        for (ActionListener listener : listeners) {
            comboBoxSortarePret.removeActionListener(listener);
        }
        comboBoxSortarePret.removeAllItems();

        ResourceBundle rb = view.getResourceBundle();
        if (rb == null) {
            rb = ResourceBundle.getBundle("LanguageBundle", view.getLocale());
        }

        comboBoxSortarePret.addItem(rb.getString("crescator"));
        comboBoxSortarePret.addItem(rb.getString("descrescator"));

        for (ActionListener listener : listeners) {
            comboBoxSortarePret.addActionListener(listener);
        }
    }

    public void updateComboBoxSortareNume() {
        JComboBox<String> comboBoxSortareNume = view.getComboBoxSortareNume();
        ActionListener[] listeners = comboBoxSortareNume.getActionListeners();
        for (ActionListener listener : listeners) {
            comboBoxSortareNume.removeActionListener(listener);
        }
        comboBoxSortareNume.removeAllItems();

        ResourceBundle rb = view.getResourceBundle();
        if (rb == null) {
            rb = ResourceBundle.getBundle("LanguageBundle", view.getLocale());
        }

        comboBoxSortareNume.addItem(rb.getString("crescator"));
        comboBoxSortareNume.addItem(rb.getString("descrescator"));

        for (ActionListener listener : listeners) {
            comboBoxSortareNume.addActionListener(listener);
        }
    }

    public String[] getFormattedPerfumeDetails(Object[] rowData) {
        ResourceBundle rb = view.getResourceBundle();
        String title = rb.getString("detaliiParfumTitle");
        String details = String.format(
                "%s: %s\n%s: %s\n%s: %s\n%s: %s\n%s: %s\n%s: %s",
                rb.getString("idParfumLabel"), rowData[0],
                rb.getString("denumireLabel"), rowData[1],
                rb.getString("producatorLabel"), rowData[2],
                rb.getString("pretLabel"), rowData[3],
                rb.getString("descriereLabel"), rowData[4],
                rb.getString("stocLabel"), rowData[5]
        );
        return new String[]{title, details};
    }



    public int getIdParfum() {
        try {
            return Integer.parseInt(view.getTextFieldIdParfum().getText());
        } catch (NumberFormatException e) {
            return -1;
        }
    }


    public int getStoc() {
        try {
            return Integer.parseInt(view.getTextFieldStoc().getText());
        } catch (NumberFormatException e) {
            return -1;
        }
    }


    public int getNewIdParfum() {
        return Integer.parseInt(view.getTxtIdParfum().getText());
    }

    public String getNewNume() {
        return view.getTxtNume().getText();
    }

    public String getNewProducator() {
        return view.getTxtProducator().getText();
    }


    public double getNewPret() {
        return Double.parseDouble(view.getTxtPret().getText());
    }


    public String getNewDescriere() {
        return view.getTxtDescriere().getText();
    }


    public int getNewStoc() {
        return Integer.parseInt(view.getTxtStoc().getText());
    }


    public String getPriceMin() {
        return view.getTextFieldPretMin().getText().trim();
    }


    public String getEnteredParfumName() { return view.getTextFieldCautaDupaNume().getText(); }


    public String getPriceMax() {
        return view.getTextFieldPretMax().getText().trim();
    }

    public int getSelectedParfumId() {
        int selectedRow = view.getTable().getSelectedRow();
        if (selectedRow != -1) {
            return Integer.parseInt(view.getTable().getValueAt(selectedRow, 0).toString());
        } else {
            return -1;
        }
    }
    public boolean isDisponibilSelected() {
        JCheckBox chckbxDisponibil = view.getChckbxDisponibil();
        return chckbxDisponibil.isSelected();
    }

    public void handleFilterParfums() {
        Double priceMin = null;
        Double priceMax = null;
        String producator = null;
        Boolean disponibil = null;

        String priceMinText = getPriceMin();
        String priceMaxText = getPriceMax();
        JComboBox<String> comboBoxMagazin = view.getComboBoxMagazin();
        String selectedMagazinName = (String) comboBoxMagazin.getSelectedItem();
        int idMagazin = getMagazinIdByName(selectedMagazinName);

        if (!priceMinText.isEmpty()) {
            priceMin = Double.parseDouble(priceMinText);
        }

        if (!priceMaxText.isEmpty()) {
            priceMax = Double.parseDouble(priceMaxText);
        }

        if (!getSelectedProducator().isEmpty()) {
            producator = getSelectedProducator();
        }

        if (isDisponibilSelected()) {
            disponibil = isDisponibilSelected();
        }

        Locale currentLocale = view.getLocale();
        String language = currentLocale.getLanguage();

        Object[] requestData = new Object[]{idMagazin, priceMin, priceMax, producator, disponibil, language};
        Request request = new Request(Request.Type.FILTER_PARFUMS, requestData);
        Response response = client.sendRequest(request);

        if (response != null && response.isSuccess()) {
            @SuppressWarnings("unchecked")
            List<Object[]> filteredParfums = (List<Object[]>) response.getData();
            updateParfumList(filteredParfums);
        } else {
            view.showMessageDialog(getLocalizedMessage("failedDisplay"));
        }
    }

    public String getLocalizedMessage(String key) {
        ResourceBundle rb = view.getResourceBundle();
        return rb.getString(key);
    }

    public void displayMagazinNames() {
        Request request = new Request(Request.Type.GET_ALL_MAGAZIN_NAMES, null);
        Response response = client.sendRequest(request);

        if (response != null && response.isSuccess()) {
            List<String> magazinNames = (List<String>) response.getData();
            JComboBox<String> comboBoxMagazin = view.getComboBoxMagazin();
            comboBoxMagazin.removeAllItems();

            for (String magazinName : magazinNames) {
                comboBoxMagazin.addItem(magazinName);
            }
            displayParfumList();
        }
    }

    public void addNewParfum() {
        System.out.println("addNewParfum called");
        int idParfum = getNewIdParfum();
        String nume = getNewNume();
        String producator = getNewProducator();
        double pret = getNewPret();
        String descriere = getNewDescriere();
        int stoc = getNewStoc();

        if (idParfum != -1 && pret != -1 && stoc != -1 && !nume.isEmpty() && !producator.isEmpty() && !descriere.isEmpty()) {
            Request request = new Request(Request.Type.ADD_PARFUM_NEW, new Object[]{idParfum, nume, producator, pret, descriere, stoc, idMagazin});
            Response response = client.sendRequest(request);

            if (response != null && response.isSuccess()) {
                System.out.println("Parfum added successfully");
                view.showMessageDialog(getLocalizedMessage("parfumAddedSuccessMessage"));
                displayParfumList();
            } else {
                System.out.println("Failed to add parfum");
                view.showMessageDialog(getLocalizedMessage("failedToAddParfumMessage"));
            }
        } else {
            System.out.println("Invalid parfum data");
        }
    }

    public void addParfum() {
        System.out.println("addParfum called");
        int idParfum = getIdParfum();
        int stoc = getStoc();

        if (idParfum != -1 && stoc != -1) {
            Request request = new Request(Request.Type.ADD_PARFUM, new Object[]{idParfum, stoc, idMagazin});
            Response response = client.sendRequest(request);

            if (response != null && response.isSuccess()) {
                view.showMessageDialog(getLocalizedMessage("parfumAddedSuccessMessage"));
                displayParfumList();
            } else {
                view.showMessageDialog(getLocalizedMessage("failedToAddParfumMessage"));
            }
        } else {
            view.showMessageDialog(getLocalizedMessage("stocInvalid"));
        }
    }

    public void updateParfum() {
        int idParfum = getIdParfum();
        int stoc = getStoc();

        if (idParfum != -1 && stoc != -1) {
            Request request = new Request(Request.Type.UPDATE_PARFUM, new Object[]{idParfum, stoc, idMagazin});
            Response response = client.sendRequest(request);

            if (response != null && response.isSuccess()) {
                view.showMessageDialog(getLocalizedMessage("parfumUpdatedSuccessMessage"));
                displayParfumList();
            } else {
                view.showMessageDialog(getLocalizedMessage("failedToUpdateParfumMessage"));
            }
        } else {
            view.showMessageDialog(getLocalizedMessage("stocInvalid"));
        }
    }

    public void deleteParfum() {
        int selectedParfumId = getSelectedParfumId();

        if (selectedParfumId == -1) {
            view.showMessageDialog(getLocalizedMessage("notSelectedParfumMessage"));
            return;
        }

        Request request = new Request(Request.Type.DELETE_PARFUM, new Object[]{selectedParfumId, idMagazin});
        Response response = client.sendRequest(request);

        if (response != null && response.isSuccess()) {
            view.showMessageDialog(getLocalizedMessage("parfumDeletedSuccessMessage"));
            displayParfumList();
        } else {
            view.showMessageDialog(getLocalizedMessage("failedToDeleteParfumMessage"));
        }
    }

    public void displayParfumList() {
        String language;
        Locale currentLocale = languageController.getCurrentLocale();
        JComboBox<String> comboBoxMagazin = view.getComboBoxMagazin();
        String selectedMagazinName = (String) comboBoxMagazin.getSelectedItem();
        int idMagazin = getMagazinIdByName(selectedMagazinName);

        if (currentLocale == null) {
            language = "ro";
        } else {
            language = currentLocale.getLanguage();
        }

        Object[] requestData = new Object[]{idMagazin, language};
        Request request = new Request(Request.Type.GET_ALL_PARFUMURI_FOR_MAGAZIN, requestData);
        Response response = client.sendRequest(request);

        if (response != null && response.isSuccess()) {
            @SuppressWarnings("unchecked")
            List<Object[]> parfumuriMagazinAsObjects = (List<Object[]>) response.getData();
            Object[][] parfumList = new Object[parfumuriMagazinAsObjects.size()][6];
            for (int i = 0; i < parfumuriMagazinAsObjects.size(); i++) {
                Object[] parfumData = parfumuriMagazinAsObjects.get(i);
                parfumList[i] = parfumData;
            }
            view.displayParfumList(parfumList);
        } else {
            view.showMessageDialog(getLocalizedMessage("failedDisplay"));
        }
    }



    public boolean isSortByPriceAscending() {
        JComboBox<String> comboBoxSortarePret = view.getComboBoxSortarePret();
        return comboBoxSortarePret.getSelectedItem().equals("Crescător");
    }

    public boolean isSortByNameAscending() {
        JComboBox<String> comboBoxSortareNume = view.getComboBoxSortareNume();
        String selectedItem = (String) comboBoxSortareNume.getSelectedItem();
        if (selectedItem == null) {
            return true;
        }
        return selectedItem.equals(view.getResourceBundle().getString("crescator"));
    }

    public void handleSortParfumsByName() {
        boolean ascending = isSortByNameAscending();
        JComboBox<String> comboBoxMagazin = view.getComboBoxMagazin();
        String selectedMagazinName = (String) comboBoxMagazin.getSelectedItem();
        int idMagazin = getMagazinIdByName(selectedMagazinName);

        Locale currentLocale = view.getLocale();
        String language;
        if (currentLocale == null) {
            language = "ro";
        } else {
            language = currentLocale.getLanguage();
        }

        Object[] requestData = new Object[]{idMagazin, ascending, language};
        Request request = new Request(Request.Type.SORT_PARFUMS_BY_NAME, requestData);
        Response response = client.sendRequest(request);

        if (response != null && response.isSuccess()) {
            @SuppressWarnings("unchecked")
            List<Object[]> sortedParfumsObject = (List<Object[]>) response.getData();
            updateParfumList(sortedParfumsObject);
        } else {
            view.showMessageDialog(getLocalizedMessage("failedDisplay"));
        }
    }

    public void handleSortParfumsByPrice() {
        boolean ascending = isSortByPriceAscending();
        JComboBox<String> comboBoxMagazin = view.getComboBoxMagazin();
        String selectedMagazinName = (String) comboBoxMagazin.getSelectedItem();
        int idMagazin = getMagazinIdByName(selectedMagazinName);

        Locale currentLocale = view.getLocale();
        String language;
        if (currentLocale == null) {
            language = "ro";
        } else {
            language = currentLocale.getLanguage();
        }

        Object[] requestData = new Object[]{idMagazin, ascending, language};
        Request request = new Request(Request.Type.SORT_PARFUMS_BY_PRICE, requestData);
        Response response = client.sendRequest(request);

        if (response != null && response.isSuccess()) {
            @SuppressWarnings("unchecked")
            List<Object[]> sortedParfumsObject = (List<Object[]>) response.getData();
            updateParfumList(sortedParfumsObject);
        } else {
            view.showMessageDialog(getLocalizedMessage("failedDisplay"));
        }
    }


    public void handleSearchParfumByName() {
        String parfumName = getEnteredParfumName();
        Object[] requestData = new Object[]{parfumName};
        Request request = new Request(Request.Type.SEARCH_PARFUM_BY_NAME, requestData);
        Response response = client.sendRequest(request);

        if (response != null && response.isSuccess()) {
            String parfumDetails = (String) response.getData();
            view.showPerfumeDetailsByName(parfumDetails);
        } else {
            view.showMessageDialog(getLocalizedMessage("notFound"));
        }
    }

    public void displayProducators() {
        JComboBox<String> comboBoxMagazin = view.getComboBoxMagazin();
        String selectedMagazinName = (String) comboBoxMagazin.getSelectedItem();
        int idMagazin = getMagazinIdByName(selectedMagazinName);

        Request request = new Request(Request.Type.GET_ALL_PRODUCATORS, idMagazin);
        Response response = client.sendRequest(request);

        if (response != null && response.isSuccess()) {
            @SuppressWarnings("unchecked")
            List<String> producators = (List<String>) response.getData();
            updateProducatorComboBox(producators);
            displayParfumList();
        } else {
            view.showMessageDialog(getLocalizedMessage("failedDisplay"));
        }
    }

    public int getMagazinIdByName(String selectedMagazinName) {
        Object[] requestData = new Object[]{selectedMagazinName};
        Request request = new Request(Request.Type.GET_MAGAZIN_ID_BY_NAME, requestData);
        Response response = client.sendRequest(request);

        if (response != null && response.isSuccess()) {
            return (int) response.getData();
        } else {
            return -1;
        }
    }


    private void updateProducatorComboBox(List<String> producators) {
        JComboBox<String> comboBoxProducator = view.getComboBoxProducator();
        comboBoxProducator.removeAllItems();

        ResourceBundle rb = view.getResourceBundle();
        if (rb == null) {
            Locale romanianLocale = new Locale("ro", "RO");
            rb = ResourceBundle.getBundle("LanguageBundle", romanianLocale);
        }

        comboBoxProducator.addItem(rb.getString("totiProducatorii"));

        for (String producator : producators) {
            comboBoxProducator.addItem(producator);
        }
    }




    private void updateParfumList(List<Object[]> objectList) {
        Object[][] parfumList = new Object[objectList.size()][6];
        for (int i = 0; i < objectList.size(); i++) {
            Object[] obj = objectList.get(i);
            parfumList[i][0] = obj[0]; // idParfum
            parfumList[i][1] = obj[1]; // nume
            parfumList[i][2] = obj[2]; // producator
            parfumList[i][3] = obj[3]; // pret
            parfumList[i][4] = obj[4]; // translated_descriere
            parfumList[i][5] = obj[5]; // stoc
        }

        view.displayParfumList(parfumList);
    }


}

