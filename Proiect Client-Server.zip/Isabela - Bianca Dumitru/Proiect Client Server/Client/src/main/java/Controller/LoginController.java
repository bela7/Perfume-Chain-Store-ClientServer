package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import View.LoginView;
import Model.Language;
import Client.Client;
import Common.Request;
import Common.Response;
import java.util.Locale;
import java.util.ResourceBundle;

public class LoginController {
    private LoginView view;
    private LanguageController languageController;
    private Client client;

    public LoginController(Language language, Client client) {
        this.client = client;
        Locale currentLocale = language.getCurrentLocale();
        this.view = new LoginView(currentLocale);
        this.languageController = new LanguageController();

        view.getBtnRomanian().addActionListener(e -> changeLanguage(Locale.forLanguageTag("ro-RO")));
        view.getBtnEnglish().addActionListener(e -> changeLanguage(Locale.forLanguageTag("en-US")));
        view.getBtnFrench().addActionListener(e -> changeLanguage(Locale.FRENCH));
        view.getBtnSpanish().addActionListener(e -> changeLanguage(Locale.forLanguageTag("es-ES")));

        view.getBtnLogin().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                autentificare();
            }
        });

        view.getBtnCancel().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                view.dispose();
            }
        });

    }


    public void initialize() {
        view.setVisible(true);
    }

    public void autentificare() {
        String user = view.getUser().getText();
        String parola = String.valueOf(view.getPassword().getPassword());

        Request request = new Request(Request.Type.LOGIN, new String[]{user, parola});
        Response response = client.sendRequest(request);

        if (response != null && response.isSuccess()) {
            String rol = response.getRole();
            int idMagazin = response.getIdMagazin();

            if (rol.equalsIgnoreCase("administrator")) {
                AdministratorController adminController = new AdministratorController(client);
                adminController.showView(user);
            } else if (rol.equalsIgnoreCase("manager")) {
                ManagerController managerController = new ManagerController(client);
                managerController.showView(user);
            } else if (rol.equalsIgnoreCase("angajat")) {
                AngajatController angajatController = new AngajatController(client);;
                angajatController.showView(user, idMagazin);
            }
        } else {
            view.mesajEroare();
        }
    }

    private void changeLanguage(Locale locale) {
        languageController.changeLanguage(locale.getLanguage());
        view.updateResourceBundle(languageController.getCurrentLocale());
        updateUIComponents();
    }

    private void updateUIComponents() {
        ResourceBundle rb = view.getResourceBundle();

        // Update labels, buttons, etc. with new language strings
        view.setTitle(rb.getString("loginTitle"));
        view.getLbUser().setText(rb.getString("usernameLabel"));
        view.getLbPassword().setText(rb.getString("passwordLabel"));
        view.getBtnLogin().setText(rb.getString("loginButton"));
        view.getBtnCancel().setText(rb.getString("cancelButton"));
    }
}
