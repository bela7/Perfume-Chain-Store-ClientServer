package Model;

import java.util.Locale;
import java.util.Observable;
import java.util.ResourceBundle;

public class Language extends Observable {
    private Locale currentLocale;
    private ResourceBundle resourceBundle;
    public Language() {
        currentLocale = Locale.getDefault();
    }

    public Language(Locale initialLocale) {
        this.currentLocale = initialLocale;
    }

    public Locale getCurrentLocale() {
        return currentLocale;
    }

    public void setCurrentLocale(Locale locale) {
        this.currentLocale = locale;
        setChanged();
        notifyObservers(locale);
    }

    public ResourceBundle getResourceBundle() {
        return resourceBundle;
    }
}
