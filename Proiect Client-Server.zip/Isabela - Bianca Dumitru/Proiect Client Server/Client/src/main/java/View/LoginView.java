package View;

import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.*;

import java.util.ResourceBundle;
import java.util.Locale;


public class LoginView extends JFrame {
    final private Font mainFont = new Font("Segoe Print", Font.BOLD, 36);
    final private Font font1 = new Font("Segoe Print", Font.BOLD, 22);
    final private Font font3 = new Font("Segoe Print", Font.BOLD, 14);
    final private Font font2 = new Font("Times New Roman", Font.BOLD, 16);
    private JTextField user;
    private JPasswordField password;
    private JButton btnLogin;
    private JButton btnCancel;
    private JLabel lbUser;
    private JLabel lbPassword;
    Image backgroundImage;

    private ResourceBundle resourceBundle;
    private JButton btnEnglish;
    private JButton btnRomanian;
    private JButton btnFrench;
    private JButton btnSpanish;

    private JPanel createLanguageButtonsPanel() {

        btnEnglish = new JButton("EN");
        btnRomanian = new JButton("RO");
        btnFrench = new JButton("FR");
        btnSpanish = new JButton("ES");
        Font buttonFont = new Font("Times New Roman", Font.BOLD, 13);
        btnEnglish.setFont(buttonFont);
        btnRomanian.setFont(buttonFont);
        btnFrench.setFont(buttonFont);
        btnSpanish.setFont(buttonFont);

        JPanel languageButtonsPanel = new JPanel();
        languageButtonsPanel.setLayout(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        languageButtonsPanel.setPreferredSize(new Dimension(800, 50));
        languageButtonsPanel.setBackground(Color.BLACK);

        btnEnglish.setPreferredSize(new Dimension(55, 30));
        btnRomanian.setPreferredSize(new Dimension(55, 30));
        btnFrench.setPreferredSize(new Dimension(55, 30));
        btnSpanish.setPreferredSize(new Dimension(55, 30));

        languageButtonsPanel.add(btnRomanian);
        languageButtonsPanel.add(btnEnglish);
        languageButtonsPanel.add(btnFrench);
        languageButtonsPanel.add(btnSpanish);

        return languageButtonsPanel;
    }

    public LoginView(Locale locale) {
        updateResourceBundle(locale);
        try {
            File file = new File("D:\\CSC\\2ndSemester\\PS\\Lab\\Tema2\\MVC\\background3.jpg");
            backgroundImage = ImageIO.read(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
        initialize();
    }
    public ResourceBundle getResourceBundle() {
        return resourceBundle;
    }

    public void updateResourceBundle(Locale locale) {
        resourceBundle = ResourceBundle.getBundle("LanguageBundle", locale);
    }

    private void initialize () {
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);

        JLabel lbLoginForm = new JLabel("SEPHORA", SwingConstants.CENTER);
        lbLoginForm.setFont(mainFont);
        lbLoginForm.setForeground(Color.WHITE);

        JPanel headerPanel = new JPanel();
        headerPanel.setPreferredSize(new Dimension(800, 80));
        headerPanel.setBackground(Color.BLACK);
        headerPanel.setLayout(new BorderLayout());
        headerPanel.add(lbLoginForm, BorderLayout.SOUTH);

        JPanel combinedHeaderPanel = new JPanel(new BorderLayout());
        combinedHeaderPanel.add(headerPanel, BorderLayout.NORTH);
        combinedHeaderPanel.add(createLanguageButtonsPanel(), BorderLayout.SOUTH);

        lbUser = new JLabel("Utilizator");
        lbUser.setFont(font1);

        lbPassword = new JLabel("Parola");
        lbPassword.setFont(font1);

        // Create the text fields
        user = new JTextField();
        user.setFont(font3);
        user.setOpaque(false);
        user.setPreferredSize(new Dimension(100, 20));

        password = new JPasswordField();
        password.setFont(font3);
        password.setOpaque(false);
        password.setPreferredSize(new Dimension(150, 30));

        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(0, 1, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(100, 280, 50, 280));
        formPanel.add(lbUser);
        formPanel.add(user);
        formPanel.add(lbPassword);
        formPanel.add(password);
        formPanel.setOpaque(false);

        /*************** Buttons Panel ***************/

        btnLogin = new JButton("autentificare");
        btnLogin.setFont(font2);

        btnCancel = new JButton("anulare");
        btnCancel.setFont(font2);

        JPanel buttonsPanel = new JPanel();
        buttonsPanel.setLayout(new GridLayout(1, 2, 30, 30));
        buttonsPanel.setBorder(BorderFactory.createEmptyBorder(0, 280, 100, 280));
        buttonsPanel.add(btnLogin);
        buttonsPanel.add(btnCancel);
        buttonsPanel.setOpaque(false);

        /*************** Initialise the frame ***************/
        getContentPane().setBackground(Color.BLACK);
        setLayout(new BorderLayout());

        // Add the background image
        ImageIcon imageIcon = new ImageIcon(backgroundImage);
        JLabel backgroundLabel = new JLabel(imageIcon);
        backgroundLabel.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                Image image = imageIcon.getImage().getScaledInstance(backgroundLabel.getWidth(), backgroundLabel.getHeight(), Image.SCALE_SMOOTH);
                backgroundLabel.setIcon(new ImageIcon(image));
            }
        });
        add(backgroundLabel);

        // Create a transparent panel to hold the form panel and buttons panel
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BorderLayout());
        contentPanel.setOpaque(false);

        // Add the form panel and buttons panel to the content panel
        contentPanel.add(formPanel, BorderLayout.CENTER);
        contentPanel.add(buttonsPanel, BorderLayout.SOUTH);

        // Add the content panel on top of the background image
        backgroundLabel.setLayout(new BorderLayout());
        backgroundLabel.add(contentPanel);

        add(combinedHeaderPanel, BorderLayout.NORTH);
        setTitle("Autentificare");

        setSize(850, 700);
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
    }


    public JButton getBtnEnglish() {
        return btnEnglish;
    }

    public JButton getBtnRomanian() {
        return btnRomanian;
    }

    public JButton getBtnFrench() {
        return btnFrench;
    }

    public JButton getBtnSpanish() {
        return btnSpanish;
    }

    public JButton getBtnLogin() {
        return btnLogin;
    }

    public JButton getBtnCancel() {
        return btnCancel;
    }

    public JTextField getUser() {
        return user;
    }

    public JPasswordField getPassword() {
        return password;
    }

    public JLabel getLbUser() {
        return lbUser;
    }

    public JLabel getLbPassword() {
        return lbPassword;
    }



    public void mesajEroare() {
        JOptionPane.showMessageDialog(LoginView.this,
                "Utilizator sau parola invalidă",
                "Încearcă din nou",
                JOptionPane.ERROR_MESSAGE);

    }





}

