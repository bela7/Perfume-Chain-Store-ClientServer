package View;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Locale;
import java.util.ResourceBundle;

public class AngajatView extends JFrame  {
    private JTable table;
    private JTextField textFieldIdParfum;
    private JTextField textFieldStoc;
    private JTextField textFieldPretMin;
    private JTextField textFieldPretMax;
    private JComboBox<String> comboBoxProducator;
    private JCheckBox chckbxDisponibil;
    private JButton btnAdaugaParfum;
    private JButton btnActualizeazaParfum;
    private JButton btnStergeParfum;
    private JButton btnFiltreaza;
    private JButton btnViewDetails;

    private JButton btnSubmit;
    private JButton btnAdaugaParfumNou;
    private JLabel lblPretMinim;
    private JLabel lblPretMaxim;
    private JLabel lblProducator;
    private JLabel lblDisponibilitate;
    private JTextField txtIdParfum;
    private JTextField txtNume;
    private JTextField txtProducator;
    private JTextField txtPret;
    private JTextArea txtDescriere;
    private JTextField txtStoc;
    private JFrame addParfumFrame;
    private JLabel lblIdParfum;
    private JLabel lblStoc;
    private JTextArea area;
    private JTextArea area1;
    private JTextArea textAreaParfumDetails;
    private JLabel lblIdParfumAdd;
    private JLabel lblNumeAdd;
    private JLabel lblStocAdd;
    private JLabel lblProducatorAdd;
    private JLabel lblPretAdd;
    private JLabel lblDescriereAdd;
    private ResourceBundle resourceBundle;
    private JButton btnEnglish;
    private JButton btnRomanian;
    private JButton btnFrench;
    private JButton btnSpanish;
    private Font mainFont = new Font("Segoe Print", Font.BOLD, 36);
    private int idMagazin;

    private JLabel lblSortareNume;
    private JLabel lblSortarePret;
    private JLabel lblCautaDupaNume;
    private JComboBox<String> comboBoxMagazin, comboBoxSortarePret, comboBoxSortareNume;
    private JLabel lblMagazin;
    private JButton btnCauta;
    private JTextField textFieldCautaDupaNume;

    private JPanel createLanguageButtonsPanel() {

        btnEnglish = new JButton("EN");
        btnRomanian = new JButton("RO");
        btnFrench = new JButton("FR");
        btnSpanish = new JButton("ES");
        Font buttonFont = new Font("Times New Roman", Font.BOLD, 13);
        btnEnglish.setFont(buttonFont);
        btnRomanian.setFont(buttonFont);
        btnFrench.setFont(buttonFont);
        btnSpanish.setFont(buttonFont);

        JPanel languageButtonsPanel = new JPanel();
        languageButtonsPanel.setLayout(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        languageButtonsPanel.setPreferredSize(new Dimension(800, 50));
        languageButtonsPanel.setBackground(Color.BLACK);

        btnEnglish.setPreferredSize(new Dimension(55, 30));
        btnRomanian.setPreferredSize(new Dimension(55, 30));
        btnFrench.setPreferredSize(new Dimension(55, 30));
        btnSpanish.setPreferredSize(new Dimension(55, 30));

        languageButtonsPanel.add(btnRomanian);
        languageButtonsPanel.add(btnEnglish);
        languageButtonsPanel.add(btnFrench);
        languageButtonsPanel.add(btnSpanish);

        return languageButtonsPanel;
    }
    public AngajatView(String user, int idMagazin) {
        this.idMagazin = idMagazin;

        setTitle("Angajat - " + user);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1100, 780);
        setLocationRelativeTo(null);


        Locale defaultLocale = new Locale("ro", "RO");
        resourceBundle = ResourceBundle.getBundle("LanguageBundle", defaultLocale);
        JLabel lbLoginForm = new JLabel("SEPHORA", SwingConstants.CENTER);
        lbLoginForm.setFont(mainFont);
        lbLoginForm.setForeground(Color.WHITE);
        JPanel headerPanel = new JPanel();
        headerPanel.setPreferredSize(new Dimension(1000, 80));
        headerPanel.setBackground(Color.BLACK);
        headerPanel.setLayout(new BorderLayout());
        headerPanel.add(lbLoginForm, BorderLayout.SOUTH);

        JPanel combinedHeaderPanel = new JPanel(new BorderLayout());
        combinedHeaderPanel.add(headerPanel, BorderLayout.NORTH);
        combinedHeaderPanel.add(createLanguageButtonsPanel(), BorderLayout.SOUTH);
        combinedHeaderPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        setLayout(new BorderLayout());
        add(combinedHeaderPanel, BorderLayout.NORTH);

        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(null);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(20, 0, 790, 460);
        contentPanel.add(scrollPane);
        table = new JTable();
        table.setRowHeight(30);
        table.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("Times New Roman", Font.BOLD, 16));

        table.setModel(new DefaultTableModel(
                new Object[][] {},
                new String[] {"Id Parfum", "Denumire", "Producător", "Pret", "Descriere", "Stoc"}
        ));

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        scrollPane.setViewportView(table);


        // First part
        lblIdParfum = new JLabel("ID Parfum:");
        lblIdParfum.setBounds(840, 0, 70, 20);
        contentPanel.add(lblIdParfum);
        textFieldIdParfum = new JTextField();
        textFieldIdParfum.setBounds(900, 0, 150, 20);
        contentPanel.add(textFieldIdParfum);
        textFieldIdParfum.setColumns(10);


        lblStoc = new JLabel("Stoc:");
        lblStoc.setBounds(840, 30, 70, 20);
        contentPanel.add(lblStoc);

        textFieldStoc = new JTextField();
        textFieldStoc.setBounds(900, 30, 150, 20);
        contentPanel.add(textFieldStoc);
        textFieldStoc.setColumns(10);

        btnAdaugaParfum = new JButton("Adauga Parfum");
        btnAdaugaParfum.setBounds(830, 60, 220, 23);
        contentPanel.add(btnAdaugaParfum);

        btnViewDetails = new JButton("Vizualizează detaliile unui parfum");
        btnViewDetails.setBounds(830, 140, 220, 23);
        contentPanel.add(btnViewDetails);


        btnActualizeazaParfum = new JButton("Actualizează Parfum");
        btnActualizeazaParfum.setBounds(830, 90, 220, 23);
        contentPanel.add(btnActualizeazaParfum);

        btnStergeParfum = new JButton("Șterge Parfum");
        btnStergeParfum.setBounds(830, 170, 210, 23);
        contentPanel.add(btnStergeParfum);

        lblPretMinim = new JLabel("Preț minim:");
        lblPretMinim.setBounds(840, 250, 100, 20);
        contentPanel.add(lblPretMinim);

        textFieldPretMin = new JTextField();
        textFieldPretMin.setBounds(930, 250, 100, 20);
        contentPanel.add(textFieldPretMin);
        textFieldPretMin.setColumns(10);


        lblPretMaxim = new JLabel("Pret maxim:");
        lblPretMaxim.setBounds(840, 290, 100, 20);
        contentPanel.add(lblPretMaxim);

        textFieldPretMax = new JTextField();
        textFieldPretMax.setBounds(930, 290, 100, 20);
        contentPanel.add(textFieldPretMax);
        textFieldPretMax.setColumns(10);

        lblProducator = new JLabel("Producător:");
        lblProducator.setBounds(840, 340, 100, 20);
        contentPanel.add(lblProducator);

        comboBoxProducator = new JComboBox<String>();
        comboBoxProducator.setBounds(900, 340, 150, 20);
        contentPanel.add(comboBoxProducator);

        lblDisponibilitate = new JLabel("Disponibilitate:");
        lblDisponibilitate.setBounds(840, 380, 100, 20);
        contentPanel.add(lblDisponibilitate);


        chckbxDisponibil = new JCheckBox("Disponibil");
        chckbxDisponibil.setBounds(850, 400, 100, 23);
        chckbxDisponibil.setBackground(Color.WHITE);
        contentPanel.add(chckbxDisponibil);

        btnFiltreaza = new JButton("Filtrează");
        btnFiltreaza.setBounds(880, 430, 120, 23);
        contentPanel.add(btnFiltreaza);

        area = new JTextArea();
        area.setBounds(820, 245, 250, 215);
        contentPanel.add(area);

        area1 = new JTextArea();
        area1.setBounds(820, 130, 250, 70);
        contentPanel.add(area1);

        textAreaParfumDetails= new JTextArea();
        textAreaParfumDetails.setBounds(820, 240, 250, 130);
        contentPanel.add(textAreaParfumDetails);

        btnAdaugaParfumNou = new JButton("Adauga parfum nou");

        btnAdaugaParfumNou.setBounds(830, 210, 220, 23);

        lblSortareNume = new JLabel("Sortare Nume");
        lblSortarePret = new JLabel("Sortare Pret");
        lblCautaDupaNume = new JLabel("Caută după nume");
        lblMagazin = new JLabel("Magazin");

        comboBoxMagazin = new JComboBox<String>();
        comboBoxSortarePret = new JComboBox<String>(new String[] {"Crescator", "Descrescator"});
        comboBoxSortareNume = new JComboBox<String>(new String[] {"Crescator", "Descrescator"});

        btnCauta = new JButton("Cauta");
        textFieldCautaDupaNume = new JTextField();

        JPanel panelBelowTable = new JPanel();
        panelBelowTable.setBackground(Color.WHITE);
        panelBelowTable.setBounds(20, 470, 790, 100);
        contentPanel.add(panelBelowTable);
        panelBelowTable.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();

// Set bigger font
        Font biggerFont = new Font("Times New Roman", Font.BOLD, 12);
        lblSortareNume.setFont(biggerFont);
        lblSortarePret.setFont(biggerFont);
        lblCautaDupaNume.setFont(biggerFont);
        lblMagazin.setFont(biggerFont);
        comboBoxMagazin.setFont(biggerFont);
        comboBoxSortarePret.setFont(biggerFont);
        comboBoxSortareNume.setFont(biggerFont);
        btnCauta.setFont(biggerFont);
        textFieldCautaDupaNume.setFont(biggerFont);

// Set row height
        gbc.ipady = 10;

// Set bigger spacing between rows and columns
        gbc.insets = new Insets(10, 2, 10, 4);

// First row
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        panelBelowTable.add(lblMagazin, gbc);

        gbc.gridx = 1;
        gbc.ipadx = 30;
        panelBelowTable.add(comboBoxMagazin, gbc);
        gbc.ipadx = 1;

        gbc.gridx = 2;
        gbc.gridwidth = 1;
        panelBelowTable.add(lblSortarePret, gbc);

        gbc.gridx = 3;
        panelBelowTable.add(comboBoxSortarePret, gbc);

        gbc.gridx = 4;
        panelBelowTable.add(lblSortareNume, gbc);

        gbc.gridx = 5;
        panelBelowTable.add(comboBoxSortareNume, gbc);

// Second row
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        panelBelowTable.add(lblCautaDupaNume, gbc);

        gbc.gridx = 1;
        gbc.ipadx = 150; // Increase width only for JTextField for Nume
        panelBelowTable.add(textFieldCautaDupaNume, gbc);
        gbc.ipadx = 1; // Reset ipadx to default

        gbc.gridx = 2;
        gbc.gridwidth = 1;
        panelBelowTable.add(btnCauta, gbc);


        contentPanel.add(btnAdaugaParfumNou);

        add(contentPanel, BorderLayout.CENTER);

        setVisible(true);
    }


    public JFrame getAddParfumFrame() {
        if (addParfumFrame == null) {
            addParfumFrame = new JFrame();
        }
        return addParfumFrame;
    }


    public void showAddParfumFrame() {
        addParfumFrame = new JFrame("Adaugă parfum nou");
        addParfumFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        addParfumFrame.setSize(400, 300);
        addParfumFrame.setLocationRelativeTo(null);
        addParfumFrame.setLayout(new GridLayout(0, 2));

        lblIdParfumAdd = new JLabel("IdParfum:");
        txtIdParfum = new JTextField();
        lblNumeAdd = new JLabel("Nume:");
        txtNume = new JTextField();
        lblProducatorAdd = new JLabel("Producator:");
        txtProducator = new JTextField();
        lblPretAdd = new JLabel("Pret:");
        txtPret = new JTextField();
        lblDescriereAdd = new JLabel("Descriere:");

        txtDescriere = new JTextArea();
        txtDescriere.setLineWrap(true);
        txtDescriere.setWrapStyleWord(true);
        JScrollPane scrollPaneDescriere = new JScrollPane(txtDescriere);
        scrollPaneDescriere.setPreferredSize(new Dimension(200, 300));

        lblStocAdd = new JLabel("Stoc:");
        txtStoc = new JTextField();

        lblSortareNume = new JLabel("Sortare Nume");
        lblSortarePret = new JLabel("Sortare Pret");
        lblCautaDupaNume = new JLabel("Caută după nume");
        lblMagazin = new JLabel("Magazin");

        comboBoxMagazin = new JComboBox<String>();
        comboBoxSortarePret = new JComboBox<String>(new String[] {"Crescator", "Descrescator"});
        comboBoxSortareNume = new JComboBox<String>(new String[] {"Crescator", "Descrescator"});

        btnCauta = new JButton("Cauta");
        textFieldCautaDupaNume = new JTextField();

        addParfumFrame.add(lblIdParfumAdd);
        addParfumFrame.add(txtIdParfum);
        addParfumFrame.add(lblNumeAdd);
        addParfumFrame.add(txtNume);
        addParfumFrame.add(lblProducatorAdd);
        addParfumFrame.add(txtProducator);
        addParfumFrame.add(lblPretAdd);
        addParfumFrame.add(txtPret);
        addParfumFrame.add(lblDescriereAdd);
        addParfumFrame.add(scrollPaneDescriere);
        addParfumFrame.add(lblStocAdd);
        addParfumFrame.add(txtStoc);
        Font inputFont = new Font("Times New Roman", Font.PLAIN, 14);
        Font labelFont = new Font("Times New Roman", Font.BOLD, 14);
        int borderWidth = 20;
        addParfumFrame.getRootPane().setBorder(BorderFactory.createEmptyBorder(borderWidth, borderWidth, borderWidth, borderWidth));


        lblIdParfumAdd.setFont(labelFont);
        txtIdParfum.setFont(inputFont);
        lblNumeAdd.setFont(labelFont);
        txtNume.setFont(inputFont);
        lblProducatorAdd.setFont(labelFont);
        txtProducator.setFont(inputFont);
        lblPretAdd.setFont(labelFont);
        txtPret.setFont(inputFont);
        lblDescriereAdd.setFont(labelFont);
        txtDescriere.setFont(inputFont);
        lblStocAdd.setFont(labelFont);
        txtStoc.setFont(inputFont);

        btnSubmit = new JButton("Adaugă parfum nou");
        btnSubmit.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        btnSubmit.setSize(40, 20);
        btnSubmit.setFont(labelFont);
        addParfumFrame.add(new JPanel());
        addParfumFrame.add(btnSubmit);

        addParfumFrame.setVisible(true);
    }

    public void disposeAddParfumFrame() {
        addParfumFrame.dispose();
    }


    public JButton getBtnSubmit() {
        return btnSubmit;
    }

    public JButton getBtnEnglish() {
        return btnEnglish;
    }

    public JButton getBtnRomanian() {
        return btnRomanian;
    }

    public JButton getBtnFrench() {
        return btnFrench;
    }

    public JButton getBtnSpanish() {
        return btnSpanish;
    }

    public ResourceBundle getResourceBundle() {
        return resourceBundle;
    }

    public void setResourceBundle(ResourceBundle bundle) {
        this.resourceBundle = bundle;
    }
    public void updateResourceBundle(Locale locale) {
        setResourceBundle(ResourceBundle.getBundle("LanguageBundle", locale));
    }


    public JLabel getLblPretMinim() {
        return lblPretMinim;
    }

    public JLabel getLblPretMaxim() {
        return lblPretMaxim;
    }

    public JLabel getLblProducator() {
        return lblProducator;
    }

    public JLabel getLblDisponibilitate() {
        return lblDisponibilitate;
    }

    public JTable getTable() {
        return table;
    }
    public JLabel getLblStoc() {
        return lblStoc;
    }

    public JLabel getLblIdParfum() {
        return lblIdParfum;
    }
    public JLabel getLblIdParfumAdd() {
        if (lblIdParfumAdd == null) {
            lblIdParfumAdd = new JLabel();
        }
        return lblIdParfumAdd;
    }

    public JLabel getLblNumeAdd() {
        return lblNumeAdd;
    }

    public JLabel getLblProducatorAdd() {
        return lblProducatorAdd;
    }

    public JLabel getLblPretAdd() {
        return lblPretAdd;
    }

    public JLabel getLblDescriereAdd() {
        return lblDescriereAdd;
    }

    public JLabel getLblStocAdd() {
        return lblStocAdd;
    }
    public JButton getBtnStergeParfum() {
        return btnStergeParfum;
    }
    public JButton getBtnActualizeazaParfum() {
        return btnActualizeazaParfum;
    }

    public JButton getBtnAdaugaParfumNou() {
        return btnAdaugaParfumNou;
    }

    public JComboBox<String> getComboBoxMagazin() {
        return comboBoxMagazin;
    }

    public JComboBox<String> getComboBoxSortarePret() {
        return comboBoxSortarePret;
    }

    public JComboBox<String> getComboBoxSortareNume() {
        return comboBoxSortareNume;
    }

    public JTextField getTextFieldCautaDupaNume() {
        return textFieldCautaDupaNume;
    }

    public JButton getBtnCauta() {
        return btnCauta;
    }

    public JLabel getLblMagazin() {
        return lblMagazin;
    }

    public JLabel getLblSortarePret() {
        return lblSortarePret;
    }

    public JLabel getLblSortareNume() {
        return lblSortareNume;
    }

    public JLabel getLblCautaDupaNume() {
        return lblCautaDupaNume;
    }


    public JComboBox<String> getComboBoxProducator() {
        return comboBoxProducator;
    }

    public JTextField getTxtIdParfum() { return txtIdParfum; }

    public JTextField getTextFieldIdParfum() {
        return textFieldIdParfum;
    }


    public JTextField getTextFieldStoc() {
        return textFieldStoc;
    }

    public JTextField getTxtNume() {
        return txtNume;
    }

    public JTextField getTxtProducator() {
        return txtProducator;
    }

    public JTextField getTxtPret() {
        return txtPret;
    }

    public JTextArea getTxtDescriere() {
        return txtDescriere;
    }

    public JTextField getTxtStoc() {
        return txtStoc;
    }

    public JTextField getTextFieldPretMin() {
        return textFieldPretMin;
    }

    public JTextField getTextFieldPretMax() {
        return textFieldPretMax;
    }


    public JButton getBtnAdaugaParfum() {
        return btnAdaugaParfum;
    }

    public JButton getBtnFiltreaza() {
        return btnFiltreaza;
    }

    public JButton getBtnViewDetails() {
        return btnViewDetails;
    }

    public JCheckBox getChckbxDisponibil() { return chckbxDisponibil; }

    public Object[] getRowData(JTable table, int row) {
        int columnCount = table.getColumnCount();
        Object[] rowData = new Object[columnCount];

        for (int i = 0; i < columnCount; i++) {
            rowData[i] = table.getValueAt(row, i);
        }

        return rowData;
    }

    public void showMessageDialog(String message) {
        JOptionPane.showMessageDialog(null, message);
    }

    public void displayParfumList(Object[][] parfumList) {
        DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
        tableModel.setRowCount(0);
        for (Object[] row : parfumList) {
            tableModel.addRow(row);
        }
    }


    public void showPerfumeDetails(String title, String perfumeDetails) {
        String[] perfumeDetailsArray = perfumeDetails.split("\n");

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.5;
        gbc.weighty = 0.5;
        gbc.anchor = GridBagConstraints.LINE_START;
        gbc.insets = new Insets(10, 10, 10, 10);

        Font boldFont = new Font("Times New Roman", Font.BOLD, 16);
        Font normalFont = new Font("Times New Roman", Font.PLAIN, 14);

        for (int i = 0; i < perfumeDetailsArray.length; i++) {
            String detail = perfumeDetailsArray[i];
            JLabel label = new JLabel(detail.substring(0, detail.indexOf(':') + 1));
            label.setFont(boldFont);
            panel.add(label, gbc);
            gbc.gridy++;
        }


        gbc.gridx = 1;
        gbc.gridy = 0;
        for (int i = 0; i < perfumeDetailsArray.length; i++) {
            String detail = perfumeDetailsArray[i];
            if (i == 4) { // Description field
                JTextArea descriptionTextArea = new JTextArea(detail.substring(detail.indexOf(':') + 1).trim());
                descriptionTextArea.setFont(normalFont);
                descriptionTextArea.setLineWrap(true);
                descriptionTextArea.setWrapStyleWord(true);
                descriptionTextArea.setEditable(false);
                descriptionTextArea.setOpaque(false);
                descriptionTextArea.setBackground(Color.WHITE);

                JScrollPane scrollPane = new JScrollPane(descriptionTextArea);
                scrollPane.setPreferredSize(new Dimension(450, 100));
                panel.add(scrollPane, gbc);
            } else {
                JLabel label = new JLabel(detail.substring(detail.indexOf(':') + 1).trim());
                label.setFont(normalFont);
                panel.add(label, gbc);
            }
            gbc.gridy++;
        }

        JOptionPane.showMessageDialog(this, panel, title, JOptionPane.PLAIN_MESSAGE);
    }

    public void showPerfumeDetailsByName(String perfumeDetails) {
        String[] perfumeDetailsArray = perfumeDetails.split("\n");

        String[] columnNames = {
                "ID", "Nume", "Producator", "Pret", "Descriere"
        };

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.5;
        gbc.weighty = 0.5;
        gbc.anchor = GridBagConstraints.LINE_START;
        gbc.insets = new Insets(10, 10, 10, 10);

        Font boldFont = new Font("Times New Roman", Font.BOLD, 16);
        Font normalFont = new Font("Times New Roman", Font.PLAIN, 14);

        for (int i = 0; i < columnNames.length; i++) {
            JLabel label = new JLabel(columnNames[i] + ":");
            label.setFont(boldFont);
            panel.add(label, gbc);
            gbc.gridy++;
        }

        gbc.gridx = 1;
        gbc.gridy = 0;
        for (int i = 0; i < perfumeDetailsArray.length; i++) {
            String detail = perfumeDetailsArray[i];
            if (i == 4) { // Description field
                JTextArea descriptionTextArea = new JTextArea(detail.substring(detail.indexOf(':') + 1).trim());
                descriptionTextArea.setFont(normalFont);
                descriptionTextArea.setLineWrap(true);
                descriptionTextArea.setWrapStyleWord(true);
                descriptionTextArea.setEditable(false);
                descriptionTextArea.setOpaque(false);
                descriptionTextArea.setBackground(Color.WHITE);

                JScrollPane scrollPane = new JScrollPane(descriptionTextArea);
                scrollPane.setPreferredSize(new Dimension(450, 100));
                panel.add(scrollPane, gbc);
            } else {
                JLabel label = new JLabel(detail.substring(detail.indexOf(':') + 1).trim());
                label.setFont(normalFont);
                panel.add(label, gbc);
            }
            gbc.gridy++;
        }

        JOptionPane.showMessageDialog(this, panel, "Detalii Parfum", JOptionPane.PLAIN_MESSAGE);
    }




}