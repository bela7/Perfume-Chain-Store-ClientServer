package Model;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import java.sql.SQLException;
import java.util.List;

class ParfumPersistentTest {
    private ParfumPersistent parfumPersistent;

    @BeforeEach
    void setUp() {
        try {
            DatabaseConnection.getConnection();
            parfumPersistent = new ParfumPersistent();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Unable to set up test environment due to database connection failure", e);
        }
    }


    @AfterEach
    void tearDown() {
        parfumPersistent = null;
    }



    @Test
    void testCreateAndRead() {
        Parfum parfum = new Parfum(99, "TestParfum", "TestProducator", 100.0, "TestDescriere");
        assertTrue(parfumPersistent.create(parfum));

        Parfum readParfum = parfumPersistent.read(99);
        assertNotNull(readParfum);
        assertEquals(parfum.getIdParfum(), readParfum.getIdParfum());
        assertEquals(parfum.getNume(), readParfum.getNume());
        assertEquals(parfum.getProducator(), readParfum.getProducator());
        assertEquals(parfum.getPret(), readParfum.getPret());
        assertEquals(parfum.getDescriere(), readParfum.getDescriere());
    }

    @Test
    void testReadByName() {
        Parfum readParfum = parfumPersistent.readByName("Ricci Ricci");
        assertNotNull(readParfum);
        assertEquals("Ricci Ricci", readParfum.getNume());
    }

    @Test
    void testUpdate() {
        Parfum parfum = new Parfum(99, "UpdatedParfum", "UpdatedProducator", 400.0, "UpdatedDescriere");
        assertTrue(parfumPersistent.update(parfum));

        Parfum updatedParfum = parfumPersistent.read(999);
        assertNotNull(updatedParfum);
        assertEquals(parfum.getNume(), updatedParfum.getNume());
        assertEquals(parfum.getProducator(), updatedParfum.getProducator());
        assertEquals(parfum.getPret(), updatedParfum.getPret());
        assertEquals(parfum.getDescriere(), updatedParfum.getDescriere());
    }

    @Test
    void testDelete() {
        int id = 99;
        assertTrue(parfumPersistent.delete(id));
    }

    @Test
    void testGetAll() {
        List<Parfum> parfums = parfumPersistent.getAll();
        assertNotNull(parfums);
        assertFalse(parfums.isEmpty());
    }



}



