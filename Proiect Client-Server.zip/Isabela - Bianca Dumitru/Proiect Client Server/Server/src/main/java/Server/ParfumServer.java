package Server;

import Controller.LoginControllerServer;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ParfumServer {
    private int port;
    private ServerSocket serverSocket;
    private LoginControllerServer loginControllerServer;
    private ExecutorService executorService;

    public ParfumServer(int port, LoginControllerServer loginControllerServer) {
        this.port = port;
        this.loginControllerServer = loginControllerServer;
        this.executorService = Executors.newCachedThreadPool();
    }

    public void start() {
        try {
            InetAddress address = InetAddress.getByName(null);
            serverSocket = new ServerSocket(port, 0, address);
            System.out.println("Server started on port " + port);
            System.out.println("Server IP: " + InetAddress.getLocalHost().getHostAddress());

            while (true) {
                System.out.println("Waiting for client...");
                System.out.println("Before serverSocket.accept()");
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected from IP: " + clientSocket.getInetAddress().getHostAddress() + " Port: " + clientSocket.getPort());
                ClientHandler clientHandler = new ClientHandler(clientSocket, loginControllerServer);
                executorService.submit(clientHandler);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                serverSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
