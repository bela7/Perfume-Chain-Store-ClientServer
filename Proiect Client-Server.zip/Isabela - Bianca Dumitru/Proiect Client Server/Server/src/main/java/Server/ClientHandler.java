package Server;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.List;

import Model.Utilizator;
import Controller.*;
import Common.*;

public class ClientHandler implements Runnable {
    private Socket socket;
    private ObjectInputStream in;
    private ObjectOutputStream out;
    private LoginControllerServer loginControllerServer;

    private AdministratorControllerServer administratorControllerServer;

    public ClientHandler(Socket socket, LoginControllerServer loginControllerServer) throws IOException {
        this.socket = socket;
        this.loginControllerServer = loginControllerServer;
        this.in = new ObjectInputStream(socket.getInputStream());
        this.out = new ObjectOutputStream(socket.getOutputStream());
        out.flush();
    }

    @Override
    public void run() {
        try {
            while (true) {
                ManagerControllerServer managerControllerServer = new ManagerControllerServer();
                AngajatControllerServer angajatControllerServer = new AngajatControllerServer();
                Request request = (Request) in.readObject();
                Response response = null;
                int idMagazin= 0;
                int idParfum=0;

                switch (request.getType()) {
                    case LOGIN:
                        String username = (String) ((Object[]) request.getData())[0];
                        String password = (String) ((Object[]) request.getData())[1];
                        Utilizator user = loginControllerServer.autentificare(username, password);

                        if (user != null) {
                            String role = user.getRol();
                            idMagazin = user.getIdMagazin();
                            response = new Response(Response.Type.LOGIN_RESULT, true, null);
                            response.setRole(role);
                            response.setIdMagazin(idMagazin);
                        } else {
                            response = new Response(Response.Type.LOGIN_RESULT, false, "Authentication failed.");
                        }

                        break;



                    case UPDATE_USER:
                        AdministratorControllerServer administratorControllerServerUpdate = new AdministratorControllerServer();
                        Object[] dataUpdate = (Object[]) request.getData();
                        int userIdUpdate = (int) dataUpdate[0];
                        String userNameUpdate = (String) dataUpdate[1];
                        String passwordUpdate = (String) dataUpdate[2];
                        String rolUpdate = (String) dataUpdate[3];
                        int idMagazinUpdate = (int) dataUpdate[4];
                        boolean successUpdate = administratorControllerServerUpdate.updateUser(userIdUpdate, userNameUpdate, passwordUpdate, rolUpdate, idMagazinUpdate);
                        response = new Response(Response.Type.UPDATE_USER_RESULT, successUpdate, null);
                        break;
                    case DELETE_USER:
                        AdministratorControllerServer administratorControllerServerDelete = new AdministratorControllerServer();
                        int userIdToDelete = (int) request.getData();
                        boolean successDelete = administratorControllerServerDelete.deleteUser(userIdToDelete);
                        response = new Response(Response.Type.DELETE_USER_RESULT, successDelete, null);
                        break;
                    case DISPLAY_USER_LIST:
                        AdministratorControllerServer administratorControllerServerDisplay = new AdministratorControllerServer();
                        Object[][] userList = administratorControllerServerDisplay.getUserList();
                        response = new Response(Response.Type.DISPLAY_USER_LIST_RESULT, userList);
                        break;

                    case GET_ALL_PRODUCATORS: {
                        int idMagazinProd = (Integer) request.getData();
                        List<String> producators = managerControllerServer.getAllProducators(idMagazinProd);
                        response = new Response(Response.Type.GET_ALL_PRODUCATORS_RESULT, producators);
                        break;
                    }
                    case FILTER_PARFUMS: {
                        Object[] requestData = (Object[]) request.getData();

                        int idMagazinFilter = (int) requestData[0];
                        Double priceMin = (Double) requestData[1];
                        Double priceMax = (Double) requestData[2];
                        String producator = (String) requestData[3];
                        Boolean disponibil = (Boolean) requestData[4];
                        String language = (String) requestData[5];


                        List<Object[]> filteredParfums = managerControllerServer.filterParfums(idMagazinFilter, priceMin, priceMax, producator, disponibil, language);
                        response = new Response(Response.Type.FILTER_PARFUMS_RESULT, filteredParfums);
                        break;
                    }

                    case GET_ALL_PARFUMURI_FOR_MAGAZIN: {
                        Object[] requestData = (Object[]) request.getData();
                        idMagazin = (int) requestData[0];
                        String language = (String) requestData[1];
                        List<Object[]> parfumuriMagazinAsObjects = managerControllerServer.getAllParfumuriForMagazinAsObjects(idMagazin, language);
                        response = new Response(Response.Type.GET_ALL_PARFUMURI_FOR_MAGAZIN_RESULT, parfumuriMagazinAsObjects);
                        break;
                    }
                    case SORT_PARFUMS_BY_PRICE: {
                        Object[] requestData = (Object[]) request.getData();
                        idMagazin = (int) requestData[0];
                        boolean ascending = (boolean) requestData[1];
                        String language = (String) requestData[2];
                        List<Object[]> sortedParfumsObject = managerControllerServer.getSortedParfumsByPriceAsObjects(idMagazin, ascending, language);
                        response = new Response(Response.Type.SORT_PARFUMS_BY_PRICE_RESULT, sortedParfumsObject);
                        break;
                    }

                    case SORT_PARFUMS_BY_NAME: {
                        Object[] requestData = (Object[]) request.getData();
                        idMagazin = (int) requestData[0];
                        boolean ascending = (boolean) requestData[1];
                        String language = (String) requestData[2];
                        List<Object[]> sortedParfumsObject = managerControllerServer.getSortedParfumsByNameAsObjects(idMagazin, ascending, language);
                        response = new Response(Response.Type.SORT_PARFUMS_BY_NAME_RESULT, sortedParfumsObject);
                        break;
                    }
                    case SEARCH_PARFUM_BY_NAME: {
                        Object[] requestData = (Object[]) request.getData();
                        String parfumName = (String) requestData[0];
                        Object parfumDetails = managerControllerServer.handleSearchParfumByName(parfumName);
                        if (parfumDetails != null) {
                            response = new Response(Response.Type.SEARCH_PARFUM_BY_NAME_RESULT, true,parfumDetails);
                        } else {
                            response = new Response(Response.Type.SEARCH_PARFUM_BY_NAME_RESULT, false, null );
                        }
                        break;
                    }

                    case GET_MAGAZIN_ID_BY_NAME: {
                        Object[] requestData = (Object[]) request.getData();
                        String selectedMagazinName = (String) requestData[0];
                        int magazinId = managerControllerServer.getMagazinIdByName(selectedMagazinName);

                        if (magazinId != -1) {
                            response = new Response(Response.Type.GET_MAGAZIN_ID_BY_NAME_RESULT,true, magazinId);
                        } else {
                            response = new Response(Response.Type.GET_MAGAZIN_ID_BY_NAME_RESULT, false,null);
                        }
                        break;
                    }

                    case GET_ALL_MAGAZIN_NAMES: {
                        List<String> magazinNames = managerControllerServer.getAllMagazinNames();

                        if (magazinNames != null && !magazinNames.isEmpty()) {
                            response = new Response(Response.Type.GET_ALL_MAGAZIN_NAMES_RESULT,  true, magazinNames);
                        } else {
                            response = new Response(Response.Type.GET_ALL_MAGAZIN_NAMES_RESULT, false,null);
                        }
                        break;
                    }

                    case ADD_PARFUM_NEW:
                        System.out.println("Processing ADD_PARFUM_NEW request");
                        Object[] parfumData = (Object[]) request.getData();
                        idParfum = (int) parfumData[0];
                        String nume = (String) parfumData[1];
                        String producator = (String) parfumData[2];
                        double pret = (double) parfumData[3];
                        String descriere = (String) parfumData[4];
                        int stoc = (int) parfumData[5];
                        idMagazin = (int) parfumData[6];
                        boolean parfumSuccess = angajatControllerServer.addParfumNew(idParfum, nume, producator, pret, descriere, stoc, idMagazin);
                        response = new Response(Response.Type.ADD_PARFUM_NEW_RESULT, parfumSuccess, null);
                        break;

                    case ADD_PARFUM:
                        Object[] parfumDataAdd = (Object[]) request.getData();
                        idParfum = (int) parfumDataAdd[0];
                        int stoc1 =(int) parfumDataAdd[1];
                        idMagazin = (int)parfumDataAdd[2];
                        boolean addParfumResponse = angajatControllerServer.addParfum(idParfum, stoc1, idMagazin);
                        response = new Response(Response.Type.ADD_PARFUM_RESULT, addParfumResponse, null);
                        break;

                    case ADD_USER:
                        AdministratorControllerServer administratorControllerServerAdd = new AdministratorControllerServer();
                        Object[] data = (Object[]) request.getData();
                        int userId = (int) data[0];
                        String userNameAdd = (String) data[1];
                        String passwordAdd = (String) data[2];
                        String rol = (String) data[3];
                        idMagazin = (int) data[4];
                        boolean success = administratorControllerServerAdd.addUser(userId, userNameAdd, passwordAdd, rol, idMagazin);
                        response = new Response(Response.Type.ADD_USER_RESULT, success, null);
                        break;

                    case UPDATE_PARFUM:
                        AngajatControllerServer angajatControllerServerUpdate = new AngajatControllerServer();
                        Object[] updateData = (Object[]) request.getData();
                        int idParfumUpdate = (int) updateData[0];
                        int stocUpdate = (int) updateData[1];
                        idMagazin = (int) updateData[2];
                        boolean updateParfumResponse = angajatControllerServerUpdate.updateParfum(idParfumUpdate, stocUpdate, idMagazin);
                        response = new Response(Response.Type.UPDATE_PARFUM_RESULT, updateParfumResponse, null);
                        break;

                    case DELETE_PARFUM:
                        AngajatControllerServer angajatControllerServerDelete = new AngajatControllerServer();
                        Object[] deleteData = (Object[]) request.getData();
                        int selectedParfumId = (int) deleteData[0];
                        int idMagazinDelete = (int) deleteData[1];
                        boolean deleteParfumResponse = angajatControllerServerDelete.deleteParfum(selectedParfumId, idMagazinDelete);
                        response = new Response(Response.Type.DELETE_PARFUM_RESULT, deleteParfumResponse, null);
                        break;

                }

                out.writeObject(response);
                out.flush();
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                in.close();
                out.close();
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void closeResources() {
        try {
            in.close();
            out.close();
            socket.close();
            System.out.println("ClientHandler resources closed");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
