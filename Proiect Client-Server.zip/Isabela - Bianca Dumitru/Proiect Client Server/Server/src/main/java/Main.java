import Server.ParfumServer;
import Controller.LoginControllerServer;

public class Main {
    public static void main(String[] args) {
        LoginControllerServer loginControllerServer = new LoginControllerServer();
        ParfumServer server = new ParfumServer(12345, loginControllerServer);
        server.start();
    }
}
