package Model;
import java.util.List;
import java.util.ArrayList;
import java.sql.*;

public class UtilizatorPersistent extends Persistent<Utilizator> {

    @Override
    public boolean create(Utilizator utilizator) {
        Connection conn = null;
        PreparedStatement preparedStatement = null;
        boolean success = false;

        try {
            conn = DatabaseConnection.getConnection();

            String sql = "INSERT INTO utilizator (userId, user, parola, rol, idMagazin) VALUES (?, ?, ?, ?, ?)";
            preparedStatement = conn.prepareStatement(sql);

            preparedStatement.setInt(1, utilizator.getUserId());
            preparedStatement.setString(2, utilizator.getUser());
            preparedStatement.setString(3, utilizator.getParola());
            preparedStatement.setString(4, utilizator.getRol());

            if ("angajat".equalsIgnoreCase(utilizator.getRol())) {
                preparedStatement.setInt(5, utilizator.getIdMagazin());
            } else {
                preparedStatement.setNull(5, Types.INTEGER);
            }

            preparedStatement.executeUpdate();
            success = true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return success;
    }

    @Override
    public Utilizator read(int id) {
        Utilizator utilizator = null;

        try {
            Connection conn = DatabaseConnection.getConnection();

            String sql = "SELECT * FROM utilizator WHERE userId=?";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setInt(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                utilizator = new Utilizator();
                utilizator.setUserId(resultSet.getInt("userId"));
                utilizator.setUser(resultSet.getString("user"));
                utilizator.setParola(resultSet.getString("parola"));
                utilizator.setRol(resultSet.getString("rol"));
                if (resultSet.getObject("idMagazin") != null) {
                    utilizator.setIdMagazin(resultSet.getInt("idMagazin"));
                }

            }

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return utilizator;
    }

    @Override
    public boolean update(Utilizator utilizator) {
        Connection conn = null;
        PreparedStatement preparedStatement = null;
        boolean success = false;

        try {
            conn = DatabaseConnection.getConnection();

            String sql = "UPDATE utilizator SET user=?, parola=?, rol=?, idMagazin=? WHERE userId=?";
            preparedStatement = conn.prepareStatement(sql);

            preparedStatement.setString(1, utilizator.getUser());
            preparedStatement.setString(2, utilizator.getParola());
            preparedStatement.setString(3, utilizator.getRol());
            if ("angajat".equalsIgnoreCase(utilizator.getRol())) {
                preparedStatement.setInt(4, utilizator.getIdMagazin());
            } else {
                preparedStatement.setNull(4, Types.INTEGER);
            }
            preparedStatement.setInt(5, utilizator.getUserId());

            int rowsAffected = preparedStatement.executeUpdate();
            success = rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return success;
    }

    @Override
         public boolean delete(int userId) {
            Connection conn = null;
            PreparedStatement preparedStatement = null;
            boolean success = false;

            try {
                conn = DatabaseConnection.getConnection();

                String sqlUtilizator = "DELETE FROM UTILIZATOR WHERE userID = ?";
                preparedStatement = conn.prepareStatement(sqlUtilizator);
                preparedStatement.setInt(1, userId);
                int rowsAffected = preparedStatement.executeUpdate();
                success = rowsAffected > 0;
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                if (preparedStatement != null) {
                    try {
                        preparedStatement.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
                if (conn != null) {
                    try {
                        conn.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
            return success;
        }


    public Utilizator cautareUtilizator(String user, String password) {
        Utilizator utilizator = null;

        try {
            Connection conn = DatabaseConnection.getConnection();

            String sql = "SELECT * FROM utilizator WHERE user=? AND parola=?";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, user);
            preparedStatement.setString(2, password);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                utilizator = new Utilizator();
                utilizator.setUserId(resultSet.getInt("userId"));
                utilizator.setUser(resultSet.getString("user"));
                utilizator.setParola(resultSet.getString("parola"));
                utilizator.setRol(resultSet.getString("rol"));
                if (resultSet.getObject("idMagazin") != null) {
                    utilizator.setIdMagazin(resultSet.getInt("idMagazin"));
                }
            }

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return utilizator;
    }
    @Override
    public List<Utilizator> getAll() {
        List<Utilizator> utilizatori = new ArrayList<>();

        try {
            Connection conn = DatabaseConnection.getConnection();

            String sql = "SELECT * FROM utilizator";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);

            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                Utilizator utilizator = new Utilizator();
                utilizator.setUserId(resultSet.getInt("userId"));
                utilizator.setUser(resultSet.getString("user"));
                utilizator.setParola(resultSet.getString("parola"));
                utilizator.setRol(resultSet.getString("rol"));
                utilizator.setIdMagazin(resultSet.getInt("idMagazin"));
                utilizatori.add(utilizator);
            }

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return utilizatori;
    }



}