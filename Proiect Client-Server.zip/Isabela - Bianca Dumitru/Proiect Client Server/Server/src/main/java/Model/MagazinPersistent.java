package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MagazinPersistent extends Persistent<Magazin> {

    @Override
    public Magazin read(int idMagazin) {
        Connection conn = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            conn = DatabaseConnection.getConnection();

            String query = "SELECT * FROM Magazin WHERE idMagazin = ?";

            preparedStatement = conn.prepareStatement(query);
            preparedStatement.setInt(1, idMagazin);

            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                String nume = resultSet.getString("nume");
                String adresa = resultSet.getString("adresa");

                return new Magazin(idMagazin, nume, adresa);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return null;
    }

    @Override
    public boolean create(Magazin magazin) {
        Connection conn = null;
        PreparedStatement preparedStatement = null;

        try {
            conn = DatabaseConnection.getConnection();
            String query = "INSERT INTO Magazin (idMagazin, nume, adresa) VALUES (?, ?,?)";
            preparedStatement = conn.prepareStatement(query);

            preparedStatement.setInt(1, magazin.getIdMagazin());
            preparedStatement.setString(2, magazin.getNume());
            preparedStatement.setString(3, magazin.getAdresa());

            int affectedRows = preparedStatement.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            closeResources(conn, preparedStatement, null);
        }
    }
    @Override
    public boolean update(Magazin magazin) {
        Connection conn = null;
        PreparedStatement preparedStatement = null;

        try {
            conn = DatabaseConnection.getConnection();
            String query = "UPDATE Magazin SET nume = ?, adresa = ? WHERE idMagazin = ?";
            preparedStatement = conn.prepareStatement(query);
            preparedStatement.setString(1, magazin.getNume());
            preparedStatement.setString(2, magazin.getAdresa());
            preparedStatement.setInt(3, magazin.getIdMagazin());

            int affectedRows = preparedStatement.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            closeResources(conn, preparedStatement, null);
        }
    }

    @Override
    public boolean delete(int id) {
        Connection conn = null;
        PreparedStatement preparedStatement = null;

        try {
            conn = DatabaseConnection.getConnection();
            String query = "DELETE FROM Magazin WHERE idMagazin = ?";
            preparedStatement = conn.prepareStatement(query);
            preparedStatement.setInt(1, id);

            int affectedRows = preparedStatement.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            closeResources(conn, preparedStatement, null);
        }
    }

    @Override
    public List<Magazin> getAll() {
        List<Magazin> magazine = new ArrayList<>();
        Connection conn = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            conn = DatabaseConnection.getConnection();
            String query = "SELECT * FROM Magazin";
            preparedStatement = conn.prepareStatement(query);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int idMagazin = resultSet.getInt("idMagazin");
                String nume = resultSet.getString("nume");
                String adresa = resultSet.getString("adresa");

                Magazin magazin = new Magazin(idMagazin, nume, adresa);
                magazine.add(magazin);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(conn, preparedStatement, resultSet);
        }

        return magazine;
    }

    private void closeResources(Connection conn, PreparedStatement preparedStatement, ResultSet resultSet) {
        try {
            if (resultSet != null) {
                resultSet.close();
            }
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


}
