package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.*;

public class ParfumMagazinPersistent  {
    public ParfumMagazinPersistent() {
    }

    public boolean createParfumMagazin(int idParfum, int angajatIdMagazin, int stoc) {
        Connection conn = null;
        PreparedStatement preparedStatement = null;
        boolean success = false;
        try {
            conn = DatabaseConnection.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }

        String query = "INSERT INTO ParfumMagazin (idMagazin, idParfum, stoc) VALUES (?, ?, ?)";

        try {
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setInt(1, angajatIdMagazin);
            statement.setInt(2, idParfum);
            statement.setInt(3, stoc);

            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteParfumMagazin(int idParfum, int idMagazin) {
        Connection conn = null;
        PreparedStatement preparedStatement = null;
        boolean success = false;

        try {
            conn = DatabaseConnection.getConnection();

            String sqlMagazin = "DELETE FROM parfumMagazin WHERE idParfum = ? AND idMagazin = ?";
            preparedStatement = conn.prepareStatement(sqlMagazin);
            preparedStatement.setInt(1, idParfum);
            preparedStatement.setInt(2, idMagazin);
            int rowsAffected = preparedStatement.executeUpdate();

            success = rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return success;
    }

    public boolean updateParfumMagazinStock(int idParfum, int angajatIdMagazin, int newStock) {
        Connection conn = null;
        PreparedStatement preparedStatement = null;
        boolean success = false;

        try {
            conn = DatabaseConnection.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }

        String query = "UPDATE ParfumMagazin SET stoc = ? WHERE idParfum = ? AND idMagazin = ?";

        try {
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setInt(1, newStock);
            statement.setInt(2, idParfum);
            statement.setInt(3, angajatIdMagazin);

            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


}
