package Controller;

import Model.Utilizator;
import Model.UtilizatorPersistent;

public class LoginControllerServer {
    private UtilizatorPersistent utilizatorPersistent;

    public LoginControllerServer() {
        this.utilizatorPersistent = new UtilizatorPersistent();
    }

    public Utilizator autentificare(String username, String password) {
        return utilizatorPersistent.cautareUtilizator(username, password);
    }
}
