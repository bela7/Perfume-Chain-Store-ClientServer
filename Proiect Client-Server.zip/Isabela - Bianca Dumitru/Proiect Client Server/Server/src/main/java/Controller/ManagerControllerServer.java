package Controller;

import Model.*;
import java.util.ArrayList;
import java.util.List;

public class ManagerControllerServer {
    private ParfumPersistent parfumPersistent;
    private MagazinPersistent magazinPersistent;

    public ManagerControllerServer() {
        this.parfumPersistent = new ParfumPersistent();
        this.magazinPersistent = new MagazinPersistent();
    }


    public List<String> getAllProducators(int idMagazin) {
        return parfumPersistent.getAllProducators(idMagazin);
    }


    public List<Object[]> filterParfums(int idMagazin, Double priceMin, Double priceMax, String producator, Boolean disponibil, String language) {
        List<ParfumMagazin> parfumMagazinList = parfumPersistent.filterParfums(idMagazin, priceMin, priceMax, producator, disponibil, language);

        List<Object[]> filteredParfums = new ArrayList<>();
        for (ParfumMagazin parfumMagazin : parfumMagazinList) {
            Parfum parfum = parfumMagazin.getParfum();
            Object[] row = new Object[] {
                    parfum.getIdParfum(),
                    parfum.getNume(),
                    parfum.getProducator(),
                    parfum.getPret(),
                    parfum.getDescriere(),
                    parfumMagazin.getStoc()
            };
            filteredParfums.add(row);
        }

        return filteredParfums;
    }


    public List<Object[]> getAllParfumuriForMagazinAsObjects(int idMagazin, String language) {
        List<ParfumMagazin> parfumuriMagazin = parfumPersistent.getAllParfumuriForMagazin(idMagazin, language);
        List<Object[]> parfumuriMagazinAsObjects = new ArrayList<>();

        for (ParfumMagazin pm : parfumuriMagazin) {
            Parfum parfum = pm.getParfum();
            Object[] parfumData = new Object[]{
                    parfum.getIdParfum(),
                    parfum.getNume(),
                    parfum.getProducator(),
                    parfum.getPret(),
                    parfum.getDescriere(),
                    pm.getStoc()
            };
            parfumuriMagazinAsObjects.add(parfumData);
        }

        return parfumuriMagazinAsObjects;
    }

    public List<Object[]> getSortedParfumsByPriceAsObjects(int idMagazin, boolean ascending, String language) {
        List<ParfumMagazin> sortedParfums = parfumPersistent.getSortedParfumsByPrice(idMagazin, ascending, language);
        return convertParfumMagazinListToObjectList(sortedParfums);
    }

    public List<Object[]> getSortedParfumsByNameAsObjects(int idMagazin, boolean ascending, String language) {
        List<ParfumMagazin> sortedParfums = parfumPersistent.getSortedParfumsByName(idMagazin, ascending, language);
        return convertParfumMagazinListToObjectList(sortedParfums);
    }


    private List<Object[]> convertParfumMagazinListToObjectList(List<ParfumMagazin> parfumMagazinList) {
        List<Object[]> parfumList = new ArrayList<>();
        for (ParfumMagazin pm : parfumMagazinList) {
            Parfum parfum = pm.getParfum();
            Object[] parfumData = new Object[]{
                    parfum.getIdParfum(),
                    parfum.getNume(),
                    parfum.getProducator(),
                    parfum.getPret(),
                    parfum.getDescriere(),
                    pm.getStoc()
            };
            parfumList.add(parfumData);
        }
        return parfumList;
    }

    public String handleSearchParfumByName(String parfumName) {
        Parfum parfum = parfumPersistent.readByName(parfumName);

        if (parfum != null) {
            return String.format("ID: %d\nNume: %s\nProducator: %s\nPret: %.2f\nDescriere: %s",
                    parfum.getIdParfum(), parfum.getNume(),
                    parfum.getProducator(), parfum.getPret(), parfum.getDescriere());
        } else {
            return null;
        }
    }

    public int getMagazinIdByName(String selectedMagazinName) {
        List<Magazin> magazine = magazinPersistent.getAll();

        for (Magazin magazin : magazine) {
            if (magazin.getNume().equals(selectedMagazinName)) {
                return magazin.getIdMagazin();
            }
        }

        return -1;
    }

    public List<String> getAllMagazinNames() {
        List<Magazin> magazine = magazinPersistent.getAll();
        List<String> magazinNames = new ArrayList<>();

        for (Magazin magazin : magazine) {
            magazinNames.add(magazin.getNume());
        }

        return magazinNames;
    }








}

