package Controller;

import Model.Utilizator;
import Model.UtilizatorPersistent;
import java.util.List;

public class AdministratorControllerServer {
    private UtilizatorPersistent utilizatorPersistent;

    public AdministratorControllerServer() {
        this.utilizatorPersistent = new UtilizatorPersistent();
    }

    public boolean addUser(int userId, String username, String password, String rol, int idMagazin) {
        Utilizator utilizator = new Utilizator();
        utilizator.setUserId(userId);
        utilizator.setUser(username);
        utilizator.setParola(password);
        utilizator.setRol(rol);
        utilizator.setIdMagazin(idMagazin);

        return utilizatorPersistent.create(utilizator);
    }

    public boolean updateUser(int userId, String username, String password, String rol, int idMagazin) {
        Utilizator utilizator = new Utilizator();
        utilizator.setUserId(userId);
        utilizator.setUser(username);
        utilizator.setParola(password);
        utilizator.setRol(rol);
        utilizator.setIdMagazin(idMagazin);

        return utilizatorPersistent.update(utilizator);
    }

    public boolean deleteUser(int userId) {
        return utilizatorPersistent.delete(userId);
    }

    public Object[][] getUserList() {
        List<Utilizator> utilizatori = utilizatorPersistent.getAll();
        Object[][] users = new Object[utilizatori.size()][5];
        for (int i = 0; i < utilizatori.size(); i++) {
            Utilizator utilizator = utilizatori.get(i);
            users[i][0] = utilizator.getUserId();
            users[i][1] = utilizator.getUser();
            users[i][2] = utilizator.getParola();
            users[i][3] = utilizator.getRol();
            users[i][4] = utilizator.getIdMagazin();
        }
        return users;
    }

}
