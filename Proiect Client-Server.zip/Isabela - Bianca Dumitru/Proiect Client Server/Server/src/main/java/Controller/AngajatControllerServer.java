package Controller;

import Model.*;



public class AngajatControllerServer {

    public AngajatControllerServer() {
    }

    public boolean addParfumNew(int idParfum, String nume, String producator, double pret, String descriere, int stoc, int idMagazin) {
        System.out.println("addParfumNew called with idParfum: " + idParfum + ", nume: " + nume + ", producator: " + producator + ", pret: " + pret + ", descriere: " + descriere + ", stoc: " + stoc);
        Parfum newParfum = new Parfum(idParfum, nume, producator, pret, descriere);
        ParfumPersistent parfumPersistent = new ParfumPersistent();
        boolean createdParfum = parfumPersistent.create(newParfum);
        System.out.println(createdParfum);

        return createdParfum;
    }

    public boolean addParfum(int idParfum, int stoc, int idMagazin) {
        ParfumMagazinPersistent parfumMagazinPersistent = new ParfumMagazinPersistent();
            boolean success = parfumMagazinPersistent.createParfumMagazin(idParfum, idMagazin, stoc);
            return success;

    }

    public boolean updateParfum(int idParfum, int stoc, int idMagazin) {
        ParfumMagazinPersistent parfumMagazinPersistent = new ParfumMagazinPersistent();
        boolean success = parfumMagazinPersistent.updateParfumMagazinStock(idParfum, idMagazin, stoc);
        return success;
    }

    public boolean deleteParfum(int selectedParfumId, int idMagazin) {
        ParfumMagazinPersistent parfumMagazinPersistent = new ParfumMagazinPersistent();
        boolean success = parfumMagazinPersistent.deleteParfumMagazin(selectedParfumId, idMagazin);
        return success;
    }





}

