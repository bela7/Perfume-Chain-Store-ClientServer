-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Gazdă: 127.0.0.1
-- Timp de generare: mai 04, 2023 la 05:26 PM
-- Versiune server: 10.4.27-MariaDB
-- Versiune PHP: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Bază de date: `parfum`
--

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `magazin`
--

CREATE TABLE `magazin` (
  `idMagazin` int(11) NOT NULL,
  `nume` varchar(20) NOT NULL,
  `adresa` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Eliminarea datelor din tabel `magazin`
--

INSERT INTO `magazin` (`idMagazin`, `nume`, `adresa`) VALUES
(1, 'Sephora Eroilor', 'Bulevardul Eroilor nr. 16, Cluj-Napoca, Cluj, 900674'),
(2, 'Sephora Tomis Mall', 'Bulevardul Tomis nr. 578, Constanța, Constanța, 800067'),
(3, 'Sephora Iulius Mall', 'Str. Aurel Vlaicu nr 578, Cluj-Napoca, Cluj, 800654');

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `parfum`
--

CREATE TABLE `parfum` (
  `idParfum` int(11) NOT NULL,
  `nume` varchar(20) NOT NULL,
  `producator` varchar(20) NOT NULL,
  `pret` float NOT NULL,
  `descriere` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Eliminarea datelor din tabel `parfum`
--

INSERT INTO `parfum` (`idParfum`, `nume`, `producator`, `pret`, `descriere`) VALUES
(1, 'HYPNÔSE', 'LANCÔME', 250, 'Apă de parfum pentru femei 30 ml. Parfumul care se împodobește cu un magnetism luminos și vibrant. Este o nouă poveste a întâlnirii dintre note și convingeri. În simbioză cu pielea, apa de toaletă își dezvăluie senzualitatea strălucitoare și accentele sale vanilate feerice. Suavă și lejeră, creează dependență.'),
(2, 'Ricci Ricci', 'NINA RICCI', 387, 'Apă de parfum pentru femei 30 ml.Ricci Ricci Eau De Parfum de la Nina Ricci întrupează o femeie urbană, senzuală și misterioasă. Veritabila expresie a stilului glamour și a îndrăznelii, apa de parfum Ricci Ricci seduce prin notele sale sclipitoare de rubarbă și de bergamotă, îmbinate cu subtilitatea acordului de regină nopții și sigilate prin caracterul misterios al aromei de patchouli. Această aromă florală, proaspătă și senzuală este evidențiată de flaconul sculptural decorat cu panglică.'),
(3, 'J\'adore', 'Dior', 578, 'Apă de parfum pentru femei, 100 ml. J\'adore Eau de Parfum este marele floral feminin al Casei Dior. Un buchet cizelat pana in cele mai mici detalii, ca o floare \"croita\" pe masura. Esenta de ylang-ylang cu note floral-fructate si esenta de trandafir de Damasc din Turcia se imbina cu un duet rar, compus din Iasomie grandiflorum de Grasse si Iasomie Sambac din India, de o senzualitate fructata si plina de voluptate. Flaconul J\'adore este la fel de feminin ca parfumul. Preluand liniile curbe si senzuale ale amforei emblematice create de Christian Dior, este impodobit cu legendarul colier Massai, asemeni unei bijuterii ce infrumuseteaza gatul unei femei. \"J\'adore este un parfum extraordinar, pentru ca reuseste sa seduca fara efort, avand o semnatura originala. E voluptuos, fara sa fie apasator. Este o compozitie care alatura contrariile, transformand notele florale emblematice intr-un ansamblu captivant, inedit si misterios. '),
(4, 'Sauvage', 'Dior', 700, 'Apă de parfum pentru bărbați 100 ml. Sauvage Eau de Parfum de la Dior este un parfum masculin inspirat de deșertul la apusul soarelui. Pentru Sauvage Eau de Parfum, Casa Dior a selectat o vanilie de o calitate excepțională, originară din Papua-Noua Guinee. Pe un fond lemnos-ambra, aceasta emană un exotism cu o latură gurmandă și îi conferă parfumului accente orientale senzuale.'),
(5, 'Aqua Allegoria Forte', 'GUERLAIN', 528, 'Apă de parfum pentru femei, 50 ml.Colecția de parfumuri Aqua Allegoria celebrează minunile lumii. Fiecare creație aduce un omagiu frumuseții naturii și ne îmbie să descoperim materii prime și note excepționale, magnific evidentiate de parfumierii noștri exploratori. Descoperiți Nerolia Vetiver Forte, strălucirea unui neroli învăluit de generozitatea acordului de smochine, căldura vetiverului și notele de migdală ale boabelor de tonka. '),
(6, 'La Vie Est Belle ', 'LANCÔME', 659, 'Apă de parfum pentru femei, 50 ml. Fericirea este o vibrație care trăiește în noi. Este efemeră, dar intensă. Rapidă, dar puternică. Este acum, aici! Pulsând în noua Apă de Parfum La Vie Est Belle Intensement. Trăiește viața din plin, aici și acum. Traiește fericirea în orice moment.Compoziția olfactivă a parfumului La Vie est Belle Intensement este alcătuită dintr-o inimă puternică și senzuală (iris, boabe de Vanilie, iasomie de Sambac, paciuli).'),
(7, 'JOY ', 'Dior', 431, 'Apă de parfum pentru femei, 30 ml. Bucuria este în sfârșit captată în notele unui parfum bland, învăluitor și, în același timp, plin de energie. O oda închinată plăcerii și vieții. Flaconul este prețios și luminos. Feminitatea transpare în argintiul său strălucitor și în rozul radios al lichidului care captivează instantaneu. Un fir strălucitor de culoarea argintului se înfășoară în jurul capacului, ca o bijuterie delicată, gravată cu finețe, pe care apare numele său, încolăcit într-un \"O\" perfe'),
(8, 'Dior Homme Intense', 'Dior', 496, 'Apă de parfum pentru bărbați, 50 ml. Întruchiparea nobleții și a rafinamentului într-o apă de parfum generoasă și vibrantă. Irisul intens, susținut de o fațetă de Ambra senzuală și de un fond lemnos încântător, emană un farmec puternic. O interpretare senzuală care lansează, prin ultimele note, o invitație.Notele parfumierului: Dior Homme evită toate clișeele masculine. Explorează un nou tip de virilitate: instantanee, dar totuși complexă.\" - Francois Demachy.\r\n'),
(9, 'La Nuit Trésor', 'LANCÔME', 408, 'Apă de parfum pentru femei, 50 ml. Fiecare 100 de ani, două stele se lovesc, irezistibil atrase una de cealaltă. Impactul generează mult prețuitul diamant negru. La Nuit Trésor este Diamantul Negru sub semnătura Lancôme. Acest parfum gurmand este semnătura femeii ce crede cu tărie în povestea de dragoste modernă. Iubirea la prima vedere. Sărutul fermecat. O noapte petrecută sub stele. Note de top: Lichior de liciu, Zmeură Note de mijloc: Esență de Trandafir Damascena, Tămâie Note de bază: Absolut de Orhidee de Vanilie Tahitensis, Pralină, Paciuli, Papirus.'),
(10, 'Hugo', 'Hugo Boss', 440, 'Apă de parfum pentru bărbați, 100 ml. Hugo de Hugo Boss este un parfum energizant și răcoritor, cu o compoziție lemnos-aquatică. Notele de măr și lavandă se combină perfect cu aromele de mentă și patchouli, creând o experiență olfactivă unică. Note de top: Măr, Grapefruit Note de mijloc: Lavandă, Menta Note de bază: Lemn de cedru, Patchouli.'),
(11, 'Black Opium', 'Yves Saint Laurent', 405, 'Apă de parfum pentru femei, 50 ml. Înspăimântător de fascinant și seducător, Black Opium de Yves Saint Laurent te învăluie într-o senzație misterioasă și încântătoare. Parfumul este o explozie de cafea neagră, completată de note florale și lemnoase. Note de top: Cafea, Piper Roz Note de mijloc: Iasomie, Vanilie, Flori albe Note de bază: Lemn de Cedru, Paciuli, Lemn de Santal.'),
(12, 'Good Girl', 'Carolina Herrera', 448, 'Apă de parfum pentru femei, 50 ml. Un parfum emblematic de la Carolina Herrera, Good Girl este un mix de arome îndrăznețe și contrastante, care reușește să surprindă și să fascineze. Notele florale și cele lemnoase se combină perfect pentru a crea o experiență olfactivă unică. Note de top: Migdale, Cafea Note de mijloc: Iasomie, Tuberose, Floare de Portocal Note de bază: Fava Tonka, Cacao, Lemn de Cedru.'),
(13, 'Gucci Bloom', 'Gucci', 526, 'Apă de parfum pentru femei, 50 ml. Gucci Bloom este un parfum floral, feminin și rafinat, care te poartă prin grădinile cu flori delicate. Compoziția este un mix subtil de arome florale și note lemnoase, care îți lasă o senzație de prospețime și vitalitate. Note de top: Tuberoză, Iasomie, Caprifoi Note de mijloc: Iris, Floare de Portocal Note de bază: Lemn de Cedru, Paciuli, Mosc Alb.'),
(14, 'Chloé', 'Chloé', 400, 'Apă de parfum pentru femei, 50 ml. Chloé este un parfum emblematic, cu note florale delicate și rafinate, care te poartă prin grădini înflorite. Compoziția este un mix subtil de arome de trandafir și magnolie, care îți lasă o senzație de prospețime și puritate. Note de top: Trandafir, Iasomie Note de mijloc: Magnolie Note de bază: Cedru, Lemn de Santal.'),
(15, 'Si', 'Giorgio Armani', 416, 'Apă de parfum pentru femei, 50 ml. Si de Giorgio Armani este un parfum sofisticat și seducător, care combină notele fructate cu cele florale și lemnoase. Compoziția este un mix subtil de arome de zmeură și vanilie, completate de note de trandafir și paciuli. Note de top: Fructe de pădure, Bergamotă Note de mijloc: Trandafir, Frezie Note de bază: Vanilie, Paciuli, Lemn de Cedru.'),
(16, 'Narciso Rodriguez fo', 'Narciso Rodriguez', 395, 'Apă de parfum pentru femei, 50 ml. Narciso Rodriguez for Her este un parfum seducător, cu o compoziție florală și lemnoasă. Notele delicate de flori albe se combină perfect cu aromele lemnoase, creând o experiență olfactivă unică. Note de top: Trandafir, Piersică, Mosc Note de mijloc: Ambră, Flori albe Note de bază: Cedru, Paciuli.'),
(17, 'Olympea', 'Paco Rabanne', 397, 'Apă de parfum pentru femei, 50 ml. Olympea de Paco Rabanne este un parfum seducător și sofisticat, cu note florale și lemnoase. Compoziția este un mix subtil de arome de jasmin și vanilie, completate de note de ambroxan și paciuli. Note de top: Tangerină verde, Gălbenele Note de mijloc: Jasmin, Ghimbir Note de bază: Vanilie, Ambroxan, Paciuli.'),
(18, 'Alien', 'Thierry Mugler', 778, 'Apă de parfum pentru femei, 75 ml. Alien de Thierry Mugler este un parfum misterios și seducător, cu o compoziție exotică și intensă. Notele florale și lemnoase se combină perfect cu aromele de vanilie și ambroxan, creând o experiență olfactivă unică. Note de top: Iasomie Sambac Note de mijloc: Lemn de Cachemire Note de bază: Ambroxan, Vanilie.'),
(19, 'Chance', 'Chanel', 607, 'Apă de parfum pentru femei, 100 ml. Chance de Chanel este un parfum elegant și sofisticat, cu o compoziție florală și lemnoasă. Notele delicate de flori albe se combină perfect cu aromele lemnoase și de vanilie, creând o experiență olfactivă unică. Note de top: Grapefruit, Piersică Note de mijloc: Iasomie, Jacintă Note de bază: Vanilie, Lemn de Cedru.'),
(20, 'La Petite Robe Noire', 'Guerlain', 598, 'Apă de parfum pentru femei, 50 ml. La Petite Robe Noire de Guerlain este un parfum delicat și romantic, cu o compoziție florală și fructată. Notele de cireșe negre se combină perfect cu aromele de trandafir și patchouli, creând o experiență olfactivă unică. Note de top: Cireșe negre, Migdale amare Note de mijloc: Trandafir, Lichior de ceai Note de bază: Patchouli, Vanilie, Mosc.'),
(21, 'Mon Guerlain', 'Guerlain', 530, 'Apă de parfum pentru femei, 50 ml. Mon Guerlain de Guerlain este un parfum sofisticat și senzual, cu o compoziție oriental-lemnoasă. Notele de lavandă și iasomie se combină perfect cu aromele de vanilie și lemn de santal, creând o experiență olfactivă unică. Note de top: Lavandă, Bergamotă Note de mijloc: Iasomie Note de bază: Vanilie, Lemn de santal.'),
(22, 'Acqua di Giò Profumo', 'Giorgio Armani', 600, 'Apă de parfum pentru bărbați, 100 ml. Acqua di Giò Profumo de Giorgio Armani este un parfum intens și sofisticat, cu o compoziție lemnoas-orientală. Notele de bergamotă și geraniu se combină perfect cu aromele de incens și piper, creând o experiență olfactivă unică. Note de top: Bergamotă, Geraniu Note de mijloc: Rozmarin, Sclipeți de marine Note de bază: Incens, Paciuli, Piper.'),
(23, 'Le Male', 'Jean Paul Gaultier', 380, 'Apă de parfum pentru bărbați, 75 ml. Le Male de Jean Paul Gaultier este un parfum clasic și seducător, cu o compoziție orientală. Notele de mentă și lavandă se combină perfect cu aromele de vanilie și scorțișoară, creând o experiență olfactivă unică. Note de top: Menta Note de mijloc: Lavandă Note de bază: Vanilie, Scorțișoară, Ambroxan.'),
(24, '1 Million', 'Paco Rabanne', 530, 'Apă de parfum pentru bărbați, 100 ml. 1 Million de Paco Rabanne este un parfum seducător și sofisticat, cu o compoziție lemnoas-orientală. Notele de grapefruit și mentă se combină perfect cu aromele de trandafir și scorțișoară, creând o experiență olfactivă unică. Note de top: Grapefruit, Menta Note de mijloc: Trandafir Note de bază: Ambra, Lemn de Cedru, Scorțișoară.'),
(25, 'Bleu de Chanel', 'Chanel', 610, 'Apă de parfum pentru bărbați, 100 ml. Bleu de Chanel de Chanel este un parfum sofisticat și intens, cu o compoziție lemnos-orientală. Notele de grapefruit și lămâie se combină perfect cu aromele de vetiver și ambroxan, creând o experiență olfactivă unică. Note de top: Grapefruit, Lămâie Note de mijloc: Ghimbir, Vetiver Note de bază: Cedru, Lemn de Santal, Ambroxan.'),
(26, 'The One for Men', 'Dolce & Gabbana', 485, 'Apă de parfum pentru bărbați, 100 ml. The One for Men de Dolce & Gabbana este un parfum elegant și sofisticat, cu o compoziție lemnos-orientală. Notele de grapefruit și coajă de portocală se combină perfect cu aromele de cedru și ambroxan, creând o experiență olfactivă unică. Note de top: Grapefruit, Coajă de portocală Note de mijloc: Cardamon, Ghimbir Note de bază: Cedru, Ambroxan, Vanilie.'),
(27, 'Boss Bottled', 'Hugo Boss', 450, 'Apă de parfum pentru bărbați, 100 ml. Boss Bottled de Hugo Boss este un parfum clasic și sofisticat, cu o compoziție lemnoas-orientală. Notele de măr și scorțișoară se combină perfect cu aromele de geraniu și vetiver, creând o experiență olfactivă unică. Note de top: Măr, Citrice Note de mijloc: Scorțișoară, Geraniu Note de bază: Lemn de Cedru, Vetiver.'),
(28, 'Coco Mademoiselle', 'Chanel', 660, 'Apă de parfum pentru femei, 50 ml. Coco Mademoiselle de Chanel este un parfum clasic și elegant, cu o compoziție floral-orientală. Notele de portocală și iasomie se combină perfect cu aromele de patchouli și vetiver, creând o experiență olfactivă unică. Note de top: Portocală, Bergamotă Note de mijloc: Iasomie, Trandafir Note de bază: Patchouli, Vetiver.'),
(29, 'Invictus', 'Paco Rabanne', 540, 'Apă de parfum pentru bărbați, 100 ml. Invictus de Paco Rabanne este un parfum seducător și energizant, cu o compoziție lemnos-marine. Notele de grapefruit și mentă se combină perfect cu aromele de mirodenii și lemn de guaiac, creând o experiență olfactivă unică. Note de top: Grapefruit, Coajă de portocală Note de mijloc: Mirodenii Note de bază: Lemn de Guaiac, Ambra cenușie.'),
(30, 'Dior Homme', 'Dior', 610, 'Apă de parfum pentru bărbați, 100 ml. Dior Homme de Dior este un parfum elegant și sofisticat, cu o compoziție florală și lemnoasă. Notele de lămâie și iris se combină perfect cu aromele de cedru și vetiver, creând o experiență olfactivă unică. Note de top: Lămâie, Bergamotă Note de mijloc: Iris, Ambroxan Note de bază: Cedru, Vetiver.'),
(31, 'The Scent', 'Hugo Boss', 520, 'Apă de parfum pentru bărbați, 100 ml. The Scent de Hugo Boss este un parfum seducător și intens, cu o compoziție lemnos-orientală. Notele de ghimbir și lavandă se combină perfect cu aromele de piele și lemn de santal, creând o experiență olfactivă unică. Note de top: Ghimbir, Bergamotă Note de mijloc: Lavandă, Maninka Note de bază: Piele, Lemn de santal.'),
(32, 'Emporio Armani Stron', 'Giorgio Armani', 530, 'Apă de parfum pentru bărbați, 100 ml. Emporio Armani Stronger With You de Giorgio Armani este un parfum seducător și intens, cu o compoziție lemnos-orientală. Notele de piper roz și frunze de violetă se combină perfect cu aromele de castană și vanilie, creând o experiență olfactivă unică. Note de top: Piper roz, Frunze de violete Note de mijloc: Castană Note de bază: Vanilie.'),
(33, 'L Homme', 'Yves Saint Laurent', 550, 'Apă de parfum pentru bărbați, 100 ml. L Homme de Yves Saint Laurent este un parfum elegant și sofisticat, cu o compoziție lemnos-florală. Notele de bergamotă și ghimbir se combină perfect cu aromele de lemn de cedru și vetiver, creând o experiență olfactivă unică. Note de top: Bergamotă, Ghimbir Note de mijloc: Flori de portocal, Piper roz Note de bază: Lemn de cedru, Vetiver.'),
(34, 'Fahrenheit', 'Dior', 590, 'Apă de parfum pentru bărbați, 100 ml. Fahrenheit de Dior este un parfum iconic și sofisticat, cu o compoziție lemnos-florală. Notele de lămâie și mușcate se combină perfect cu aromele de piele și lemn de santal, creând o experiență olfactivă unică. Note de top: Lămâie, Mușcate Note de mijloc: Violete Note de bază: Piele, Lemn de santal.'),
(35, 'Gentleman Givenchy', 'Givenchy', 580, 'Apă de parfum pentru bărbați, 100 ml. Gentleman Givenchy de Givenchy este un parfum clasic și sofisticat, cu o compoziție lemnoas-florală. Notele de bergamotă și cardamon se combină perfect cu aromele de iris și lemn de cedru, creând o experiență olfactivă unică. Note de top: Bergamotă, Cardamon Note de mijloc: Iris, Lavandă Note de bază: Lemn de cedru, Vetiver.'),
(36, 'Aventus', 'Creed', 1550, 'Apă de parfum pentru bărbați, 100 ml. Aventus de Creed este un parfum luxos și sofisticat, cu o compoziție lemnos-fructată. Notele de ananas și bergamotă se combină perfect cu aromele de mosc și lemn de cedru, creând o experiență olfactivă unică. Note de top: Ananas, Bergamotă Note de mijloc: Mosc Note de bază: Lemn de cedru, Paciuli.'),
(37, 'Gentleman Society', 'GIVENCHY', 480, 'Apă de parfum bărbați, 80 ml. Reinventeaza regulile cu Gentleman Society Eau de Parfum, parfumul masculin Givenchy ce redefineste conceptul de gentleman. Un parfum cu mai multe fatete ce creeaza un contrast intre nota de narcisa salbatica si acordul lemnos enigmatic. Realizat din ingrediente remarcabile, Gentleman Society este emblematic pentru maiestria si expertiza Givenchy. Notele de varf de salvie proaspata se combina cu acordurile florale ale absolutului de narcisa salbatica. Acest duo se alatura aromei intense si misterioase a acordurilor de Vetiver recoltat in Madagascar, Uruguay si Haiti. Aroma calda de vanilie este mixata cu esentele de lemn de santal si lemn de cedru ce ofera intensitate acestui parfum sofisticat pentru barbati. O declaratie indrazneata pentru gentlemanul modern. Designul flacoanelor Givenchy Gentleman este revizuit cu un accent de eleganta pura. Sigla 4 G reinterpretata in metal argintiu decoreaza sticla negru-lacuit. Flaconul este compus in proportie de 15%'),
(38, 'Elegance Divine', 'Dior', 520, 'Apă de parfum femei, 50 ml. Elegance Divine de la Dior este un parfum sofisticat si senzual, perfect pentru femeia moderna care doreste sa straluceasca. Cu note de varf de bergamot, ylang-ylang si trandafir, se dezvolta in inima de iasomie si vanilie, culminand intr-un amestec cald de mosc, ambra si lemn de santal. Flaconul elegant si rafinat completeaza perfect aura luxoasa a acestui parfum de exceptie.'),
(40, 'Floral Essence', 'GUCCI', 450, 'Apă de parfum femei, 30 ml. Floral Essence de la Gucci este un parfum delicat si fresh, conceput pentru femeia moderna si romantica. Combinand note de varf de piersica, coacaze rosii si lamaie, cu inima de frezie, magnolie si trandafir, acest parfum se incheie cu baza de mosc alb, cedru si ambra. Flaconul simplu si rafinat subliniaza eleganta acestui parfum feminin.'),
(41, 'Ocean Breeze', 'ARMANI', 480, 'Apă de parfum bărbați, 50 ml. Ocean Breeze de la Armani este un parfum proaspat si energizant, perfect pentru barbatul modern si dinamic. Cu note de varf de grapefruit, mandarina si piper roz, se desfasoara intr-o inima de lavanda, geranium si cardamom, in timp ce baza parfumului include lemn de santal, vetiver si paciuli. Flaconul elegant si modern completeaza perfect acest parfum rafinat.'),
(42, 'Velvet Dreams', 'YVES SAINT LAURENT', 550, 'Apă de parfum femei, 30 ml. Velvet Dreams de la Yves Saint Laurent este un parfum senzual si captivant, destinat femeii moderne si sofisticate. Cu note de varf de bergamot, coacaze negre si litchi, parfumul se dezvolta intr-o inima de iasomie, trandafir si patchouli, culminand cu baza calda de vanilie, ambra si lemn de santal. Flaconul luxos si rafinat reflecta perfect esenta acestui parfum seducator.');

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `parfummagazin`
--

CREATE TABLE `parfummagazin` (
  `idMagazin` int(11) NOT NULL,
  `idParfum` int(11) NOT NULL,
  `stoc` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Eliminarea datelor din tabel `parfummagazin`
--

INSERT INTO `parfummagazin` (`idMagazin`, `idParfum`, `stoc`) VALUES
(1, 1, 30),
(2, 1, 1),
(3, 1, 30),
(1, 2, 1),
(2, 2, 1),
(1, 3, 0),
(2, 3, 1),
(1, 4, 0),
(2, 4, 18),
(2, 5, 1),
(1, 6, 0),
(2, 6, 2),
(3, 6, 5),
(1, 7, 8),
(2, 7, 1),
(1, 8, 6),
(2, 8, 12),
(1, 9, 14),
(2, 9, 1),
(3, 9, 12),
(1, 10, 20),
(2, 10, 3),
(1, 11, 22),
(2, 11, 1),
(1, 12, 8),
(2, 12, 14),
(3, 12, 3),
(1, 13, 22),
(2, 13, 1),
(1, 14, 4),
(2, 14, 1),
(1, 15, 19),
(2, 15, 1),
(3, 15, 9),
(1, 16, 80),
(2, 16, 19),
(1, 17, 1),
(2, 17, 1),
(1, 18, 1),
(2, 18, 6),
(3, 18, 14),
(1, 19, 1),
(2, 19, 1),
(1, 20, 10),
(2, 20, 1),
(1, 21, 1),
(2, 21, 1),
(3, 21, 6),
(1, 22, 1),
(2, 22, 9),
(1, 23, 4),
(2, 23, 1),
(1, 24, 1),
(2, 24, 5),
(3, 24, 1),
(1, 25, 7),
(2, 25, 1),
(1, 26, 1),
(2, 26, 15),
(1, 27, 3),
(2, 27, 1),
(3, 27, 16),
(1, 28, 1),
(2, 28, 2),
(1, 29, 4),
(2, 29, 22),
(1, 30, 1),
(2, 30, 22),
(3, 30, 7),
(1, 31, 19),
(2, 31, 22),
(1, 32, 1),
(2, 32, 22),
(1, 33, 1),
(2, 33, 22),
(1, 34, 1),
(2, 34, 22),
(1, 35, 3),
(2, 35, 22),
(1, 36, 10),
(2, 36, 22),
(1, 37, 100),
(2, 37, 22),
(1, 38, 2),
(2, 38, 22),
(1, 40, 5),
(2, 40, 22),
(1, 41, 1),
(2, 41, 22),
(1, 42, 10),
(2, 42, 22);

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `parfum_translation`
--

CREATE TABLE `parfum_translation` (
  `idparfum` int(11) NOT NULL,
  `language` varchar(2) NOT NULL,
  `translated_descriere` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Eliminarea datelor din tabel `parfum_translation`
--

INSERT INTO `parfum_translation` (`idparfum`, `language`, `translated_descriere`) VALUES
(1, 'en', 'Eau de parfum for women 30 ml. Fragrance that adorns with a bright and vibrant magnetism. It is a new story of the meeting of notes and convictions. In symbiosis with the skin, the eau de toilette reveals its shimmering sensuality and its feeric vanilla accents. Soft and light, it is addictive.'),
(1, 'es', 'Eau de parfum para mujer 30 ml. Fragancia que adorna con un magnetismo brillante y vibrante. Es una nueva historia del encuentro de notas y convicciones. En simbiosis con la piel, el eau de toilette revela su sensualidad resplandeciente y sus acentos de vainilla feérica. Suave y ligera, es adictiva.'),
(1, 'fr', 'Eau de parfum pour femme 30 ml. Un parfum qui se pare d\'un magnétisme lumineux et vibrant. C\'est une nouvelle histoire, celle de la rencontre de notes et de convictions. En symbiose avec la peau, l\'eau de toilette révèle sa sensualité chatoyante et ses accents féeriques de vanille. Douce et légère, elle est addictive.'),
(1, 'ro', 'Apă de parfum pentru femei 30 ml. Parfumul care se împodobește cu un magnetism luminos și vibrant. Este o nouă poveste a întâlnirii dintre note și convingeri. În simbioză cu pielea, apa de toaletă își dezvăluie senzualitatea strălucitoare și accentele sale vanilate feerice. Suavă și lejeră, creează dependență.'),
(2, 'en', 'Perfume water for women 30ml. Ricci Ricci Eau De Parfum from Nina Ricci embodies an urban, sensual, and mysterious woman. A true expression of glamour and daring, Ricci Ricci perfume water seduces with its sparkling notes of rhubarb and bergamot, combined with the subtlety of the accord of queen of the night and sealed by the mysterious character of patchouli scent. This floral, fresh, and sensual scent is highlighted by the sculptural bottle decorated with a ribbon.'),
(2, 'es', 'Agua de perfume para mujeres 30 ml. Ricci Ricci Eau De Parfum de Nina Ricci encarna a una mujer urbana, sensual y misteriosa. Una verdadera expresión de glamour y atrevimiento, el agua de perfume Ricci Ricci seduce con sus notas brillantes de ruibarbo y bergamota, combinadas con la sutileza del acorde de la reina de la noche y selladas por el carácter misterioso del aroma del pachulí. Este aroma floral, fresco y sensual se destaca por el frasco escultural decorado con una cinta.'),
(2, 'fr', 'Eau de parfum pour femmes 30 ml. Ricci Ricci Eau De Parfum de Nina Ricci incarne une femme urbaine, sensuelle et mystérieuse. Une véritable expression de glamour et d\'audace, l\'eau de parfum Ricci Ricci séduit avec ses notes pétillantes de rhubarbe et de bergamote, combinées à la subtilité de l\'accord de la reine de la nuit et scellées par le caractère mystérieux de la senteur de patchouli. Ce parfum floral, frais et sensuel est mis en valeur par le flacon sculptural décoré d\'un ruban.'),
(2, 'ro', 'Apă de parfum pentru femei 30 ml.Ricci Ricci Eau De Parfum de la Nina Ricci întrupează o femeie urbană, senzuală și misterioasă. Veritabila expresie a stilului glamour și a îndrăznelii, apa de parfum Ricci Ricci seduce prin notele sale sclipitoare de rubarbă și de bergamotă, îmbinate cu subtilitatea acordului de regină nopții și sigilate prin caracterul misterios al aromei de patchouli. Această aromă florală, proaspătă și senzuală este evidențiată de flaconul sculptural decorat cu panglică.'),
(3, 'en', 'Perfume for women, 100 ml. J\'adore Eau de Parfum is the great feminine floral of the House of Dior. A chiseled bouquet to the smallest detail, like a flower \"tailored\" to perfection. The essence of ylang-ylang with floral-fruity notes and the essence of Damascus rose from Turkey blend with a rare duet, composed of Grasse grandiflorum jasmine and Sambac jasmine from India, of a fruity sensuality and full of voluptuousness. The J\'adore bottle is as feminine as the perfume. Taking the sensual curves of the emblematic amphora created by Christian Dior, it is adorned with the legendary Massai necklace, like a jewel that beautifies a woman\'s neck. \"J\'adore is an extraordinary perfume, because it manages to seduce effortlessly, having an original signature. It is voluptuous, without being overwhelming. It is a composition that brings together opposites, transforming emblematic floral notes into a captivating, innovative and mysterious whole.\r\n'),
(3, 'es', 'Perfume para mujeres, 100 ml. J\'adore Eau de Parfum es el gran floral femenino de la Casa de Dior. Un ramo cincelado hasta el más mínimo detalle, como una flor \"hecha a medida\". La esencia de ylang-ylang con notas florales y afrutadas y la esencia de rosa de Damasco de Turquía se mezclan con un dúo raro, compuesto por jazmín grandiflorum de Grasse y jazmín Sambac de India, de una sensualidad frutal y llena de voluptuosidad. El frasco de J\'adore es tan femenino como el perfume. Tomando las curvas sensuales del emblemático ánfora creado por Christian Dior, está adornado con el legendario collar Massai, como una joya que embellece el cuello de una mujer. \"J\'adore es un perfume extraordinario, porque logra seducir sin esfuerzo, teniendo una firma original. Es voluptuoso, sin ser abrumador. Es una composición que une opuestos, transformando notas florales emblemáticas en un todo cautivador, innovador y misterioso.\r\n'),
(3, 'fr', 'Parfum pour femmes, 100 ml. J\'adore Eau de Parfum est le grand floral féminin de la Maison Dior. Un bouquet ciselé jusqu\'au moindre détail, tel une fleur \"taillée sur mesure\". L\'essence d\'ylang-ylang aux notes florales et fruitées et l\'essence de rose de Damas de Turquie se mêlent à un duo rare, composé de jasmin grandiflorum de Grasse et de jasmin Sambac d\'Inde, d\'une sensualité fruitée et pleine de volupté. Le flacon de J\'adore est aussi féminin que le parfum. Reprenant les courbes sensuelles de l\'amphore emblématique créée par Christian Dior, il est orné du légendaire collier Massai, tel un bijou qui embellit le cou d\'une femme. \"J\'adore est un parfum extraordinaire, car il parvient à séduire sans effort, ayant une signature originale. Il est voluptueux, sans être étouffant. C\'est une composition qui rassemble les opposés, transformant les notes florales emblématiques en un tout captivant\r\n'),
(3, 'ro', 'Apă de parfum pentru femei, 100 ml. J\'adore Eau de Parfum este marele floral feminin al Casei Dior. Un buchet cizelat pana in cele mai mici detalii, ca o floare \"croita\" pe masura. Esenta de ylang-ylang cu note floral-fructate si esenta de trandafir de Damasc din Turcia se imbina cu un duet rar, compus din Iasomie grandiflorum de Grasse si Iasomie Sambac din India, de o senzualitate fructata si plina de voluptate. Flaconul J\'adore este la fel de feminin ca parfumul. Preluand liniile curbe si senzuale ale amforei emblematice create de Christian Dior, este impodobit cu legendarul colier Massai, asemeni unei bijuterii ce infrumuseteaza gatul unei femei. \"J\'adore este un parfum extraordinar, pentru ca reuseste sa seduca fara efort, avand o semnatura originala. E voluptuos, fara sa fie apasator. Este o compozitie care alatura contrariile, transformand notele florale emblematice intr-un ansamblu captivant, inedit si misterios. \r\n'),
(4, 'en', 'Perfume for men, 100 ml. Sauvage Eau de Parfum from Dior is a masculine fragrance inspired by the desert at sunset. For Sauvage Eau de Parfum, Dior has selected an exceptional quality vanilla from Papua New Guinea. On a woody-amber background, it emits an exoticism with a gourmet side and gives the perfume sensual oriental accents.\r\n'),
(4, 'es', 'Perfume para hombres, 100 ml. Sauvage Eau de Parfum de Dior es una fragancia masculina inspirada en el desierto al atardecer. Para Sauvage Eau de Parfum, la Casa Dior ha seleccionado una vainilla de una calidad excepcional, originaria de Papua Nueva Guinea. Sobre un fondo amaderado-ámbar, emana un exotismo con un lado gourmet y le da al perfume acentos orientales sensuales.\r\n'),
(4, 'fr', 'Parfum pour hommes, 100 ml. Sauvage Eau de Parfum de Dior est une fragrance masculine inspirée du désert au coucher du soleil. Pour Sauvage Eau de Parfum, Dior a sélectionné une vanille d\'une qualité exceptionnelle originaire de Papouasie-Nouvelle-Guinée. Sur un fond boisé-ambre, elle émet un exotisme avec un côté gourmand et donne au parfum des accents orientaux sensuels.\r\n'),
(4, 'ro', 'Apă de parfum pentru bărbați 100 ml. Sauvage Eau de Parfum de la Dior este un parfum masculin inspirat de deșertul la apusul soarelui. Pentru Sauvage Eau de Parfum, Casa Dior a selectat o vanilie de o calitate excepțională, originară din Papua-Noua Guinee. Pe un fond lemnos-ambra, aceasta emană un exotism cu o latură gurmandă și îi conferă parfumului accente orientale senzuale.\r\n'),
(5, 'en', 'Perfume for women, 50 ml. The Aqua Allegoria perfume collection celebrates the wonders of the world. Each creation pays homage to the beauty of nature and invites us to discover exceptional raw materials and notes, magnificently highlighted by our exploring perfumers. Discover Nerolia Vetiver Forte, the radiance of a neroli wrapped in the generosity of a fig accord, the warmth of vetiver and the almond notes of tonka beans.\r\n'),
(5, 'es', 'Perfume para mujeres, 50 ml. La colección de perfumes Aqua Allegoria celebra las maravillas del mundo. Cada creación rinde homenaje a la belleza de la naturaleza y nos invita a descubrir materias primas y notas excepcionales, magníficamente resaltadas por nuestros perfumistas exploradores. Descubre Nerolia Vetiver Forte, el brillo de un neroli envuelto en la generosidad de un acorde de higo, la calidez del vetiver y las notas de almendra de los granos de tonka.\r\n'),
(5, 'fr', 'Parfum pour femmes, 50 ml. La collection de parfums Aqua Allegoria célèbre les merveilles du monde. Chaque création rend hommage à la beauté de la nature et nous invite à découvrir des matières premières et des notes exceptionnelles, magnifiquement mises en valeur par nos parfumeurs explorateurs. Découvrez Nerolia Vetiver Forte, l\'éclat d\'un néroli enveloppé dans la générosité d\'un accord de figue, la chaleur du vétiver et les notes d\'amande des fèves de tonka.\r\n'),
(5, 'ro', 'Apă de parfum pentru femei, 50 ml.Colecția de parfumuri Aqua Allegoria celebrează minunile lumii. Fiecare creație aduce un omagiu frumuseții naturii și ne îmbie să descoperim materii prime și note excepționale, magnific evidentiate de parfumierii noștri exploratori. Descoperiți Nerolia Vetiver Forte, strălucirea unui neroli învăluit de generozitatea acordului de smochine, căldura vetiverului și notele de migdală ale boabelor de tonka. \r\n'),
(6, 'en', 'Perfume for women, 50 ml. Happiness is a vibration that lives within us. It is ephemeral but intense. Fast, but powerful. It is now, here! Pulsing in the new La Vie Est Belle Intensement Eau de Parfum. Live life to the fullest, here and now. Live happiness at any moment. The olfactory composition of the La Vie est Belle Intensement perfume is composed of a strong and sensual heart (iris, vanilla beans, jasmine sambac, patchouli).\r\n'),
(6, 'es', 'Perfume para mujeres, 50 ml. La felicidad es una vibración que vive dentro de nosotros. Es efímera pero intensa. Rápida, pero poderosa. ¡Está aquí y ahora! Pulsando en la nueva Agua de Perfume La Vie Est Belle Intensement. Vive la vida al máximo, aquí y ahora. Vive la felicidad en cualquier momento. La composición olfativa del perfume La Vie est Belle Intensement se compone de un corazón fuerte y sensual (iris, vainilla, jazmín sambac, pachulí).\r\n'),
(6, 'fr', 'Parfum pour femmes, 50 ml. Le bonheur est une vibration qui vit en nous. Il est éphémère mais intense. Rapide, mais puissant. C\'est maintenant, ici ! Pulsant dans le nouveau La Vie Est Belle Intensement Eau de Parfum. Vivez la vie à fond, ici et maintenant. Vivez le bonheur à tout moment. La composition olfactive du parfum La Vie est Belle Intensement est composée d\'un cœur fort et sensuel (iris, gousses de vanille, jasmin sambac, patchouli).\r\n'),
(6, 'ro', 'Apă de parfum pentru femei, 50 ml. Fericirea este o vibrație care trăiește în noi. Este efemeră, dar intensă. Rapidă, dar puternică. Este acum, aici! Pulsând în noua Apă de Parfum La Vie Est Belle Intensement. Trăiește viața din plin, aici și acum. Traiește fericirea în orice moment.Compoziția olfactivă a parfumului La Vie est Belle Intensement este alcătuită dintr-o inimă puternică și senzuală (iris, boabe de Vanilie, iasomie de Sambac, paciuli).\r\n'),
(7, 'en', 'Perfume for women, 30 ml. Joy is finally captured in the notes of a mild, enveloping, yet energetic perfume. An ode dedicated to pleasure and life. The bottle is precious and luminous. Femininity shines through its shiny silver and the bright pink of the liquid that captivates instantly. A shiny thread of silver wraps around the cap, like a delicate piece of jewelry, finely engraved with its name, curled up in a perfect \"O\".\r\n'),
(7, 'es', 'Perfume para mujeres, 30 ml. La alegría finalmente se captura en las notas de un perfume suave, envolvente y energético. Una oda dedicada al placer y la vida. La botella es preciosa y luminosa. La feminidad brilla a través de su plata brillante y el rosa brillante del líquido que cautiva al instante. Un hilo brillante de plata envuelve la tapa, como una delicada joya, finamente grabada con su nombre, enroscada en una \"O\" perfecta.\r\n'),
(7, 'fr', 'Parfum pour femmes, 30 ml. La joie est enfin capturée dans les notes d\'un parfum doux, enveloppant et énergique. Une ode dédiée au plaisir et à la vie. La bouteille est précieuse et lumineuse. La féminité transparaît à travers son argent brillant et le rose vif du liquide qui captive instantanément. Un fil brillant d\'argent enveloppe le capuchon, tel un bijou délicat, finement gravé de son nom, enroulé en une parfaite \"O\".\r\n'),
(7, 'ro', 'Apă de parfum pentru femei, 30 ml. Bucuria este în sfârșit captată în notele unui parfum bland, învăluitor și, în același timp, plin de energie. O oda închinată plăcerii și vieții. Flaconul este prețios și luminos. Feminitatea transpare în argintiul său strălucitor și în rozul radios al lichidului care captivează instantaneu. Un fir strălucitor de culoarea argintului se înfășoară în jurul capacului, ca o bijuterie delicată, gravată cu finețe, pe care apare numele său, încolăcit într-un \"O\" perfe\r\n'),
(8, 'en', 'Perfume for men, 50 ml. The embodiment of nobility and refinement in a generous and vibrant Eau de Parfum. The intense iris, supported by a facet of sensual amber and a charming woody base, emanates a strong charm. A sensual interpretation that launches an invitation through the final notes. The perfumer\'s notes: Dior Homme avoids all masculine clichés. It explores a new type of virility: instantaneous, yet complex.\" - Francois Demachy.\r\n'),
(8, 'es', 'Perfume para hombres, 50 ml. La encarnación de la nobleza y la refinación en un Eau de Parfum generoso y vibrante. El intenso iris, respaldado por una faceta de ámbar sensual y una base encantadora de madera, emana un fuerte encanto. Una interpretación sensual que lanza una invitación a través de las notas finales. Las notas del perfumista: Dior Homme evita todos los clichés masculinos. Explora un nuevo tipo de virilidad: instantánea, pero compleja.\" - Francois Demachy\r\n'),
(8, 'fr', 'Parfum pour hommes, 50 ml. L\'incarnation de la noblesse et du raffinement dans un Eau de Parfum généreux et vibrant. L\'iris intense, soutenu par une facette d\'ambre sensuel et une base charmante de bois, émane d\'un fort charme. Une interprétation sensuelle qui lance une invitation à travers les notes finales. Les notes du parfumeur: Dior Homme évite tous les clichés masculins. Il explore un nouveau type de virilité : instantanée, mais complexe.\" - Francois Demachy.\r\n'),
(8, 'ro', 'Apă de parfum pentru bărbați, 50 ml. Întruchiparea nobleții și a rafinamentului într-o apă de parfum generoasă și vibrantă. Irisul intens, susținut de o fațetă de Ambra senzuală și de un fond lemnos încântător, emană un farmec puternic. O interpretare senzuală care lansează, prin ultimele note, o invitație.Notele parfumierului: Dior Homme evită toate clișeele masculine. Explorează un nou tip de virilitate: instantanee, dar totuși complexă.\" - Francois Demachy.\r\n'),
(9, 'en', 'Perfume for women, 50 ml. Every 100 years, two stars collide, irresistibly drawn to each other. The impact generates the much-prized black diamond. La Nuit Trésor is the Black Diamond under the signature of Lancôme. This gourmand fragrance is the signature of the woman who strongly believes in the modern love story. Love at first sight. The enchanted kiss. A night spent under the stars. Top notes: Lychee liquor, Raspberry Middle notes: Essence of Damascus Rose, Frankincense Base notes: Absolute of Vanilla Tahitensis Orchid, Praline, Patchouli, Papyrus.\r\n'),
(9, 'es', 'Perfume para mujeres, 50 ml. Cada 100 años, dos estrellas colisionan, irresistiblemente atraídas una por la otra. El impacto genera el codiciado diamante negro. La Nuit Trésor es el Diamante Negro bajo la firma de Lancôme. Esta fragancia gourmand es la firma de la mujer que cree firmemente en la historia de amor moderna. Amor a primera vista. El beso encantado. Una noche bajo las estrellas. Notas principales: licor de lichi, frambuesa Notas medias: Esencia de Rosa de Damasco, Incienso Notas de base: Absoluto de Orquídea de Vainilla Tahitensis, Praliné, Pachulí, Papiro.\r\n'),
(9, 'fr', 'Parfum pour femmes, 50 ml. Tous les 100 ans, deux étoiles se heurtent, attirées irrésistiblement l\'une par l\'autre. L\'impact génère le diamant noir tant prisé. La Nuit Trésor est le Diamant Noir sous la signature de Lancôme. Cette fragrance gourmande est la signature de la femme qui croit fermement en l\'histoire d\'amour moderne. Amour au premier regard. Le baiser enchanté. Une nuit passée sous les étoiles. Notes de tête: Liqueur de Litchi, Framboise Notes de cœur: Essence de Rose de Damas, Encens Notes de fond: Absolu d\'Orchidée Vanille Tahitensis, Praliné, Patchouli, Papyrus.\r\n'),
(9, 'ro', 'Apă de parfum pentru femei, 50 ml. Fiecare 100 de ani, două stele se lovesc, irezistibil atrase una de cealaltă. Impactul generează mult prețuitul diamant negru. La Nuit Trésor este Diamantul Negru sub semnătura Lancôme. Acest parfum gurmand este semnătura femeii ce crede cu tărie în povestea de dragoste modernă. Iubirea la prima vedere. Sărutul fermecat. O noapte petrecută sub stele. Note de top: Lichior de liciu, Zmeură Note de mijloc: Esență de Trandafir Damascena, Tămâie Note de bază: Absolut de Orhidee de Vanilie Tahitensis, Pralină, Paciuli, Papirus.\r\n'),
(10, 'en', 'Perfume for men, 100 ml. Hugo by Hugo Boss is an energizing and refreshing fragrance with a woody-aquatic composition. Notes of apple and lavender perfectly combine with hints of mint and patchouli, creating a unique olfactory experience.\r\n'),
(10, 'es', 'Perfume para hombres, 100 ml. Hugo de Hugo Boss es una fragancia energizante y refrescante con una composición acuática-amaderada. Las notas de manzana y lavanda se combinan perfectamente con los toques de menta y patchouli, creando una experiencia olfativa única.\r\n'),
(10, 'fr', 'Parfum pour hommes, 100 ml. Hugo de Hugo Boss est une fragrance énergisante et rafraîchissante avec une composition boisée-aquatique. Les notes de pomme et de lavande se combinent parfaitement avec des nuances de menthe et de patchouli, créant une expérience olfactive unique.\r\n'),
(10, 'ro', 'Apă de parfum pentru bărbați, 100 ml. Hugo de Hugo Boss este un parfum energizant și răcoritor, cu o compoziție lemnos-aquatică. Notele de măr și lavandă se combină perfect cu aromele de mentă și patchouli, creând o experiență olfactivă unică. Note de top: Măr, Grapefruit Note de mijloc: Lavandă, Menta Note de bază: Lemn de cedru, Patchouli.\r\n'),
(11, 'en', 'Perfume for women, 50 ml. Scarily fascinating and seductive, Black Opium by Yves Saint Laurent envelops you in a mysterious and enchanting sensation. The perfume is an explosion of black coffee, complemented by floral and woody notes. Top notes: Coffee, Pink Pepper. Middle notes: Jasmine, Vanilla, White Flowers. Base notes: Cedarwood, Patchouli, Sandalwood.\r\n'),
(11, 'es', 'Perfume para mujeres, 50 ml. Aterradora de fascinante y seductora, Black Opium de Yves Saint Laurent te envuelve en una sensación misteriosa y encantadora. El perfume es una explosión de café negro, complementado con notas florales y amaderadas. Notas de salida: café, pimienta rosa. Notas de corazón: jazmín, vainilla, flores blancas. Notas de fondo: madera de cedro, pachulí, madera de sándalo.\r\n'),
(11, 'fr', 'Parfum pour femmes, 50 ml. Effrayamment fascinant et séduisant, Black Opium d\'Yves Saint Laurent vous enveloppe dans une sensation mystérieuse et enchanteuse. Le parfum est une explosion de café noir, complétée par des notes florales et boisées. Notes de tête : Café, Poivre Rose. Notes de cœur : Jasmin, Vanille, Fleurs Blanches. Notes de fond : Bois de Cèdre, Patchouli, Bois de Santal.\r\n'),
(11, 'ro', 'Apă de parfum pentru femei, 50 ml. Înspăimântător de fascinant și seducător, Black Opium de Yves Saint Laurent te învăluie într-o senzație misterioasă și încântătoare. Parfumul este o explozie de cafea neagră, completată de note florale și lemnoase. Note de top: Cafea, Piper Roz Note de mijloc: Iasomie, Vanilie, Flori albe Note de bază: Lemn de Cedru, Paciuli, Lemn de Santal.\r\n'),
(12, 'en', 'An Eau de Parfum for women, 50 ml. An iconic perfume from Carolina Herrera, Good Girl is a mix of bold and contrasting aromas that manages to surprise and fascinate. Floral and woody notes combine perfectly to create a unique olfactory experience. Top notes: Almonds, Coffee. Middle notes: Jasmine, Tuberose, Orange Blossom. Base notes: Tonka Bean, Cocoa, Cedarwood.\r\n'),
(12, 'es', 'Una fragancia de Eau de Parfum para mujeres, 50 ml. Un perfume icónico de Carolina Herrera, Good Girl es una mezcla de aromas atrevidos y contrastantes que logra sorprender y fascinar. Las notas florales y las notas amaderadas se combinan perfectamente para crear una experiencia olfativa única. Notas altas: Almendras, Café. Notas medias: Jazmín, Tuberosa, Flor de naranjo. Notas base: Habas Tonka, Cacao, Cedro.\r\n'),
(12, 'fr', 'Une Eau de Parfum pour femmes, 50 ml. Un parfum emblématique de Carolina Herrera, Good Girl est un mélange d\'arômes audacieux et contrastants qui parvient à surprendre et à fasciner. Les notes florales et les notes boisées se combinent parfaitement pour créer une expérience olfactive unique. Notes de tête : Amandes, Café. Notes de cœur : Jasmin, Tubéreuse, Fleur d\'oranger. Notes de fond : Fève Tonka, Cacao, Bois de cèdre.\r\n'),
(12, 'ro', 'Apă de parfum pentru femei, 50 ml. Un parfum emblematic de la Carolina Herrera, Good Girl este un mix de arome îndrăznețe și contrastante, care reușește să surprindă și să fascineze. Notele florale și cele lemnoase se combină perfect pentru a crea o experiență olfactivă unică. Note de top: Migdale, Cafea Note de mijloc: Iasomie, Tuberose, Floare de Portocal Note de bază: Fava Tonka, Cacao, Lemn de Cedru.\r\n'),
(13, 'en', 'Perfume for women, 50 ml. Gucci Bloom is a floral, feminine, and refined perfume that takes you through gardens with delicate flowers. The composition is a subtle mix of floral aromas and woody notes that leave you with a feeling of freshness and vitality.\r\n'),
(13, 'es', 'Perfume para mujeres, 50 ml. Gucci Bloom es un perfume floral, femenino y refinado que te lleva a través de jardines con flores delicadas. La composición es una mezcla sutil de aromas florales y notas amaderadas que te dejan una sensación de frescura y vitalidad.\r\n'),
(13, 'fr', 'Parfum pour femmes, 50 ml. Gucci Bloom est un parfum floral, féminin et raffiné qui vous emmène à travers des jardins avec des fleurs délicates. La composition est un mélange subtil d\'arômes floraux et de notes boisées qui vous laisse une sensation de fraîcheur et de vitalité.\r\n'),
(13, 'ro', 'Apă de parfum pentru femei, 50 ml. Gucci Bloom este un parfum floral, feminin și rafinat, care te poartă prin grădinile cu flori delicate. Compoziția este un mix subtil de arome florale și note lemnoase, care îți lasă o senzație de prospețime și vitalitate. Note de top: Tuberoză, Iasomie, Caprifoi Note de mijloc: Iris, Floare de Portocal Note de bază: Lemn de Cedru, Paciuli, Mosc Alb.\r\n'),
(14, 'en', 'Perfume for women, 50 ml. Chloé is an emblematic fragrance, with delicate and refined floral notes, which takes you through blooming gardens. The composition is a subtle mix of rose and magnolia aromas, leaving you with a feeling of freshness and purity. Top notes: Rose, Jasmine Middle notes: Magnolia Base notes: Cedar, Sandalwood.\r\n'),
(14, 'es', 'Perfume para mujeres, 50 ml. Chloé es una fragancia emblemática, con notas florales delicadas y refinadas, que te lleva a través de jardines en flor. La composición es una mezcla sutil de aromas de rosa y magnolia, dejándote con una sensación de frescura y pureza. Notas de salida: rosa, jazmín. Notas medias: magnolia. Notas de base: cedro, sándalo.\r\n'),
(14, 'fr', 'Parfum pour femmes, 50 ml. Chloé est un parfum emblématique, avec des notes florales délicates et raffinées, qui vous emmène à travers des jardins en fleurs. La composition est un mélange subtil d\'arômes de rose et de magnolia, vous laissant une sensation de fraîcheur et de pureté. Notes de tête : Rose, Jasmin. Notes de cœur : Magnolia. Notes de fond : Cèdre, Bois de santal.\r\n'),
(14, 'ro', 'Apă de parfum pentru femei, 50 ml. Chloé este un parfum emblematic, cu note florale delicate și rafinate, care te poartă prin grădini înflorite. Compoziția este un mix subtil de arome de trandafir și magnolie, care îți lasă o senzație de prospețime și puritate. Note de top: Trandafir, Iasomie Note de mijloc: Magnolie Note de bază: Cedru, Lemn de Santal.\r\n'),
(15, 'en', 'An agua de perfume for women, 50 ml. Si by Giorgio Armani is a sophisticated and seductive perfume that combines fruity, floral, and woody notes. The composition is a subtle mix of raspberry and vanilla scents, complemented by rose and patchouli notes.\r\n'),
(15, 'es', 'Una fragancia de agua de perfume para mujeres, 50 ml. Si de Giorgio Armani es una fragancia sofisticada y seductora que combina notas frutales con notas florales y amaderadas. La composición es una mezcla sutil de aromas de frambuesa y vainilla, completada con notas de rosa y pachulí.\r\n'),
(15, 'fr', 'Une eau de parfum pour femmes, 50 ml. Si de Giorgio Armani est un parfum sophistiqué et séduisant qui combine des notes fruitées, florales et boisées. La composition est un mélange subtil de framboise et de vanille, complété par des notes de rose et de patchouli.\r\n'),
(15, 'ro', 'Apă de parfum pentru femei, 50 ml. Si de Giorgio Armani este un parfum sofisticat și seducător, care combină notele fructate cu cele florale și lemnoase. Compoziția este un mix subtil de arome de zmeură și vanilie, completate de note de trandafir și paciuli. Note de top: Fructe de pădure, Bergamotă Note de mijloc: Trandafir, Frezie Note de bază: Vanilie, Paciuli, Lemn de Cedru.\r\n'),
(16, 'en', 'Perfume for women, 50 ml. Narciso Rodriguez for Her is a seductive perfume with a floral and woody composition. Delicate notes of white flowers blend perfectly with woody aromas, creating a unique olfactory experience. Top notes: Rose, Peach, Musk. Middle notes: Amber, White flowers. Base notes: Cedar, Patchouli.\r\n'),
(16, 'es', 'Perfume para mujeres, 50 ml. Narciso Rodriguez for Her es un perfume seductor con una composición floral y amaderada. Las delicadas notas de flores blancas se combinan perfectamente con aromas amaderados, creando una experiencia olfativa única. Notas de salida: Rosa, Melocotón, Almizcle. Notas medias: Ámbar, Flores blancas. Notas de fondo: Cedro, Pachulí.\r\n'),
(16, 'fr', 'Parfum pour femmes, 50 ml. Narciso Rodriguez for Her est un parfum séduisant avec une composition florale et boisée. Les notes délicates de fleurs blanches se marient parfaitement aux arômes boisés, créant une expérience olfactive unique. Notes de tête : Rose, Pêche, Musc. Notes de cœur : Ambre, Fleurs blanches. Notes de fond : Cèdre, Patchouli.\r\n'),
(16, 'ro', 'Apă de parfum pentru femei, 50 ml. Narciso Rodriguez for Her este un parfum seducător, cu o compoziție florală și lemnoasă. Notele delicate de flori albe se combină perfect cu aromele lemnoase, creând o experiență olfactivă unică. Note de top: Trandafir, Piersică, Mosc Note de mijloc: Ambră, Flori albe Note de bază: Cedru, Paciuli.\r\n'),
(17, 'en', 'Perfume for women, 50 ml. Olympea by Paco Rabanne is a seductive and sophisticated fragrance with floral and woody notes. The composition is a subtle mix of jasmine and vanilla aromas, complemented by notes of ambroxan and patchouli. Top notes: green mandarin, Calendula. Middle notes: jasmine, ginger. Base notes: vanilla, ambroxan, patchouli.\r\n'),
(17, 'es', 'Perfume para mujeres, 50 ml. Olympea de Paco Rabanne es una fragancia seductora y sofisticada con notas florales y amaderadas. La composición es una sutil mezcla de aromas de jazmín y vainilla, complementados con notas de ambroxan y pachulí. Notas de salida: mandarina verde, caléndula. Notas de corazón: jazmín, jengibre. Notas de fondo: vainilla, ambroxan, pachulí.\r\n'),
(17, 'fr', 'Parfum pour femmes, 50 ml. Olympea de Paco Rabanne est un parfum séduisant et sophistiqué aux notes florales et boisées. La composition est un mélange subtil d\'arômes de jasmin et de vanille, complété par des notes d\'ambroxan et de patchouli. Notes de tête : mandarine verte, calendula. Notes de cœur : jasmin, gingembre. Notes de fond : vanille, ambroxan, patchouli.\r\n'),
(17, 'ro', 'Apă de parfum pentru femei, 50 ml. Olympea de Paco Rabanne este un parfum seducător și sofisticat, cu note florale și lemnoase. Compoziția este un mix subtil de arome de jasmin și vanilie, completate de note de ambroxan și paciuli. Note de top: Tangerină verde, Gălbenele Note de mijloc: Jasmin, Ghimbir Note de bază: Vanilie, Ambroxan, Paciuli.\r\n'),
(18, 'en', 'Perfume for women, 75 ml. Alien by Thierry Mugler is a mysterious and seductive fragrance with an exotic and intense composition. Floral and woody notes perfectly combine with vanilla and ambroxan, creating a unique olfactory experience. Top notes: Sambac jasmine. Middle notes: Cashmere wood. Base notes: Ambroxan, Vanilla.\r\n'),
(18, 'es', 'Perfume para mujeres, 75 ml. Alien de Thierry Mugler es una fragancia misteriosa y seductora, con una composición exótica e intensa. Las notas florales y amaderadas se combinan perfectamente con vainilla y ambroxan, creando una experiencia olfativa única. Notas de salida: jazmín Sambac. Notas de corazón: madera de cachemira. Notas de fondo: ambroxan, vainilla.\r\n'),
(18, 'fr', 'Parfum pour femmes, 75 ml. Alien de Thierry Mugler est un parfum mystérieux et séduisant avec une composition exotique et intense. Les notes florales et boisées se combinent parfaitement avec la vanille et l\'ambroxan, créant une expérience olfactive unique. Notes de tête : jasmin Sambac. Notes de cœur : bois de cachemire. Notes de fond : ambroxan, vanille.\r\n'),
(18, 'ro', 'Apă de parfum pentru femei, 75 ml. Alien de Thierry Mugler este un parfum misterios și seducător, cu o compoziție exotică și intensă. Notele florale și lemnoase se combină perfect cu aromele de vanilie și ambroxan, creând o experiență olfactivă unică. Note de top: Iasomie Sambac Note de mijloc: Lemn de Cachemire Note de bază: Ambroxan, Vanilie.\r\n'),
(19, 'en', 'Chance by Chanel is an elegant and sophisticated women\'s perfume with a floral and woody composition. Delicate notes of white flowers perfectly blend with woody and vanilla scents, creating a unique olfactory experience. Top notes: Grapefruit, Peach. Middle notes: Jasmine, Hyacinth. Base notes: Vanilla, Cedarwood.\r\n'),
(19, 'es', 'Chance de Chanel es un perfume elegante y sofisticado para mujeres con una composición floral y amaderada. Las notas delicadas de flores blancas se combinan perfectamente con los aromas amaderados y de vainilla, creando una experiencia olfativa única. Notas de salida: Pomelo, Durazno. Notas medias: Jazmín, Jacinto. Notas de fondo: Vainilla, Madera de Cedro.\r\n'),
(19, 'fr', 'Chance de Chanel est un parfum élégant et sophistiqué pour femmes avec une composition florale et boisée. Les notes délicates de fleurs blanches se mêlent parfaitement aux senteurs boisées et vanillées, créant une expérience olfactive unique. Notes de tête : Pamplemousse, Pêche. Notes de cœur : Jasmin, Jacinthe. Notes de fond : Vanille, Bois de Cèdre.\r\n'),
(19, 'ro', 'Apă de parfum pentru femei, 100 ml. Chance de Chanel este un parfum elegant și sofisticat, cu o compoziție florală și lemnoasă. Notele delicate de flori albe se combină perfect cu aromele lemnoase și de vanilie, creând o experiență olfactivă unică. Note de top: Grapefruit, Piersică Note de mijloc: Iasomie, Jacintă Note de bază: Vanilie, Lemn de Cedru.\r\n'),
(20, 'en', 'Perfume for women, 100 ml. Chance by Chanel is an elegant and sophisticated perfume, with a floral and woody composition. The delicate notes of white flowers blend perfectly with woody and vanilla aromas, creating a unique olfactory experience. Top notes: Grapefruit, Peach. Middle notes: Jasmine, Hyacinth. Base notes: Vanilla, Cedarwood.\r\n'),
(20, 'es', 'Perfume para mujeres, 100 ml. Chance de Chanel es un perfume elegante y sofisticado, con una composición floral y amaderada. Las notas delicadas de flores blancas se combinan perfectamente con aromas amaderados y de vainilla, creando una experiencia olfativa única. Notas de salida: Pomelo, Melocotón. Notas de corazón: Jazmín, Jacinto. Notas de fondo: Vainilla, Cedro.\r\n'),
(20, 'fr', 'Parfum pour femmes, 100 ml. Chance de Chanel est un parfum élégant et sophistiqué, avec une composition florale et boisée. Les notes délicates de fleurs blanches se marient parfaitement avec des arômes boisés et de vanille, créant une expérience olfactive unique. Notes de tête : Pamplemousse, Pêche. Notes de cœur : Jasmin, Jacinthe. Notes de fond : Vanille, Cèdre.\r\n'),
(20, 'ro', 'Apă de parfum pentru femei, 50 ml. La Petite Robe Noire de Guerlain este un parfum delicat și romantic, cu o compoziție florală și fructată. Notele de cireșe negre se combină perfect cu aromele de trandafir și patchouli, creând o experiență olfactivă unică. Note de top: Cireșe negre, Migdale amare Note de mijloc: Trandafir, Lichior de ceai Note de bază: Patchouli, Vanilie, Mosc.\r\n'),
(21, 'en', 'Women\'s Eau de Parfum, 50 ml. La Petite Robe Noire by Guerlain is a delicate and romantic fragrance, with a floral and fruity composition. The notes of black cherries blend perfectly with the scents of rose and patchouli, creating a unique olfactory experience\r\n'),
(21, 'es', 'Agua de perfume para mujeres, 50 ml. La Petite Robe Noire de Guerlain es una fragancia delicada y romántica, con una composición floral y frutal. Las notas de cerezas negras se combinan perfectamente con los aromas de rosa y patchouli, creando una experiencia olfativa única\r\n'),
(21, 'fr', 'Eau de Parfum pour femmes, 50 ml. La Petite Robe Noire de Guerlain est un parfum délicat et romantique, avec une composition florale et fruitée. Les notes de cerises noires se marient parfaitement aux parfums de rose et de patchouli, créant une expérience olfactive unique.\r\n'),
(21, 'ro', 'Apă de parfum pentru femei, 50 ml. Mon Guerlain de Guerlain este un parfum sofisticat și senzual, cu o compoziție oriental-lemnoasă. Notele de lavandă și iasomie se combină perfect cu aromele de vanilie și lemn de santal, creând o experiență olfactivă unică. Note de top: Lavandă, Bergamotă Note de mijloc: Iasomie Note de bază: Vanilie, Lemn de santal.\r\n'),
(22, 'en', 'Men\'s eau de parfum, 100 ml. Acqua di Giò Profumo by Giorgio Armani is an intense and sophisticated perfume, with a woody-oriental composition. Notes of bergamot and geranium blend perfectly with aromas of incense and pepper, creating a unique olfactory experience.\r\n'),
(22, 'es', 'Agua de perfume para hombres, 100 ml. Acqua di Giò Profumo de Giorgio Armani es una fragancia intensa y sofisticada, con una composición oriental-amaderada. Las notas de bergamota y geranio se combinan perfectamente con los aromas de incienso y pimienta, creando una experiencia olfativa única.\r\n'),
(22, 'fr', 'Eau de parfum pour hommes, 100 ml. Acqua di Giò Profumo de Giorgio Armani est un parfum intense et sophistiqué, avec une composition boisée-orientale. Les notes de bergamote et de géranium se marient parfaitement avec les arômes d\'encens et de poivre, créant une expérience olfactive unique.\r\n'),
(22, 'ro', 'Apă de parfum pentru bărbați, 100 ml. Acqua di Giò Profumo de Giorgio Armani este un parfum intens și sofisticat, cu o compoziție lemnoas-orientală. Notele de bergamotă și geraniu se combină perfect cu aromele de incens și piper, creând o experiență olfactivă unică. Note de top: Bergamotă, Geraniu Note de mijloc: Rozmarin, Sclipeți de marine Note de bază: Incens, Paciuli, Piper.\r\n'),
(23, 'en', 'Perfume for men, 75 ml. Le Male by Jean Paul Gaultier is a classic and seductive fragrance with an oriental composition. Notes of mint and lavender combine perfectly with aromas of vanilla and cinnamon, creating a unique olfactory experience. Top notes: Mint Middle notes: Lavender Base notes: Vanilla, Cinnamon, Ambroxan.\r\n'),
(23, 'es', 'Perfume para hombres, 75 ml. Le Male de Jean Paul Gaultier es una fragancia clásica y seductora con una composición oriental. Las notas de menta y lavanda combinan perfectamente con aromas de vainilla y canela, creando una experiencia olfativa única. Notas de salida: menta Notas medias: lavanda Notas de base: vainilla, canela, ambroxan.\r\n'),
(23, 'fr', 'Parfum pour hommes, 75 ml. Le Male de Jean Paul Gaultier est un parfum classique et séduisant avec une composition orientale. Les notes de menthe et de lavande se combinent parfaitement avec des arômes de vanille et de cannelle, créant une expérience olfactive unique. Notes de tête: menthe Notes de cœur: lavande Notes de fond: vanille, cannelle, ambroxan.\r\n'),
(23, 'ro', 'Apă de parfum pentru bărbați, 75 ml. Le Male de Jean Paul Gaultier este un parfum clasic și seducător, cu o compoziție orientală. Notele de mentă și lavandă se combină perfect cu aromele de vanilie și scorțișoară, creând o experiență olfactivă unică. Note de top: Menta Note de mijloc: Lavandă Note de bază: Vanilie, Scorțișoară, Ambroxan.\r\n'),
(24, 'en', 'Perfume for men, 75 ml. Le Male by Jean Paul Gaultier is a classic and seductive perfume, with an oriental composition. The notes of mint and lavender perfectly blend with the aromas of vanilla and cinnamon, creating a unique olfactory experience. Top notes: Mint. Middle notes: Lavender. Base notes: Vanilla, Cinnamon, Ambroxan.\r\n'),
(24, 'es', 'Perfume para hombres, 75 ml. Le Male de Jean Paul Gaultier es un perfume clásico y seductor, con una composición oriental. Las notas de menta y lavanda se combinan perfectamente con los aromas de vainilla y canela, creando una experiencia olfativa única. Notas de salida: Menta. Notas de corazón: Lavanda. Notas de fondo: Vainilla, Canela, Ambroxan.\r\n'),
(24, 'fr', 'Parfum pour homme, 75 ml. Le Male de Jean Paul Gaultier est un parfum classique et séduisant, avec une composition orientale. Les notes de menthe et de lavande se marient parfaitement aux arômes de vanille et de cannelle, créant une expérience olfactive unique. Notes de tête: Menthe. Notes de cœur: Lavande. Notes de fond: Vanille, Cannelle, Ambroxan.\r\n'),
(24, 'ro', 'Apă de parfum pentru bărbați, 100 ml. 1 Million de Paco Rabanne este un parfum seducător și sofisticat, cu o compoziție lemnoas-orientală. Notele de grapefruit și mentă se combină perfect cu aromele de trandafir și scorțișoară, creând o experiență olfactivă unică. Note de top: Grapefruit, Menta Note de mijloc: Trandafir Note de bază: Ambra, Lemn de Cedru, Scorțișoară.\r\n'),
(25, 'en', 'Perfume for men, 100 ml. Bleu de Chanel by Chanel is a sophisticated and intense fragrance with a woody-oriental composition. The notes of grapefruit and lemon combine perfectly with the scents of vetiver and ambroxan, creating a unique olfactory experience. Top notes: grapefruit, lemon. Middle notes: ginger, vetiver. Base notes: cedar, sandalwood, ambroxan.\r\n'),
(25, 'es', 'Perfume para hombres, 100 ml. Bleu de Chanel de Chanel es una fragancia sofisticada e intensa con una composición oriental amaderada. Las notas de pomelo y limón combinan perfectamente con los aromas de vetiver y ambroxan, creando una experiencia olfativa única. Notas de cabeza: pomelo, limón. Notas de corazón: jengibre, vetiver. Notas de base: cedro, sándalo, ambroxan.\r\n'),
(25, 'fr', 'Parfum pour hommes, 100 ml. Bleu de Chanel de Chanel est un parfum sophistiqué et intense avec une composition boisée-orientale. Les notes de pamplemousse et de citron se marient parfaitement avec les parfums de vétiver et d\'ambroxan, créant une expérience olfactive unique. Notes de tête : pamplemousse, citron. Notes de cœur : gingembre, vétiver. Notes de base : cèdre, santal, ambroxan.\r\n'),
(25, 'ro', 'Apă de parfum pentru bărbați, 100 ml. Bleu de Chanel de Chanel este un parfum sofisticat și intens, cu o compoziție lemnos-orientală. Notele de grapefruit și lămâie se combină perfect cu aromele de vetiver și ambroxan, creând o experiență olfactivă unică. Note de top: Grapefruit, Lămâie Note de mijloc: Ghimbir, Vetiver Note de bază: Cedru, Lemn de Santal, Ambroxan.\r\n'),
(26, 'en', 'Perfume for men, 100 ml. The One for Men by Dolce & Gabbana is an elegant and sophisticated fragrance with a woody-oriental composition. The notes of grapefruit and orange peel blend perfectly with the scents of cedar and ambroxan, creating a unique olfactory experience. Top notes: Grapefruit, Orange Peel Middle notes: Cardamom, Ginger Base notes: Cedar, Ambroxan, Vanilla.\r\n'),
(26, 'es', 'Perfume para hombres, 100 ml. The One for Men de Dolce & Gabbana es una fragancia elegante y sofisticada con una composición oriental-amaderada. Las notas de pomelo y cáscara de naranja se combinan perfectamente con los aromas de cedro y ambroxan, creando una experiencia olfativa única. Notas de salida: Pomelo, Cáscara de Naranja Notas medias: Cardamomo, Jengibre Notas de fondo: Cedro, Ambroxan, Vainilla.\r\n'),
(26, 'fr', 'Parfum pour hommes, 100 ml. The One for Men de Dolce & Gabbana est un parfum élégant et sophistiqué avec une composition orientale-boisée. Les notes de pamplemousse et d\'écorce d\'orange se marient parfaitement avec les arômes de cèdre et d\'ambroxan, créant une expérience olfactive unique. Notes de tête: Pamplemousse, Écorce d\'Orange Notes de cœur: Cardamome, Gingembre Notes de fond: Cèdre, Ambroxan, Vanille.'),
(26, 'ro', 'Apă de parfum pentru bărbați, 100 ml. The One for Men de Dolce & Gabbana este un parfum elegant și sofisticat, cu o compoziție lemnos-orientală. Notele de grapefruit și coajă de portocală se combină perfect cu aromele de cedru și ambroxan, creând o experiență olfactivă unică. Note de top: Grapefruit, Coajă de portocală Note de mijloc: Cardamon, Ghimbir Note de bază: Cedru, Ambroxan, Vanilie.\r\n'),
(27, 'en', 'Perfume for men, 100 ml. Boss Bottled by Hugo Boss is a classic and sophisticated fragrance, with a woody-oriental composition. The notes of apple and cinnamon perfectly combine with the aromas of geranium and vetiver, creating a unique olfactory experience. Top notes: Apple, Citrus Middle notes: Cinnamon, Geranium Base notes: Cedarwood, Vetiver.\r\n'),
(27, 'es', 'Perfume para hombres, 100 ml. Boss Bottled de Hugo Boss es una fragancia clásica y sofisticada, con una composición oriental-amaderada. Las notas de manzana y canela se combinan perfectamente con los aromas de geranio y vetiver, creando una experiencia olfativa única. Notas de salida: Manzana, Cítricos Notas de corazón: Canela, Geranio Notas de fondo: Cedro, Vetiver.\r\n'),
(27, 'fr', 'Parfum pour homme, 100 ml. Boss Bottled de Hugo Boss est un parfum classique et sophistiqué, avec une composition orientale-boisée. Les notes de pomme et de cannelle se marient parfaitement avec les arômes de géranium et de vétiver, créant une expérience olfactive unique. Notes de tête: Pomme, Agrumes Notes de cœur: Cannelle, Géranium Notes de fond: Bois de cèdre, Vétiver.\r\n'),
(27, 'ro', 'Apă de parfum pentru bărbați, 100 ml. Boss Bottled de Hugo Boss este un parfum clasic și sofisticat, cu o compoziție lemnoas-orientală. Notele de măr și scorțișoară se combină perfect cu aromele de geraniu și vetiver, creând o experiență olfactivă unică. Note de top: Măr, Citrice Note de mijloc: Scorțișoară, Geraniu Note de bază: Lemn de Cedru, Vetiver.\r\n'),
(28, 'en', 'Perfume for women, 50 ml. Coco Mademoiselle by Chanel is a classic and elegant perfume, with a floral-oriental composition. The notes of orange and jasmine blend perfectly with the aromas of patchouli and vetiver, creating a unique olfactory experience. Top notes: Orange, Bergamot. Middle notes: Jasmine, Rose. Base notes: Patchouli, Vetiver.\r\n'),
(28, 'es', 'Perfume para mujeres, 50 ml. Coco Mademoiselle de Chanel es un perfume clásico y elegante, con una composición floral-oriental. Las notas de naranja y jazmín se combinan perfectamente con los aromas de pachulí y vetiver, creando una experiencia olfativa única. Notas de salida: Naranja, Bergamota. Notas de corazón: Jazmín, Rosa. Notas de fondo: Pachulí, Vetiver.\r\n'),
(28, 'fr', 'Parfum pour femmes, 50 ml. Coco Mademoiselle de Chanel est un parfum classique et élégant, avec une composition florale-orientale. Les notes d\'orange et de jasmin se marient parfaitement avec les arômes de patchouli et de vétiver, créant une expérience olfactive unique. Notes de tête : Orange, Bergamote. Notes de cœur : Jasmin, Rose. Notes de fond : Patchouli, Vétiver.\r\n'),
(28, 'ro', 'Apă de parfum pentru femei, 50 ml. Coco Mademoiselle de Chanel este un parfum clasic și elegant, cu o compoziție floral-orientală. Notele de portocală și iasomie se combină perfect cu aromele de patchouli și vetiver, creând o experiență olfactivă unică. Note de top: Portocală, Bergamotă Note de mijloc: Iasomie, Trandafir Note de bază: Patchouli, Vetiver.\r\n'),
(29, 'en', 'Perfume for men, 100 ml. Invictus by Paco Rabanne is a seductive and energizing fragrance, with a woody-marine composition. The notes of grapefruit and mint combine perfectly with the spices and guaiac wood, creating a unique olfactory experience. Top notes: Grapefruit, Orange Peel. Middle notes: Spices. Base notes: Guaiac Wood, Grey Amber.\r\n'),
(29, 'es', 'Perfume para hombres, 100 ml. Invictus de Paco Rabanne es una fragancia seductora y energizante, con una composición de madera y marina. Las notas de pomelo y menta se combinan perfectamente con las especias y la madera de guayaco, creando una experiencia olfativa única. Notas de salida: Pomelo, Corteza de naranja. Notas medias: Especias. Notas de fondo: Madera de guayaco, Ámbar gris.\r\n'),
(29, 'fr', 'Parfum pour homme, 100 ml. Invictus de Paco Rabanne est un parfum séduisant et énergisant, avec une composition boisée-marine. Les notes de pamplemousse et de menthe se marient parfaitement avec les épices et le bois de gaïac, créant une expérience olfactive unique. Notes de tête : Pamplemousse, Écorce d\'orange. Notes de cœur : Épices. Notes de fond : Bois de gaïac, Ambre gris.\r\n'),
(29, 'ro', 'Apă de parfum pentru bărbați, 100 ml. Invictus de Paco Rabanne este un parfum seducător și energizant, cu o compoziție lemnos-marine. Notele de grapefruit și mentă se combină perfect cu aromele de mirodenii și lemn de guaiac, creând o experiență olfactivă unică. Note de top: Grapefruit, Coajă de portocală Note de mijloc: Mirodenii Note de bază: Lemn de Guaiac, Ambra cenușie.\r\n'),
(30, 'en', 'Perfume for men, 100 ml. Dior Homme by Dior is an elegant and sophisticated perfume, with a floral and woody composition. Notes of lemon and iris combine perfectly with aromas of cedar and vetiver, creating a unique olfactory experience. Top notes: Lemon, Bergamot. Middle notes: Iris, Ambroxan. Base notes: Cedar, Vetiver.\r\n'),
(30, 'es', 'Perfume para hombres, 100 ml. Dior Homme de Dior es un perfume elegante y sofisticado, con una composición floral y amaderada. Las notas de limón e iris combinan perfectamente con los aromas de cedro y vetiver, creando una experiencia olfativa única. Notas de salida: Limón, Bergamota. Notas de corazón: Iris, Ambroxan. Notas de fondo: Cedro, Vetiver.\r\n'),
(30, 'fr', 'Parfum pour homme, 100 ml. Dior Homme de Dior est un parfum élégant et sophistiqué, avec une composition florale et boisée. Les notes de citron et d\'iris se marient parfaitement avec les arômes de cèdre et de vétiver, créant une expérience olfactive unique. Notes de tête : Citron, Bergamote. Notes de cœur : Iris, Ambroxan. Notes de fond : Cèdre, Vétiver.\r\n'),
(30, 'ro', 'Apă de parfum pentru bărbați, 100 ml. Dior Homme de Dior este un parfum elegant și sofisticat, cu o compoziție florală și lemnoasă. Notele de lămâie și iris se combină perfect cu aromele de cedru și vetiver, creând o experiență olfactivă unică. Note de top: Lămâie, Bergamotă Note de mijloc: Iris, Ambroxan Note de bază: Cedru, Vetiver.\r\n'),
(31, 'en', 'Perfume for men, 100 ml. The Scent by Hugo Boss is a seductive and intense fragrance, with a woody-oriental composition. The notes of ginger and lavender combine perfectly with the aromas of leather and sandalwood, creating a unique olfactory experience. Top notes: Ginger, Bergamot. Middle notes: Lavender, Maninka. Base notes: Leather, Sandalwood.\r\n'),
(31, 'es', 'Perfume para hombres, 100 ml. The Scent de Hugo Boss es una fragancia seductora e intensa, con una composición oriental amaderada. Las notas de jengibre y lavanda se combinan perfectamente con los aromas de cuero y madera de sándalo, creando una experiencia olfativa única. Notas de salida: jengibre, bergamota. Notas medias: lavanda, maninka. Notas de base: cuero, madera de sándalo.\r\n');
INSERT INTO `parfum_translation` (`idparfum`, `language`, `translated_descriere`) VALUES
(31, 'fr', 'Parfum pour hommes, 100 ml. The Scent de Hugo Boss est un parfum séduisant et intense, avec une composition orientale boisée. Les notes de gingembre et de lavande se marient parfaitement aux arômes de cuir et de bois de santal, créant une expérience olfactive unique. Notes de tête: gingembre, bergamote. Notes de cœur: lavande, maninka. Notes de fond: cuir, bois de santal.\r\n'),
(31, 'ro', 'Apă de parfum pentru bărbați, 100 ml. The Scent de Hugo Boss este un parfum seducător și intens, cu o compoziție lemnos-orientală. Notele de ghimbir și lavandă se combină perfect cu aromele de piele și lemn de santal, creând o experiență olfactivă unică. Note de top: Ghimbir, Bergamotă Note de mijloc: Lavandă, Maninka Note de bază: Piele, Lemn de santal.\r\n'),
(32, 'en', 'Perfume for men, 100 ml. Emporio Armani Stronger With You by Giorgio Armani is a seductive and intense fragrance with a woody-oriental composition. Notes of pink pepper and violet leaves perfectly blend with the aromas of chestnut and vanilla, creating a unique olfactory experience. Top notes: Pink pepper, Violet leaves. Middle note: Chestnut. Base note: Vanilla.\r\n'),
(32, 'es', 'Perfume para hombres, 100 ml. Emporio Armani Stronger With You de Giorgio Armani es una fragancia seductora e intensa con una composición oriental amaderada. Las notas de pimienta rosa y hojas de violeta se combinan perfectamente con los aromas de castaña y vainilla, creando una experiencia olfativa única. Notas de salida: Pimienta rosa, Hojas de violeta. Nota media: Castaña. Nota base: Vainilla.\r\n'),
(32, 'fr', 'Parfum pour hommes, 100 ml. Emporio Armani Stronger With You de Giorgio Armani est un parfum séduisant et intense avec une composition boisée orientale. Les notes de poivre rose et de feuilles de violette se mélangent parfaitement avec les arômes de châtaigne et de vanille, créant une expérience olfactive unique. Notes de tête : Poivre rose, Feuilles de violette. Note de cœur : Châtaigne. Note de fond : Vanille.\r\n'),
(32, 'ro', 'Apă de parfum pentru bărbați, 100 ml. Emporio Armani Stronger With You de Giorgio Armani este un parfum seducător și intens, cu o compoziție lemnos-orientală. Notele de piper roz și frunze de violetă se combină perfect cu aromele de castană și vanilie, creând o experiență olfactivă unică. Note de top: Piper roz, Frunze de violete Note de mijloc: Castană Note de bază: Vanilie.\r\n'),
(33, 'en', 'The fragrance for men, 100 ml. L\'Homme by Yves Saint Laurent is an elegant and sophisticated perfume, with a woody-floral composition. The notes of bergamot and ginger combine perfectly with the aromas of cedarwood and vetiver, creating a unique olfactory experience. Top notes: Bergamot, Ginger. Middle notes: Orange Blossom, Pink Pepper. Base notes: Cedarwood, Vetiver\r\n'),
(33, 'es', 'La fragancia para hombres, 100 ml. L\'Homme de Yves Saint Laurent es un perfume elegante y sofisticado, con una composición floral-amaderada. Las notas de bergamota y jengibre se combinan perfectamente con los aromas de madera de cedro y vetiver, creando una experiencia olfativa única. Notas de salida: Bergamota, Jengibre. Notas de corazón: Flor de naranjo, Pimienta rosa. Notas de fondo: Madera de cedro, Vetiver.\r\n'),
(33, 'fr', 'La fragrance pour hommes, 100 ml. L\'Homme d\'Yves Saint Laurent est un parfum élégant et sophistiqué, avec une composition florale-boisée. Les notes de bergamote et de gingembre se marient parfaitement avec les arômes de bois de cèdre et de vétiver, créant une expérience olfactive unique. Notes de tête : Bergamote, Gingembre. Notes de cœur : Fleur d\'oranger, Poivre rose. Notes de fond : Bois de cèdre, Vétiver.\r\n'),
(33, 'ro', 'Apă de parfum pentru bărbați, 100 ml. L Homme de Yves Saint Laurent este un parfum elegant și sofisticat, cu o compoziție lemnos-florală. Notele de bergamotă și ghimbir se combină perfect cu aromele de lemn de cedru și vetiver, creând o experiență olfactivă unică. Note de top: Bergamotă, Ghimbir Note de mijloc: Flori de portocal, Piper roz Note de bază: Lemn de cedru, Vetiver.\r\n'),
(34, 'en', 'Perfume for men, 100 ml. Fahrenheit by Dior is an iconic and sophisticated perfume, with a woody-floral composition. The notes of lemon and nutmeg combine perfectly with the aromas of leather and sandalwood, creating a unique olfactory experience. Top notes: Lemon, Nutmeg. Middle notes: Violet. Base notes: Leather, Sandalwood.\r\n'),
(34, 'es', 'Perfume para hombres, 100 ml. Fahrenheit de Dior es un perfume icónico y sofisticado, con una composición floral amaderada. Las notas de limón y nuez moscada se combinan perfectamente con los aromas de cuero y sándalo, creando una experiencia olfativa única. Notas de salida: Limón, Nuez moscada. Notas medias: Violeta. Notas de fondo: Cuero, Sándalo.\r\n'),
(34, 'fr', 'Parfum pour homme, 100 ml. Fahrenheit de Dior est un parfum emblématique et sophistiqué, avec une composition florale boisée. Les notes de citron et de muscade se marient parfaitement avec les arômes de cuir et de bois de santal, créant une expérience olfactive unique. Notes de tête : Citron, Muscade. Notes de cœur : Violette. Notes de fond : Cuir, Bois de santal.\r\n'),
(34, 'ro', 'Apă de parfum pentru bărbați, 100 ml. Fahrenheit de Dior este un parfum iconic și sofisticat, cu o compoziție lemnos-florală. Notele de lămâie și mușcate se combină perfect cu aromele de piele și lemn de santal, creând o experiență olfactivă unică. Note de top: Lămâie, Mușcate Note de mijloc: Violete Note de bază: Piele, Lemn de santal.\r\n'),
(35, 'en', 'Perfume for men, 100 ml. Gentleman Givenchy by Givenchy is a classic and sophisticated fragrance, with a woody-floral composition. Notes of bergamot and cardamom blend perfectly with aromas of iris and cedarwood, creating a unique olfactory experience. Top notes: Bergamot, Cardamom. Middle notes: Iris, Lavender. Base notes: Cedarwood, Vetiver.\r\n'),
(35, 'es', 'Perfume para hombres, 100 ml. Gentleman Givenchy de Givenchy es una fragancia clásica y sofisticada, con una composición floral-madera. Las notas de bergamota y cardamomo se combinan perfectamente con aromas de iris y madera de cedro, creando una experiencia olfativa única. Notas de salida: Bergamota, Cardamomo. Notas medias: Iris, Lavanda. Notas de fondo: Madera de cedro, Vetiver.\r\n'),
(35, 'fr', 'Parfum pour hommes, 100 ml. Gentleman Givenchy de Givenchy est un parfum classique et sophistiqué, avec une composition florale-boisée. Les notes de bergamote et de cardamome se marient parfaitement aux arômes d\'iris et de cèdre, créant une expérience olfactive unique. Notes de tête: Bergamote, Cardamome. Notes de coeur: Iris, Lavande. Notes de fond: Bois de cèdre, Vetiver.\r\n'),
(35, 'ro', 'Apă de parfum pentru bărbați, 100 ml. Gentleman Givenchy de Givenchy este un parfum clasic și sofisticat, cu o compoziție lemnoas-florală. Notele de bergamotă și cardamon se combină perfect cu aromele de iris și lemn de cedru, creând o experiență olfactivă unică. Note de top: Bergamotă, Cardamon Note de mijloc: Iris, Lavandă Note de bază: Lemn de cedru, Vetiver.\r\n'),
(36, 'en', 'Perfume for men, 100 ml. Aventus by Creed is a luxurious and sophisticated fragrance with a woody-fruity composition. The notes of pineapple and bergamot blend perfectly with the scents of musk and cedarwood, creating a unique olfactory experience. Top notes: Pineapple, Bergamot. Middle notes: Musk. Base notes: Cedarwood, Patchouli.\r\n'),
(36, 'es', 'Perfume para hombres, 100 ml. Aventus de Creed es una fragancia lujosa y sofisticada con una composición amaderada-frutal. Las notas de piña y bergamota se combinan perfectamente con los aromas de almizcle y madera de cedro, creando una experiencia olfativa única. Notas de salida: Piña, Bergamota. Notas de corazón: Almizcle. Notas de fondo: Madera de cedro, Pachulí.\r\n'),
(36, 'fr', 'Parfum pour homme, 100 ml. Aventus de Creed est un parfum luxueux et sophistiqué avec une composition boisée-fruity. Les notes d\'ananas et de bergamote se mélangent parfaitement avec les parfums de musc et de cèdre, créant une expérience olfactive unique. Notes de tête: Ananas, Bergamote. Notes de coeur: Musc. Notes de fond: Cèdre, Patchouli.\r\n'),
(36, 'ro', 'Apă de parfum pentru bărbați, 100 ml. Aventus de Creed este un parfum luxos și sofisticat, cu o compoziție lemnos-fructată. Notele de ananas și bergamotă se combină perfect cu aromele de mosc și lemn de cedru, creând o experiență olfactivă unică. Note de top: Ananas, Bergamotă Note de mijloc: Mosc Note de bază: Lemn de cedru, Paciuli.\r\n'),
(37, 'en', 'Men\'s eau de parfum, 80 ml. Reinvent the rules with Gentleman Society Eau de Parfum, the Givenchy men\'s fragrance that redefines the concept of a gentleman. A multifaceted fragrance that creates a contrast between the wild narcissus note and the enigmatic woody accord. Made from remarkable ingredients, Gentleman Society is emblematic of Givenchy\'s mastery and expertise. Fresh sage top notes combine with the floral accords of wild narcissus absolute. This duo joins the intense and mysterious aromas of vetiver harvested in Madagascar, Uruguay, and Haiti. The warm aroma of vanilla is mixed with sandalwood and cedarwood essences, offering intensity to this sophisticated men\'s fragrance. A bold statement for the modern gentleman. The design of the Givenchy Gentleman bottles is revised with a pure elegance accent. The 4 G logo reinterpreted in silver metal decorates the lacquered black bottle. The bottle is composed of 15%.\r\n'),
(37, 'es', 'Agua de perfume para hombres, 80 ml. Reinventa las reglas con Gentleman Society Eau de Parfum, la fragancia masculina de Givenchy que redefine el concepto de caballero. Una fragancia multifacética que crea un contraste entre la nota de narciso salvaje y el enigmático acorde amaderado. Elaborada con ingredientes notables, Gentleman Society es emblemática de la maestría y experiencia de Givenchy. Las notas altas de salvia fresca se combinan con los acordes florales del absoluto de narciso salvaje. Este dúo se une a las intensas y misteriosas aromas de vetiver cosechado en Madagascar, Uruguay y Haití. El cálido aroma de la vainilla se mezcla con esencias de sándalo y cedro, ofreciendo intensidad a esta sofisticada fragancia para hombres. Una declaración audaz para el caballero moderno. El diseño de las botellas de Givenchy Gentleman se revisa con un acento de elegancia pura. El logotipo 4 G reinterpretado en metal plateado decora la botella lacada en negro. La botella está compuesta en un'),
(37, 'fr', 'Eau de parfum pour hommes, 80 ml. Réinventez les règles avec Gentleman Society Eau de Parfum, le parfum pour hommes Givenchy qui redéfinit le concept de gentleman. Un parfum aux multiples facettes qui crée un contraste entre la note de narcisse sauvage et l\'accord boisé énigmatique. Fabriqué à partir d\'ingrédients remarquables, Gentleman Society est emblématique de la maîtrise et de l\'expertise de Givenchy. Les notes de tête de sauge fraîche se combinent avec les accords floraux de l\'absolu de narcisse sauvage. Ce duo rejoint les arômes intenses et mystérieux de vétiver récolté à Madagascar, en Uruguay et en Haïti. L\'arôme chaud de la vanille est mélangé aux essences de bois de santal et de cèdre, offrant de l\'intensité à ce parfum sophistiqué pour hommes. Une déclaration audacieuse pour le gentleman moderne. Le design des flacons Givenchy Gentleman est révisé avec un accent d\'une élégance pure. Le logo 4 G réinterprété en métal argenté décore la boute\r\n'),
(37, 'ro', 'Apă de parfum bărbați, 80 ml. Reinventeaza regulile cu Gentleman Society Eau de Parfum, parfumul masculin Givenchy ce redefineste conceptul de gentleman. Un parfum cu mai multe fatete ce creeaza un contrast intre nota de narcisa salbatica si acordul lemnos enigmatic. Realizat din ingrediente remarcabile, Gentleman Society este emblematic pentru maiestria si expertiza Givenchy. Notele de varf de salvie proaspata se combina cu acordurile florale ale absolutului de narcisa salbatica. Acest duo se alatura aromei intense si misterioase a acordurilor de Vetiver recoltat in Madagascar, Uruguay si Haiti. Aroma calda de vanilie este mixata cu esentele de lemn de santal si lemn de cedru ce ofera intensitate acestui parfum sofisticat pentru barbati. O declaratie indrazneata pentru gentlemanul modern. Designul flacoanelor Givenchy Gentleman este revizuit cu un accent de eleganta pura. Sigla 4 G reinterpretata in metal argintiu decoreaza sticla negru-lacuit. Flaconul este compus in proportie de 15%'),
(38, 'en', 'Women\'s Eau de Parfum, 50 ml. Elegance Divine by Dior is a sophisticated and sensual fragrance, perfect for the modern woman who wants to shine. With top notes of bergamot, ylang-ylang, and rose, it develops into a heart of jasmine and vanilla, culminating in a warm blend of musk, amber, and sandalwood. The elegant and refined bottle perfectly complements the luxurious aura of this exceptional perfume\r\n'),
(38, 'es', 'Agua de perfume para mujeres, 50 ml. Elegance Divine de Dior es una fragancia sofisticada y sensual, perfecta para la mujer moderna que quiere brillar. Con notas altas de bergamota, ylang-ylang y rosa, se desarrolla en un corazón de jazmín y vainilla, culminando en una cálida mezcla de almizcle, ámbar y sándalo. La botella elegante y refinada complementa perfectamente la aura lujosa de este perfume excepcional\r\n'),
(38, 'fr', 'Eau de parfum pour femmes, 50 ml. Elegance Divine de Dior est un parfum sophistiqué et sensuel, parfait pour la femme moderne qui veut briller. Avec des notes de tête de bergamote, d\'ylang-ylang et de rose, il se développe en un cœur de jasmin et de vanille, culminant dans un mélange chaud de musc, d\'ambre et de bois de santal. Le flacon élégant et raffiné complète parfaitement l\'aura luxueuse de ce parfum exceptionnel.\r\n'),
(38, 'ro', 'Apă de parfum femei, 50 ml. Elegance Divine de la Dior este un parfum sofisticat si senzual, perfect pentru femeia moderna care doreste sa straluceasca. Cu note de varf de bergamot, ylang-ylang si trandafir, se dezvolta in inima de iasomie si vanilie, culminand intr-un amestec cald de mosc, ambra si lemn de santal. Flaconul elegant si rafinat completeaza perfect aura luxoasa a acestui parfum de exceptie.\r\n'),
(40, 'en', 'Women\'s Eau de Parfum, 30 ml. Floral Essence by Gucci is a delicate and fresh perfume, designed for the modern and romantic woman. Combining top notes of peach, red berries, and lemon with a heart of freesia, magnolia, and rose, this perfume finishes with a base of white musk, cedar, and amber. The simple and refined bottle underlines the elegance of this feminine fragrance.\r\n'),
(40, 'es', 'Agua de perfume para mujeres, 30 ml. Floral Essence de Gucci es una fragancia delicada y fresca, diseñada para la mujer moderna y romántica. Combinando notas altas de durazno, bayas rojas y limón, con un corazón de fresia, magnolia y rosa, este perfume termina con una base de almizcle blanco, cedro y ámbar. La botella simple y refinada subraya la elegancia de esta fragancia femenina\r\n'),
(40, 'fr', 'Eau de parfum pour femmes, 30 ml. Floral Essence de Gucci est un parfum délicat et frais, conçu pour la femme moderne et romantique. Combinant des notes de tête de pêche, de baies rouges et de citron avec un cœur de freesia, de magnolia et de rose, ce parfum se termine par une base de musc blanc, de cèdre et d\'ambre. Le flacon simple et raffiné souligne l\'élégance de cette fragrance féminine.\r\n'),
(40, 'ro', 'Apă de parfum femei, 30 ml. Floral Essence de la Gucci este un parfum delicat si fresh, conceput pentru femeia moderna si romantica. Combinand note de varf de piersica, coacaze rosii si lamaie, cu inima de frezie, magnolie si trandafir, acest parfum se incheie cu baza de mosc alb, cedru si ambra. Flaconul simplu si rafinat subliniaza eleganta acestui parfum feminin.\r\n'),
(41, 'en', 'Men\'s Eau de Parfum, 50 ml. Ocean Breeze by Armani is a fresh and energizing fragrance, perfect for the modern and dynamic man. With top notes of grapefruit, mandarin, and pink pepper, it unfolds into a heart of lavender, geranium, and cardamom, while the base of the fragrance includes sandalwood, vetiver, and patchouli. The elegant and modern bottle perfectly complements this refined fragrance.\r\n'),
(41, 'es', 'Eau de Parfum para hombres, 50 ml. Ocean Breeze de Armani es una fragancia fresca y energizante, perfecta para el hombre moderno y dinámico. Con notas altas de pomelo, mandarina y pimienta rosa, se desarrolla en un corazón de lavanda, geranio y cardamomo, mientras que la base de la fragancia incluye madera de sándalo, vetiver y pachulí. El elegante y moderno frasco complementa perfectamente esta fragancia refinada.\r\n'),
(41, 'fr', 'Eau de Parfum pour hommes, 50 ml. Ocean Breeze de Armani est un parfum frais et énergisant, parfait pour l\'homme moderne et dynamique. Avec des notes de tête de pamplemousse, mandarine et poivre rose, il se déploie en un cœur de lavande, géranium et cardamome, tandis que la base du parfum comprend du bois de santal, du vétiver et du patchouli. Le flacon élégant et moderne complète parfaitement cette fragrance raffinée.\r\n'),
(41, 'ro', 'Apă de parfum bărbați, 50 ml. Ocean Breeze de la Armani este un parfum proaspat si energizant, perfect pentru barbatul modern si dinamic. Cu note de varf de grapefruit, mandarina si piper roz, se desfasoara intr-o inima de lavanda, geranium si cardamom, in timp ce baza parfumului include lemn de santal, vetiver si paciuli. Flaconul elegant si modern completeaza perfect acest parfum rafinat.\r\n'),
(42, 'en', 'The perfume is called Velvet Dreams by Yves Saint Laurent, and it is designed for modern and sophisticated women. It is a sensual and captivating fragrance with top notes of bergamot, blackcurrant, and lychee. It develops into a heart of jasmine, rose, and patchouli, and finishes with a warm base of vanilla, amber, and sandalwood. The luxurious and refined bottle perfectly reflects the essence of this seductive perfume.\r\n'),
(42, 'es', 'El perfume se llama Velvet Dreams de Yves Saint Laurent, y está diseñado para mujeres modernas y sofisticadas. Es una fragancia sensual y cautivadora con notas altas de bergamota, grosella negra y lichi. Se desarrolla en un corazón de jazmín, rosa y patchouli, y termina con una base cálida de vainilla, ámbar y madera de sándalo. El frasco lujoso y refinado refleja perfectamente la esencia de este perfume seductor.\r\n'),
(42, 'fr', 'Le parfum s\'appelle Velvet Dreams de Yves Saint Laurent et est conçu pour les femmes modernes et sophistiquées. C\'est un parfum sensuel et captivant avec des notes de tête de bergamote, de cassis et de litchi. Il se développe en un cœur de jasmin, de rose et de patchouli, et se termine par une base chaude de vanille, d\'ambre et de bois de santal. Le flacon luxueux et raffiné reflète parfaitement l\'essence de ce parfum séduisant.\r\n'),
(42, 'ro', 'Apă de parfum femei, 30 ml. Velvet Dreams de la Yves Saint Laurent este un parfum senzual si captivant, destinat femeii moderne si sofisticate. Cu note de varf de bergamot, coacaze negre si litchi, parfumul se dezvolta intr-o inima de iasomie, trandafir si patchouli, culminand cu baza calda de vanilie, ambra si lemn de santal. Flaconul luxos si rafinat reflecta perfect esenta acestui parfum seducator.\r\n');

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `persoana`
--

CREATE TABLE `persoana` (
  `CNP` varchar(13) NOT NULL,
  `nume` varchar(20) NOT NULL,
  `prenume` varchar(50) NOT NULL,
  `userID` int(11) NOT NULL,
  `telefon` varchar(15) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Eliminarea datelor din tabel `persoana`
--

INSERT INTO `persoana` (`CNP`, `nume`, `prenume`, `userID`, `telefon`, `email`) VALUES
('1100705231247', 'Popescu', 'Ion', 1, '0723548932', 'ion.popescu@gmail.com'),
('1930605051025', 'Dumitru', 'George', 10, '0774561234', 'george.dumitru@gmail.com'),
('1960224232031', 'Munteanu', 'Gabriel', 12, '0741122334', 'gabriel.munteanu@gmail.com'),
('1960513165123', 'Mihai', 'Cristina', 18, '0732123456', 'cristina.mihai@gmail.com'),
('1980122110018', 'Popa', 'Mihai', 8, '0765089234', 'mihai.popa@gmail.com'),
('1980329019037', 'Radu', 'Diana', 14, '0763123456', 'diana.radu@gmail.com'),
('1981002054025', 'Popovici', 'Ioana', 16, '0729456789', 'ioana.popovici@gmail.com'),
('2110909211241', 'Stan', 'Andreea', 7, '0754213568', 'andreea.stan@gmail.com'),
('2950107210874', 'Stefan', 'Alexandra', 9, '0745230145', 'alexandra.stefan@gmail.com'),
('2950201134153', 'Ionescu', 'Maria', 3, '0765089234', 'maria@gmail.com'),
('2950322014084', 'Cristea', 'Cristina', 13, '0756102345', 'cristina.cristea@gmail.com'),
('2950708214065', 'Vasilescu', 'Roxana', 20, '0765123456', 'roxana.vasilescu@gmail.com'),
('2951024065213', 'Negrea', 'Andrei', 15, '0746123456', 'andrei.negrea@gmail.com'),
('2951219250012', 'Andrei', 'Maria', 11, '0730123456', 'maria.andrei@gmail.com'),
('2961013190131', 'Gheorghiu', 'Florin', 19, '0742789456', 'florin.gheorghiu@gmail.com'),
('2970208165127', 'Stanciu', 'Andrei', 17, '0767456321', 'andrei.stanciu@gmail.com'),
('2990201134153', 'Antonescu', 'Ana', 4, '0765089234', 'ana@gmail.com');

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `utilizator`
--

CREATE TABLE `utilizator` (
  `userId` int(11) NOT NULL,
  `user` varchar(20) NOT NULL,
  `parola` varchar(20) NOT NULL,
  `rol` varchar(20) NOT NULL,
  `idmagazin` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Eliminarea datelor din tabel `utilizator`
--

INSERT INTO `utilizator` (`userId`, `user`, `parola`, `rol`, `idmagazin`) VALUES
(1, 'ion123', 'ion123', 'administrator', NULL),
(2, 'marius123', 'marius123', 'manager', NULL),
(3, 'maria123', 'maria123', 'angajat', 1),
(4, 'ana123', 'ana123', 'angajat', 2),
(5, 'ada123', 'ada123', 'Angajat', 3),
(6, 'aurel12', 'aurel12345', 'Angajat', 1),
(7, 'stan12', 'stan123456', 'Manager', NULL),
(8, 'popa03', 'popa035u78', 'Manager', NULL),
(9, 'stefan04', 'stefan04', 'manager', NULL),
(10, 'dumitru05', 'dumitru05', 'manager', NULL),
(11, 'andrei06', 'andrei06', 'manager', NULL),
(12, 'munteanu07', 'munteanu07', 'manager', NULL),
(13, 'cristea08', 'cristea08', 'manager', NULL),
(14, 'radu09', 'radu09', 'manager', NULL),
(15, 'Antonio', 'an123', 'administrator', NULL),
(16, 'popovici11', 'popovici11', 'manager', NULL),
(17, 'stanciu12', 'stanciu12', 'manager', NULL),
(18, 'Mihai12345678', 'mmm', 'Angajat', 1);

--
-- Indexuri pentru tabele eliminate
--

--
-- Indexuri pentru tabele `magazin`
--
ALTER TABLE `magazin`
  ADD PRIMARY KEY (`idMagazin`);

--
-- Indexuri pentru tabele `parfum`
--
ALTER TABLE `parfum`
  ADD PRIMARY KEY (`idParfum`);

--
-- Indexuri pentru tabele `parfummagazin`
--
ALTER TABLE `parfummagazin`
  ADD PRIMARY KEY (`idParfum`,`idMagazin`),
  ADD KEY `magazinid_FK` (`idMagazin`);

--
-- Indexuri pentru tabele `parfum_translation`
--
ALTER TABLE `parfum_translation`
  ADD PRIMARY KEY (`idparfum`,`language`);

--
-- Indexuri pentru tabele `persoana`
--
ALTER TABLE `persoana`
  ADD PRIMARY KEY (`CNP`);

--
-- Indexuri pentru tabele `utilizator`
--
ALTER TABLE `utilizator`
  ADD PRIMARY KEY (`userId`),
  ADD KEY `magazin_FK` (`idmagazin`);

--
-- Constrângeri pentru tabele eliminate
--

--
-- Constrângeri pentru tabele `parfummagazin`
--
ALTER TABLE `parfummagazin`
  ADD CONSTRAINT `magazinid_FK` FOREIGN KEY (`idMagazin`) REFERENCES `magazin` (`idMagazin`),
  ADD CONSTRAINT `parfumid_FK` FOREIGN KEY (`idParfum`) REFERENCES `parfum` (`idParfum`);

--
-- Constrângeri pentru tabele `parfum_translation`
--
ALTER TABLE `parfum_translation`
  ADD CONSTRAINT `parfum_translation_ibfk_1` FOREIGN KEY (`idparfum`) REFERENCES `parfum` (`idParfum`),
  ADD CONSTRAINT `parfum_translation_ibfk_2` FOREIGN KEY (`idparfum`) REFERENCES `parfum` (`idParfum`);

--
-- Constrângeri pentru tabele `utilizator`
--
ALTER TABLE `utilizator`
  ADD CONSTRAINT `magazin_FK` FOREIGN KEY (`idmagazin`) REFERENCES `magazin` (`idMagazin`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
